"""Enumerate an official MIIT announcement column through its published pagination API."""
import csv
import html
import json
from pathlib import Path
import re
import urllib.parse
from public_fetch import fetch

ROOT = Path(__file__).resolve().parent
raw = ROOT / 'raw'
first = json.loads((raw / 'announcements_build.txt').read_text())['data']['html']
attributes = re.search(r'<div class="pagination"\s+queryData="([^"]+)"', first).group(1)
query = json.loads(attributes.replace("'", '"'))
all_rows = []

def parse(fragment, page):
    matches = re.findall(r'<a class="fl" href="([^"]+)"[^>]*title="([^"]*)"[^>]*>.*?<span class="fr">.*?(\d{4}-\d{2}-\d{2})',
                         fragment, re.S)
    return [{'column_page': page, 'url': urllib.parse.urljoin('https://www.miit.gov.cn/', url),
             'title': html.unescape(title), 'column_display_date': date}
            for url, title, date in matches]

for page in range(1, 42):
    if page == 1:
        fragment = first
    else:
        parameters = dict(query, paramJson=json.dumps({'pageNo': page, 'pageSize': '24'}, separators=(',', ':')))
        url = 'https://www.miit.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit?' + urllib.parse.urlencode(parameters)
        record, body = fetch(f'announcement_page_{page:02d}', url, '.txt')
        if record.get('status') != 200:
            break
        response = json.loads(body)
        fragment = response['data']['html']
    rows = parse(fragment, page)
    print('COLUMN_PAGE', page, 'rows', len(rows), 'dates', min((r['column_display_date'] for r in rows), default=''),
          max((r['column_display_date'] for r in rows), default=''), flush=True)
    if not rows:
        break
    all_rows.extend(rows)
    if min(r['column_display_date'] for r in rows) < '2022-01-01':
        break

with (ROOT / 'official_announcements_column.csv').open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
    writer.writeheader()
    writer.writerows(all_rows)
window = [r for r in all_rows if '2022-01-01' <= r['column_display_date'] <= '2024-12-31']
print('WINDOW', len(window), 'dates', min(r['column_display_date'] for r in window), max(r['column_display_date'] for r in window))
