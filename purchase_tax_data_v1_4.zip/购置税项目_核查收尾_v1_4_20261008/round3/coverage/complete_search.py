import csv,json,urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from public_fetch import fetch
r=Path(__file__).resolve().parent; raw=r/'raw'
tasks=[]
for name in ['search_tax_2022_2024','search_withdrawal_all']:
 rec=json.loads((raw/(name+'.json')).read_text());base=rec['requested_url'];body=json.loads((raw/(name+'.txt')).read_text());z=body['data']['searchResult'];count=len(z['dataResults'] or []); pages=(z['total']+count-1)//count
 for p in range(2,pages+1):
  parts=urllib.parse.urlsplit(base);q=dict(urllib.parse.parse_qsl(parts.query));q['p']=str(p);url=urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(q)))
  tasks.append((name,p,url))
base=json.loads((raw/'search_tax_2022_2024.json').read_text())['requested_url'];parts=urllib.parse.urlsplit(base);q=dict(urllib.parse.parse_qsl(parts.query));q['begin']='2014-01-01';q['end']='2021-12-31';q['p']='1';tasks.append(('search_tax_2014_2021',1,urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(q)))))
def get(task):
 name,p,url=task;target=raw/f'{name}_page_{p:02d}.txt';meta=raw/f'{name}_page_{p:02d}.json'
 if target.exists() and meta.exists() and json.loads(meta.read_text()).get('status')==200:return name,p,json.loads(target.read_text())
 rec,b=fetch(f'{name}_page_{p:02d}',url,'.txt')
 if rec.get('status')!=200:return name,p,None
 try:return name,p,json.loads(b)
 except Exception:return name,p,None
with ThreadPoolExecutor(max_workers=4) as pool:
 results=[f.result() for f in as_completed([pool.submit(get,t) for t in tasks])]
results.extend([(name,1,json.loads((raw/(name+'.txt')).read_text())) for name in ['search_tax_2022_2024','search_withdrawal_all','search_errata_all','search_corrections_all']])
legacy=next((x for n,p,x in results if n=='search_tax_2014_2021'),None)
if legacy:
 z=legacy['data']['searchResult'];count=len(z['dataResults'] or []);print('LEGACY',z['total'],count,flush=True)
 if count:
  more=[]
  for p in range(2,(z['total']+count-1)//count+1):
   q['p']=str(p);more.append(('search_tax_2014_2021',p,urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(q)))))
  with ThreadPoolExecutor(max_workers=4) as pool:results.extend([f.result() for f in as_completed([pool.submit(get,t) for t in more])])
rows=[];summ=[]
for name,p,x in results:
 if x is None:summ.append({'query':name,'page':p,'status':'failed'});continue
 z=x['data']['searchResult'];groups=z.get('dataResults') or [];summ.append({'query':name,'page':p,'status':'ok','total_group_count':z['total'],'raw_hit_count':z['totalHits'],'groups_returned':len(groups)})
 for group in groups:
  for g in group.get('groupData') or [group]:
   d=g.get('data') or {}
   if not d.get('url'):continue
   rows.append({'query':name,'result_page':p,'url':urllib.parse.urljoin('https://www.miit.gov.cn/',d['url']),'title':d.get('title',''),'search_display_date':d.get('jsearch_date',''),'columnname':d.get('columnname',''),'deploytime_raw':d.get('deploytime',''),'contentdescribe':d.get('contentdescribe','')})
with (r/'official_search_results.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(sorted(rows,key=lambda z:(z['query'],int(z['result_page']),z['url'])))
(r/'search_enumeration_summary.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2)+'\n')
print('ROWS',len(rows),'URLS',len(set(x['url'] for x in rows)),flush=True)
