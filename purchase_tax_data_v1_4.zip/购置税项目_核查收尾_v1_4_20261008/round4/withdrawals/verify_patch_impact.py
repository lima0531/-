#!/usr/bin/env python3
"""Check the actual before/after data and source evidence, independently of enumeration."""
from pathlib import Path
from collections import Counter
from zipfile import ZipFile
from xml.etree import ElementTree as E
import csv, hashlib, json
import xlrd
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/purchase_tax_audit/round3/reconstruction/data_v1_3')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=read(BASE/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv')
after=read(ROOT/'正式历史撤销_全表核查修正版3007行.csv')
contentpatch=read(ROOT/'全表对语义表_内容修订补丁.csv')
provenancepatch=read(ROOT/'企业文字来源标注_逐行精确化候选.csv')
enumeration=read(ROOT/'9份历史撤销_独立全表枚举3007行.csv')
cohort={r['model_key'] for r in read(BASE/'研究数据/样本成员重建.csv')}
assert len(before)==len(after)==len(enumeration)==3007
expected=[]
for p in contentpatch:
    i=int(p['input_csv_line_1based'])-2;field=p['field']
    assert before[i][field]==p['old_value'] and after[i][field]==p['original_value']
    assert before[i]['model_key']==p['model_key']==after[i]['model_key']
    expected.append((i,field,p['old_value'],p['original_value']))
for p in provenancepatch:
    i=int(p['input_csv_line_1based'])-2;field=p['field']
    assert before[i][field]==p['old_value'] and after[i][field]==p['suggested_precise_value']
    expected.append((i,field,p['old_value'],p['suggested_precise_value']))
actual=[]
for i,(a,b) in enumerate(zip(before,after)):
    for field in a:
        if a[field]!=b[field]:actual.append((i,field,a[field],b[field]))
assert Counter(expected)==Counter(actual)
identityfields=['车辆型号','model_key','原件文件','原件SHA256','原列入批次','撤销公告批次','撤销事件日','撤销观察日','publish_date_is_verified','signed_date_is_verified','在研究总体内']
assert all(all(a[k]==b[k] for k in identityfields) for a,b in zip(before,after))
assert not any(p['model_key'] in cohort for p in contentpatch)

# Read the two repaired cells again directly from original file formats.
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
xmlsource=Path(next(r['original_path_used'] for r in enumeration if r['model_key']=='ZQZ5041XXYBEV'))
with ZipFile(xmlsource) as z:tree=E.fromstring(z.read('word/document.xml'))
r=tree.findall('.//w:tbl/w:tr',ns)[63]
cells=[''.join(c.itertext()).strip() for c in r.findall('w:tc',ns)]
assert cells[0]=='63' and cells[2]=='ZQZ5041XXYBEV' and cells[1]=='中汽商用汽车有限公司(杭州)'
xlssource=Path(next(r['original_path_used'] for r in enumeration if r['model_key']=='WK5040XJEEV1'))
sheet=xlrd.open_workbook(xlssource).sheet_by_index(0)
assert sheet.cell_value(179,0)==176 and sheet.cell_value(179,2)=='WK5040XJEEV1' and sheet.cell_value(179,3)=='纯电动监测车'

hashes={r['original_path_used']:(r['source_sha256_used'],r['historical_sha256_expected']) for r in enumeration}
assert len(hashes)==9
for p,(seen,expected_sha) in hashes.items():assert digest(Path(p))==seen==expected_sha
result={'before_rows':len(before),'after_rows':len(after),'content_field_changes':len(contentpatch),'provenance_flag_changes':len(provenancepatch),'total_existing_field_changes':len(actual),'unexpected_existing_field_changes':0,'identity_and_date_fields_unchanged':identityfields,'content_changes_in_research_cohort':0,'provenance_flags_changed_in_research_cohort':sum(p['model_key'] in cohort for p in provenancepatch),'source_files_same_sha256_as_historical_index':len(hashes),'source_models_multiset_before_after_equal':Counter((r['原件文件'],r['model_key']) for r in before)==Counter((r['原件文件'],r['model_key']) for r in after),'original_3007_grain':'numbered original source rows; duplicate model observations retained','all_checks_passed':True,'original_input_files_modified':False}
(ROOT/'patch_impact_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
