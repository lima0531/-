import csv,html,json,re,urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from public_fetch import fetch
root=Path(__file__).resolve().parent
raw=root/'raw'
first=json.loads((raw/'announcements_build.txt').read_text())['data']['html']
query=json.loads(re.search(r'<div class="pagination"\s+queryData="([^"]+)"',first).group(1).replace("'",'"'))
count=int(re.search(r'\bcount="(\d+)"',first).group(1)); pages=(count+23)//24

def get(page):
 if page==1:return page,first
 target=raw/f'announcement_page_{page:02d}.txt'
 rec=raw/f'announcement_page_{page:02d}.json'
 if target.exists() and rec.exists() and json.loads(rec.read_text()).get('status')==200:
  body=target.read_bytes()
 else:
  parameters=dict(query,paramJson=json.dumps({'pageNo':page,'pageSize':'24'},separators=(',',':')))
  record,body=fetch(f'announcement_page_{page:02d}','https://www.miit.gov.cn/api-gateway/jpaas-publish-server/front/page/build/unit?'+urllib.parse.urlencode(parameters),'.txt')
  if record.get('status')!=200:return page,None
 try:return page,json.loads(body)['data']['html']
 except Exception:return page,None
results=[]; failures=[]
with ThreadPoolExecutor(max_workers=4) as pool:
 for future in as_completed([pool.submit(get,page) for page in range(1,pages+1)]):
  page,fragment=future.result()
  if fragment is None:failures.append(page);continue
  # Only primary list links; child related-interpretation links excluded by class fl.
  matches=re.findall(r'<a class="fl" href="([^"]+)"[^>]*title="([^"]*)"[^>]*>.*?<span class="fr">.*?(\d{4}-\d{2}-\d{2})',fragment,re.S)
  rows=[{'column_page':page,'url':urllib.parse.urljoin('https://www.miit.gov.cn/',url),'title':html.unescape(title),'column_display_date':date} for url,title,date in matches]
  print(page,len(rows),min((r['column_display_date'] for r in rows),default=''),flush=True);results.extend(rows)
results.sort(key=lambda r:(r['column_page'],-int(r['column_display_date'].replace('-',''))))
with (root/'official_announcements_column_complete.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['column_page','url','title','column_display_date']);w.writeheader();w.writerows(results)
report={'api_declared_count':count,'pages_expected':pages,'pages_failed':sorted(failures),'rows_retrieved':len(results),'unique_urls':len(set(r['url'] for r in results)),'minimum_column_date':min(r['column_display_date'] for r in results),'maximum_column_date':max(r['column_display_date'] for r in results),'scope':'MIIT政策文件/公告栏目本次可见分页全集，不是全互联网或工信部所有栏目全集'}
(root/'column_enumeration_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False),flush=True)
