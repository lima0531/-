import pathlib,json,csv,re,hashlib,fitz,html
P=pathlib.Path(__file__).parent
POLICY_URL='https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2023/art_62216a180da4437cad5c2710e4b6924e.html'
PDF_URL='https://www.miit.gov.cn/cms_files/filemanager/1226211233/attach/202312/b78f1a68e62e45a59a14f6d6924c0fed.pdf'
STD_QUERY=json.loads((P/'openstd_search_receipt.json').read_text())['url']
pdf=P/'policy32_attachment_official.pdf'
b=pdf.read_bytes();sha=hashlib.sha256(b).hexdigest();doc=fitz.open(pdf)
assert b.startswith(b'%PDF-') and len(doc)==3
assert sha=='108550dc32e4b64bbe64a3e8e6e60fa9dfd08d682fb52ca74461bc22293883e0'
texts=[p.get_text() for p in doc];(P/'policy32_attachment_text.txt').write_text('\n\f\n'.join(texts),encoding='utf-8')
normal=lambda s:re.sub(r'\s+','',s)
compact=normal(texts[0]);truck=normal(texts[2])
passage='对按照GB/T18386.1-2021《电动汽车能量消耗量和续驶里程试验方法第1部分：轻型汽车》中“附录A”进行检测的纯电动乘用车车型，其低温里程衰减率不超过35%的，电池系统能量密度应不低于95Wh/kg,续驶里程不低于120km。'
assert normal(passage) in compact
assert 'N1类纯电动货车车型' in truck and '其低温里程衰减率不超过35%' in truck
phtml=(P/'policy32_primary.html').read_text()
assert '2023-12-07' in phtml and '发布日期：</span><span class="xxgk-span4">2023-12-11' in phtml
article_text=html.unescape(re.sub('<[^>]+>','\n',phtml));article_text='\n'.join(x.strip() for x in article_text.splitlines() if x.strip());(P/'policy32_primary_text.txt').write_text(article_text)
metadata={
 'standard_number':'GB/T 18386.1-2021',
 'standard_name':'电动汽车能量消耗量和续驶里程试验方法 第1部分：轻型汽车',
 'standard_name_evidence_type':'2023年第32号公告技术要求附件中的正式标准引用；未取回SAMR标准登记页',
 'standard_release_date':None,'standard_implementation_date':None,'standard_current_status':None,'replaces_standard':None,
 'standard_registry_url':STD_QUERY,'standard_registry_response_sha256':None,
 'standard_registry_retrieval_status':'blocked_by_execution_egress_proxy_403',
 'standard_registry_missing_fields':['standard_release_date','standard_implementation_date','standard_current_status','replaces_standard','standard_registry_response_sha256'],
 'policy_number':'2023年第32号',
 'policy_title':'工业和信息化部 财政部 税务总局关于调整减免车辆购置税新能源汽车产品技术要求的公告',
 'policy_signed_date':'2023-12-07','policy_page_registered_public_date':'2023-12-11',
 'policy_page_visible_time':'2023-12-11 14:30','policy_page_meta_PubDate':'2023-12-11 15:00',
 'global_first_online_at_certified':False,
 'policy_primary_url':POLICY_URL,
 'policy_primary_sha256':hashlib.sha256((P/'policy32_primary.html').read_bytes()).hexdigest(),
 'policy_attachment_url':PDF_URL,'policy_attachment_sha256':sha,'policy_attachment_bytes':len(b),'policy_attachment_pages':len(doc),
 'attachment_sha256_matches_compact_input':True,
 'passenger_low_temperature_exception':{'page_1based':1,'clause':'一、新能源乘用车技术要求，第4项','test_method_standard':'GB/T 18386.1-2021','test_method_annex':'附录A','max_range_degradation_percent':35,'min_battery_system_quality_energy_density_Wh_per_kg':95,'min_range_km':120,'raw_quote_whitespace_normalized':passage,'does_not_waive_speed_and_energy_consumption':True},
 'N1_truck_low_temperature_exception':{'page_1based':3,'clause':'三、新能源货车和专用车技术要求，第2项','test_method_standard':'GB/T 18386.1-2021','test_method_annex':'附录A','max_range_degradation_percent':35,'min_battery_system_quality_energy_density_Wh_per_kg':95,'passenger_min_range_120_km_applies':False},
 'vehicle_level_compliance_evidence_collected':False,
 'model_low_temperature_eligibility_should_remain':'unknown_without_config_matched_Annex_A_report',
 'verification':['attachment_format_and_3_pages','full_sha256_matches_input','passenger_clause_text_found_exact_after_whitespace_normalization','N1_clause_text_found','official_primary_date_fields_found'],
}
(P/'standard_policy32_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
rows=[
 ['standard_number','GB/T 18386.1-2021','observed',PDF_URL,sha,1,'一、第4项'],
 ['standard_name',metadata['standard_name'],'observed_policy_reference',PDF_URL,sha,1,'一、第4项'],
 ['standard_release_date','','unknown_network_blocked',STD_QUERY,'','',''],
 ['standard_implementation_date','','unknown_network_blocked',STD_QUERY,'','',''],
 ['standard_current_status','','unknown_network_blocked',STD_QUERY,'','',''],
 ['replaces_standard','','unknown_network_blocked',STD_QUERY,'','',''],
 ['policy_signed_date','2023-12-07','observed',POLICY_URL,metadata['policy_primary_sha256'],'','成文日期'],
 ['policy_page_registered_public_date','2023-12-11','observed',POLICY_URL,metadata['policy_primary_sha256'],'','发布日期'],
 ['passenger_low_temperature_max_degradation_percent',35,'observed',PDF_URL,sha,1,'一、第4项'],
 ['passenger_low_temperature_min_density_Wh_per_kg',95,'observed',PDF_URL,sha,1,'一、第4项'],
 ['passenger_low_temperature_min_range_km',120,'observed',PDF_URL,sha,1,'一、第4项'],
 ['N1_low_temperature_max_degradation_percent',35,'observed',PDF_URL,sha,3,'三、第2项'],
 ['N1_low_temperature_min_density_Wh_per_kg',95,'observed',PDF_URL,sha,3,'三、第2项'],
]
with (P/'标准与低温条款_可引用字段.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['field','value','evidence_status','source_url','source_sha256','page_1based','locator']);w.writerows(rows)
(P/'README.md').write_text('''本轮已补回2023年第32号公告官方正文和原始技术要求附件，并取回官方解读。附件 SHA256 与用户精简包中的政策32 PDF 完全一致，属于正式来源链补齐，不增加车型检测记录。

官方主发布页明确成文日为2023-12-07，登记发布日期为2023-12-11；页面正文时间14:30与 meta PubDate 15:00 不同，因此仅采用一致的日期，不认证全球最早上线时刻。

纯电动乘用车低温例外见附件第1页、一第4项：按 GB/T 18386.1-2021 附录A 检测，低温里程衰减率不超过35%，可采用能量密度至少95 Wh/kg、续驶里程至少120 km的门槛；车速及电耗要求仍须满足。N1纯电动货车低温条款见第3页、三第2项，不能套用乘用车120 km门槛。

GB/T 18386.1-2021 的标准编号、名称和附录A引用已由正式政策附件确认。SAMR全国标准信息平台（std.samr.gov.cn）和国家标准全文公开系统（openstd.samr.gov.cn）访问被当前执行环境代理以403拒绝，SAC、SAMR主站及政府检索站同样受阻。未取得标准登记页，因此标准发布日期、实施日期、现行状态、代替标准均保留为空；不凭记忆填值。请求URL、时间及错误已保留在 receipt JSON 中。配置草稿的域名调整尚未在当前运行环境生效。

未取得具体车型与配置对应的附录A低温检测报告，不将35%、95 Wh/kg、120 km门槛直接转成车型合规标签；同型号的其他配置不能代替配置匹配的检测证据。

可引用字段见 `标准与低温条款_可引用字段.csv`，完整结构化说明见 `standard_policy32_metadata.json`；HTTP正文、PDF和SHA收据已保留。`build_metadata.py` 可重跑校验。
''',encoding='utf-8')
print(json.dumps({'status':'partial_standard_registry_blocked_policy_source_closed','pdf_bytes':len(b),'pdf_sha256':sha,'pages':len(doc),'metadata_fields_observed':9,'registry_fields_unknown':4,'checks_passed':5},ensure_ascii=False))
