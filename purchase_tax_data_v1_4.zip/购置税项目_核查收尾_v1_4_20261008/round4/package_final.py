#!/usr/bin/env python3
"""Portable delivery of current data and review evidence; originals separate."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREFIX='购置税项目_核查收尾_v1_4_20261008'
TARGET=Path('/workspace')/(PREFIX+'.zip')
PREVIOUS=Path('/workspace/购置税项目_补采与修订_v1_3_20261008.zip')
manifest=[];names=set()
def digest(b):return hashlib.sha256(b).hexdigest()

def add(z,rel,b):
    assert rel not in names,rel
    names.add(rel);z.writestr(PREFIX+'/'+rel,b)
    manifest.append(dict(relative_path=rel,bytes=len(b),sha256=digest(b)))

assert digest(PREVIOUS.read_bytes())=='f127efe681411232161fa32a650c3907eca690fc24a539e168277f6d8db07c4b'
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    # Include exact prior evidence and v1.3 baseline for delta reproduction.
    with zipfile.ZipFile(PREVIOUS) as prior:
        assert prior.testzip() is None
        for info in prior.infolist():
            if info.is_dir():continue
            rel=info.filename.split('/',1)[1]
            if rel in {'README.md','交付文件_SHA256.txt'}:continue
            add(z,rel,prior.read(info.filename))
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=str(p.relative_to(ROOT))
        if rel in {'core_package_result_v1_4.json','public_gaps/batch26_tax_catalogue.docx','public_gaps/batch26_tax_withdrawal.docx'}:continue
        add(z,'round4/'+rel,p.read_bytes())
    add(z,'README.md',('''# 购置税项目核查收尾 v1.4

当前数据与材料清单从 [round4/README.md](round4/README.md) 开始。规范数据在 round4/data_v1_4；round3 是只读前轮证据和 v1.3 基准，input 是未经修改的精简输入 ZIP。不要把前轮历史缺口当成本轮仍缺。

另有《购置税项目_公开原件104份及推荐资料_v1_4_20261008.zip》，与主包解压到同一父目录并合并同名顶层文件夹即可。该原件包含104份历史同SHA原件、3份推荐PDF和2份第26批官方异字节版本。

两包均小于32MiB；交付文件_SHA256.txt逐文件给出指纹。本轮仍缺第1批PDF和第64批DOC，可从用户先前已上传完整归档提取；其他材料按用途见round4/requirements/需要用户亲自提供的数据.md。
''').encode())
    z.writestr(PREFIX+'/交付文件_SHA256.txt',''.join(r['sha256']+'  '+r['relative_path']+'\n' for r in manifest))
with zipfile.ZipFile(TARGET) as z:
    assert z.testzip() is None
    for r in manifest:
        b=z.read(PREFIX+'/'+r['relative_path']);assert len(b)==r['bytes'] and digest(b)==r['sha256']
assert TARGET.stat().st_size<32*1024*1024
result=dict(path=str(TARGET),bytes=TARGET.stat().st_size,sha256=digest(TARGET.read_bytes()),
    files=len(manifest)+1,all_members_crc_and_sha_verified=True,original_input_preserved=True,
    canonical_data_root=PREFIX+'/round4/data_v1_4',historical_baseline_included='round3/reconstruction/data_v1_3')
(ROOT/'core_package_result_v1_4.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
