# 购置税项目核查收尾 v1.4

先读[核查收尾报告](核查收尾报告_v1_4_20261008.md)，需要本人提供的数据与具体型号见[材料清单](requirements/需要用户亲自提供的数据.md)。当前规范数据在[data_v1_4](data_v1_4/README.md)，其余目录保存原件回执、独立枚举、逐字段差异、修订定位、采集模板及验证代码。

当前完成：历史原件104/106同SHA；可得目录95/95全部独立逐表枚举；历史撤销9/9、3007行及另2份2020行全部核查。无法核历史原件的仅第1批PDF、第64批DOC，可从此前已经上传的大包提取。推荐端29个缺单值版本与风险集381个单值不足型号均已补做保守区间核查。科学定义、成员、冻结单值及月度面板未变。

主包包括round3前轮证据和只读v1.3基准、原始精简输入ZIP，以及round4本轮v1.4数据；使用round4判断当前状态，round3的102份原件及较旧缺口是历史记录。独立原件包与主包解压到同一父目录、合并同名顶层文件夹即可补齐原件文件，109个原件/推荐/异字节版本均有SHA。

复核主要入口（Python依赖继承前轮，目录枚举另用PyMuPDF及xlrd/LibreOffice）：

```bash
python round4/build_interval_audit.py
python round4/recommendation_interval/build_recommendation_interval.py
python round4/build_final_version.py
python round4/validate_interval_bounds.py
python round3/validation/validate_reconstructed_data.py round4/data_v1_4 round4/validation/independent_scientific
```

本环境原件索引和部分历史脚本保存了`/workspace/purchase_tax_audit`绝对路径；更换目录后需将该前缀映射至解压目录。
