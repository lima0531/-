import collect,json
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor
rows=json.loads((collect.ROOT/'batch26_attachment_discovery.json').read_text())
selected=[r for r in rows if ('免征车辆购置税的新能源汽车车型目录' in r['label'] or '撤销《免征' in r['label']) and 'c7709375' not in r['url']]
receipts=[]
def f(r):
 name='batch26_'+r['url'].rsplit('/',1)[-1];rec=collect.fetch(r['url'],name);rec['links']=[dict(r,system='免征目录',batch='26')];return rec
with ThreadPoolExecutor(max_workers=2) as ex:
 for rec in ex.map(f,selected):receipts.append(rec);print(json.dumps({k:v for k,v in rec.items() if k!='response_headers'},ensure_ascii=False),flush=True)
(collect.ROOT/'batch26_download_manifest.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
