#!/usr/bin/env python3
"""Verify final source repairs and their changes against preserved inputs."""
import collections
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'reconstruction/data_v1_3'
BASE=ROOT/'versioning/data_v1_2'
ORIGINAL=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def index(rows,*fields):
    result={tuple(r[k] for k in fields):r for r in rows}
    assert len(result)==len(rows)
    return result

checks=[]
def check(name,value):checks.append({'name':name,'status':'PASS' if value else 'FAIL'})

events=read(DATA/'研究数据/资格事件_重建去重表.csv')
links=read(DATA/'研究数据/资格事件_逐原件连接.csv')
added=read(ROOT/'coverage/new_withdrawal_events.csv')
repairs=read(ROOT/'coverage/batch27_corrected_events_47.csv')
eventmap=index(events,'event_id')
check('73_new_official_events_exactly_present',len(added)==73 and all(eventmap[(r['event_id'],)]==r for r in added))
check('47_verified_batch_date_repairs_exactly_present',len(repairs)==47 and all(eventmap[(r['event_id'],)]==r for r in repairs))
linkmap=index(links,'event_id','source_record_id')
fixedlinks=read(ROOT/'coverage/batch27_corrected_source_links_47.csv')
check('47_source_link_ids_and_repairs_preserved',all(linkmap[(r['event_id'],r['source_record_id'])]==r for r in fixedlinks))
check('expected_event_and_source_counts',len(events)==6801 and len(links)==6873)

panel=read(DATA/'研究数据/车型月度面板_2022至2024.csv')
oldpanel=index(read(ORIGINAL/'研究数据/车型月度面板_2022至2024.csv'),'model_key','month')
monthly_changes=[r for r in panel if r['state']!=oldpanel[(r['model_key'],r['month'])]['state']]
forward=[r for r in monthly_changes if r['catalogue_active_observed']=='0']
restored=[r for r in monthly_changes if r['catalogue_active_observed']=='1']
check('2628_missed_withdrawal_and_23_restored_months',len(forward)==2628 and len(restored)==23 and {r['model_key'] for r in restored}=={'CSA6461FBEV3'})
oldrisk=index(read(BASE/'研究数据/公告前风险集_连续处理强度输入.csv'),'model_key')
risk=read(DATA/'研究数据/公告前风险集_连续处理强度输入.csv')
riskset={r['model_key'] for r in risk if r['membership_announcement_cohort']=='1' and r['announcement_active_observed']=='1'}
ready=[r for r in risk if r['descriptive_continuous_did_input_ready']=='1']
check('frozen_exposure_exact_strings_unchanged',all(r[c]==oldrisk[(r['model_key'],)][c] for r in risk for c in ['continuous_exposure_range','continuous_exposure_density_proxy','continuous_exposure_joint_max']))
check('final_risk_and_ready_source_backed_counts',len(riskset)==2805 and len(ready)==2424)
check('restored_model_ready_with_original_values',next(r for r in risk if r['model_key']=='CSA6461FBEV3')['descriptive_continuous_did_input_ready']=='1')
layers=read(DATA/'官方技术清单/五档数值层_逐型号归属与判据.csv')
check('canonical_layer_keys_equal_new_risk',len(layers)==len(riskset) and {r['model_key'] for r in layers}==riskset)
check('canonical_outside_withdrawals_seven',len(read(DATA/'官方技术清单/2024撤销观察_风险集外型号.csv'))==7)

params=index(read(DATA/'研究数据/参数版本_原值与计算代理.csv'),'record_id')
oldparams=index(read(ORIGINAL/'研究数据/参数版本_原值与计算代理.csv'),'record_id')
datecols={'publish_date_exact','public_date_lower_bound','public_date_upper_bound','date_basis'}
check('all_parameter_source_fields_except_date_metadata_unchanged',params.keys()==oldparams.keys() and all(r[c]==oldparams[k][c] for k,r in params.items() for c in r if c not in datecols))
for rel in ['研究数据/样本成员重建.csv','1991基线/1991_独立重建名单.csv','官方技术清单/官方不符合技术要求_全表4160行.csv']:
    check('preserved_'+rel,hashlib.sha256((DATA/rel).read_bytes()).hexdigest()==hashlib.sha256((ORIGINAL/rel).read_bytes()).hexdigest())
source_checks=[]
for src in json.loads((ROOT/'coverage/new_withdrawal_sources.json').read_text()):
    b=Path(src['source_file']).read_bytes()
    source_checks.append(hashlib.sha256(b).hexdigest()==src['source_sha256'] and len(b)==src['source_bytes'])
check('two_new_raw_official_sources_sha_and_bytes',all(source_checks) and len(source_checks)==2)
input_checks=[]
for line in (ORIGINAL/'文件清单_SHA256.txt').read_text(encoding='utf-8-sig').splitlines():
    sha,rel=line.split('  ',1);input_checks.append(hashlib.sha256((ORIGINAL/rel).read_bytes()).hexdigest()==sha)
check('63_original_delivery_entries_still_unchanged',len(input_checks)==63 and all(input_checks))
result={'checks':checks,'pass':sum(r['status']=='PASS' for r in checks),'fail':sum(r['status']=='FAIL' for r in checks),
        'state_changed_monthly_rows':len(monthly_changes),'active_to_withdrawn_monthly_rows':len(forward),
        'withdrawn_to_active_monthly_rows':len(restored),'risk_models':len(riskset),'ready_models':len(ready),
        'ready_cycle_explicit_cltc':sum(r['range_cycle_explicit']=='CLTC' for r in ready),
        'ready_cycle_unmarked':sum(not r['range_cycle_explicit'] for r in ready),
        'numeric_layers':dict(collections.Counter(r['numeric_layer'] for r in layers))}
(ROOT/'validation/final_delta_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
raise SystemExit(1 if result['fail'] else 0)
