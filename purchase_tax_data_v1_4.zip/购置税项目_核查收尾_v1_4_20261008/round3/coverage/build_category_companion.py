"""Verify external product-name evidence at model grain without certifying configurations."""
import csv,json,hashlib,re,unicodedata,collections
from pathlib import Path
import fitz
R=Path(__file__).resolve().parent
B=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008');T=R.parent/'technical'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s)).upper()
def write(name,rows):
 with (R/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
cohort=read(B/'研究数据/样本成员重建.csv');keys={x['model_key'] for x in cohort};params=read(B/'研究数据/参数版本_原值与计算代理.csv');recs=read(B/'推荐参数/推荐参数_配置版本长表.csv');off=read(B/'官方技术清单/官方不符合技术要求_全表4160行.csv')
# Three recommendation originals were newly fetched and hash matched the supplied source records.
texts={};hashes={}
for sid in sorted(set(x['source_id'] for x in recs)):
 p=T/(sid+'_original.pdf');hashes[sid]=hashlib.sha256(p.read_bytes()).hexdigest()
 d=fitz.open(p);texts[sid]=[norm(page.get_text()) for page in d]
checks=[];long=[]
for x in recs:
 sid=x['source_id'];assert x['source_sha256']==hashes[sid]
 page=int(x['page_first_1based'])-1;window=texts[sid][max(0,page-1):min(page+2,len(texts[sid]))];target=norm(x['heading_raw'])
 checked=target in ''.join(window);assert checked,(sid,x['model_key'],page+1)
 # Heading may end on the previous page while the configuration table starts on page_first.
 header_pages=[i+1 for i,t in enumerate(texts[sid]) if norm(x['model_raw']) in t and norm(x['firm_raw']) in t and norm(x['brand_raw']) in t]
 check={'observation_version_key':x['observation_version_key'],'model_key':x['model_key'],'source_id':sid,'source_sha256':hashes[sid],'source_original':str(T/(sid+'_original.pdf')),'table_first_page_1based':str(page+1),'heading_candidate_pages_1based':';'.join(map(str,header_pages)),'firm_raw':x['firm_raw'],'model_raw':x['model_raw'],'product_name_raw':x['product_name_raw'],'retained_full_heading_matches_original_text':'1','match_rule':'NFKC/remove whitespace/uppercase; entire retained product heading must occur in a three-page window around the table first page','cohort_member':str(int(x['model_key'] in keys))}
 checks.append(check)
 if x['model_key'] in keys:long.append({'model_key':x['model_key'],'source_kind':'推荐目录官方PDF','source_id':sid,'source_file':str(T/(sid+'_original.pdf')),'source_sha256':hashes[sid],'source_public_date':x['source_public_date'],'source_location':'heading pages '+check['heading_candidate_pages_1based']+'; configuration table first page '+str(page+1),'firm_raw':x['firm_raw'],'product_name_raw':x['product_name_raw'],'explicit_bev_passenger_name':str(int('纯电动' in norm(x['product_name_raw']) and ('乘用车' in norm(x['product_name_raw']) or '轿车' in norm(x['product_name_raw'])))),'raw_text_original_verified':'1','full_configuration_match_verified':'0','entity_register_identity_verified':'0'})
# Reuse the previous independent 4160-row extraction only after equality of all identity/name fields.
off_ind=read(Path('/workspace/purchase_tax_audit/round2/pdf/official_list_independently_enumerated_4160.csv')) if Path('/workspace/purchase_tax_audit/round2/pdf/official_list_independently_enumerated_4160.csv').exists() else None
if off_ind is None:
 candidates=list(Path('/workspace/purchase_tax_audit/round2/pdf').glob('*4160*.csv'));assert len(candidates)==1,candidates;off_ind=read(candidates[0])
# Inspector scripts store the same raw names; compare common data identity fields to the original CSV.
common=[k for k in ['seq','model_key','firm_raw','product_name_raw'] if k in off_ind[0]];assert len(common)>=3,off_ind[0]
assert [[x[k] for k in common] for x in off]==[[x[k] for k in common] for x in off_ind]
for x in off:
 if x['model_key'] not in keys:continue
 product=norm(x['product_name_raw']);explicit='纯电动' in product and ('乘用车' in product or '轿车' in product)
 long.append({'model_key':x['model_key'],'source_kind':'官方不符合技术要求清单PDF','source_id':'official_nonconforming_20240118','source_file':str(B/'原件/20240118_不符合技术要求的车型清单.pdf'),'source_sha256':x['source_sha256'],'source_public_date':x['official_public_date'],'source_location':'page '+x['page_1based']+'; seq '+x['seq'],'firm_raw':x['firm_raw'],'product_name_raw':x['product_name_raw'],'explicit_bev_passenger_name':str(int(explicit)),'raw_text_original_verified':'1','full_configuration_match_verified':'0','entity_register_identity_verified':'0'})
by=collections.defaultdict(list);firms=collections.defaultdict(set);contexts=collections.defaultdict(set)
for x in long:by[x['model_key']].append(x)
for x in params:
 if x['firm_raw']:firms[x['model_key']].add(norm(x['firm_raw']))
 if x['firm_context_candidate']:contexts[x['model_key']].add(norm(x['firm_context_candidate']))
comp=[]
for x in cohort:
 k=x['model_key'];ev=by[k];explicit=any(e['explicit_bev_passenger_name']=='1' for e in ev)
 match=any(norm(e['firm_raw']) in firms[k] for e in ev);candidate=any(norm(e['firm_raw']) in contexts[k] for e in ev)
 comp.append({'model_key':k,'input_vehicle_class_independently_certified':x['vehicle_class_independently_certified'],'external_original_evidence_rows':str(len(ev)),'external_source_ids':';'.join(sorted(set(e['source_id'] for e in ev))),'external_product_name_values_json':json.dumps(sorted(set(e['product_name_raw'] for e in ev)),ensure_ascii=False),'external_firm_values_json':json.dumps(sorted(set(e['firm_raw'] for e in ev)),ensure_ascii=False),'model_bev_passenger_product_name_supported':str(int(explicit)),'firm_name_text_matches_tax_explicit_firm_raw':str(int(match)),'firm_name_text_matches_tax_context_candidate':str(int(candidate)),'has_recommendation_evidence_preannouncement':str(int(any(e['source_kind']=='推荐目录官方PDF' and e['source_public_date']<='2023-12-10' for e in ev))),'has_postannouncement_official_list_evidence':str(int(any(e['source_kind']=='官方不符合技术要求清单PDF' for e in ev))),'external_evidence_status':'官方原件明确纯电乘用车/轿车产品名称' if explicit else ('已找到官方原件但产品名称不足明确分类' if ev else '本轮外部名单未取得该型号产品名称证据'),'configuration_identity_certified':'0','enterprise_register_identity_certified':'0','M1_homologation_certificate_verified':'0','input_cohort_modified':'0','scope':'型号级的官方企业/产品名称文本佐证；不能认证跨目录同配置、法定M1合格证或制造日期'})
write('recommendation_category_heading_verification_285.csv',checks);write('external_category_evidence_long_874.csv',long);write('cohort_external_category_companion_3328.csv',comp)
summary={'cohort_models':len(comp),'recommendation_heading_rows_verified':len(checks),'recommendation_originals':len(texts),'external_evidence_rows':len(long),'cohort_models_with_any_external_evidence':sum(int(x['external_original_evidence_rows'])>0 for x in comp),'cohort_models_with_explicit_bev_passenger_product_names':sum(x['model_bev_passenger_product_name_supported']=='1' for x in comp),'cohort_models_ambiguous_name_only':sum(int(x['external_original_evidence_rows'])>0 and x['model_bev_passenger_product_name_supported']=='0' for x in comp),'cohort_models_without_external_evidence':sum(int(x['external_original_evidence_rows'])==0 for x in comp),'models_with_explicit_tax_firm_text_match':sum(x['firm_name_text_matches_tax_explicit_firm_raw']=='1' for x in comp),'models_with_tax_context_firm_text_match':sum(x['firm_name_text_matches_tax_context_candidate']=='1' for x in comp),'preannouncement_recommendation_model_evidence':sum(x['has_recommendation_evidence_preannouncement']=='1' for x in comp),'input_cohort_modified':False,'input_external_certified_flags_modified':False,'configuration_identity_certificates_obtained':0,'M1_certificates_obtained':0}
(R/'category_companion_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
