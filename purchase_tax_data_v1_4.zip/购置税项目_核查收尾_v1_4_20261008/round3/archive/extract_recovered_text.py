#!/usr/bin/env python3
"""Make searchable text companions; this is not independent table enumeration.

PDF: text per page with PyMuPDF. DOCX: ordered XML paragraphs, table cells
retain tabs. OLE: LibreOffice headless text conversion of a SHA-checked copy
with true .doc suffix, in an isolated writable task profile.
"""
import concurrent.futures,csv,hashlib,json,os,signal,shutil,subprocess,tempfile,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
import fitz,xlrd

ROOT=Path(__file__).resolve().parent
TEXT=ROOT/'text';TEXT.mkdir(exist_ok=True)
SOFFICE='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

def sha(b):return hashlib.sha256(b).hexdigest()
def process(row):
    result={k:row[k] for k in ['scope','system','source_file','source_sha256','recovery_status']}
    if row['recovery_status']!='sha256_exact':
        result.update(text_status='source_not_recovered',independent_table_enumeration=False);return result
    source=Path(row['recovered_path']);data=source.read_bytes()
    if sha(data)!=row['source_sha256']:raise ValueError('Input fingerprint changed: '+str(source))
    output=TEXT/(row['source_file']+'.txt');text=''
    try:
        if data.startswith(b'%PDF-'):
            result['detected_format']='PDF';result['reader']='PyMuPDF per-page text, sort=True'
            doc=fitz.open(source);pieces=[];empty=[]
            for i,p in enumerate(doc):
                t=p.get_text('text',sort=True);pieces.append(f'\n===== PDF PAGE {i+1} =====\n'+t)
                if not t.strip():empty.append(i+1)
            text=''.join(pieces);result.update(page_count=len(doc),pages_without_text=empty);doc.close()
        elif data[:4]==b'PK\x03\x04':
            result['detected_format']='ZIP_DOCX';result['reader']='ordered word/document.xml paragraphs and table rows'
            with zipfile.ZipFile(source) as z:body=ET.fromstring(z.read('word/document.xml')).find('w:body',NS)
            pieces=[]
            for item in body:
                if item.tag.endswith('}p'):pieces.append(''.join(item.itertext()) if not item.findall('.//w:t',NS) else ''.join(t.text or '' for t in item.findall('.//w:t',NS)))
                elif item.tag.endswith('}tbl'):
                    for tr in item.findall('w:tr',NS):pieces.append('\t'.join(' '.join(''.join(t.text or '' for t in p.findall('.//w:t',NS)) for p in tc.findall('.//w:p',NS)) for tc in tr.findall('w:tc',NS)))
            text='\n'.join(pieces)
        elif source.suffix.lower()=='.xls':
            result['detected_format']='OLE_EXCEL';result['reader']='xlrd native BIFF worksheet cells'
            book=xlrd.open_workbook(source);pieces=[]
            for sheet in book.sheets():
                pieces.append(f'\n===== SHEET {sheet.name} =====\n')
                pieces.extend('\t'.join(str(value) for value in sheet.row_values(i)) for i in range(sheet.nrows))
            text='\n'.join(pieces);result['sheet_count']=book.nsheets
        elif data[:8]==bytes.fromhex('d0cf11e0a1b11ae1') and len(data)>16*1024*1024:
            from word_piece_text import extract
            text,proof=extract(source)
            result.update(detected_format='OLE_WORD',reader=proof['reader'],main_story_utf16_units=proof['main_story_utf16_units'],word_piece_reader_proof=proof)
        elif data[:8]==bytes.fromhex('d0cf11e0a1b11ae1'):
            result['detected_format']='OLE_WORD';result['reader']='LibreOffice txt:Text, binary-format-correct .doc copy'
            with tempfile.TemporaryDirectory(prefix='purchase_tax_extract_',dir='/tmp') as temp:
                d=Path(temp);work=d/'input.doc';work.write_bytes(data);target=d/'out';target.mkdir()
                timeout=180 if len(data)>16*1024*1024 else 50
                proc=subprocess.Popen([SOFFICE,'-env:UserInstallation='+str((d/'profile').as_uri()),'--headless','--convert-to','txt:Text','--outdir',str(target),str(work)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
                try:stdout,stderr=proc.communicate(timeout=timeout)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.communicate(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.communicate()
                    raise
                result.update(converter_exit=proc.returncode,converter_stdout=stdout[-2000:],converter_stderr=stderr[-2000:])
                generated=target/'input.txt'
                if not generated.exists():raise RuntimeError('Converter produced no text')
                text=generated.read_text(encoding='utf-8-sig',errors='replace')
        else:raise ValueError('Unrecognized source signature')
        output.write_text(text,encoding='utf-8');result.update(text_status='text_available' if text.strip() else 'no_extractable_text',text_path=str(output),text_bytes=output.stat().st_size,text_sha256=sha(output.read_bytes()),text_characters=len(text),independent_table_enumeration=False)
    except Exception as exc:result.update(text_status='extraction_error',error=f'{type(exc).__name__}: {exc}',independent_table_enumeration=False)
    return result

def main():
    rows=list(csv.DictReader((ROOT/'106原件公开回收清单.csv').open(encoding='utf-8-sig')))
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        jobs={executor.submit(process,r):r for r in rows}
        for job in concurrent.futures.as_completed(jobs):
            result=job.result();results.append(result);print(len(results),result['source_file'],result['text_status'],flush=True)
    results.sort(key=lambda r:(r['scope'],r['system'],r['source_file']))
    (ROOT/'recovered_text_manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    (ROOT/'recovered_text_summary.json').write_text(json.dumps({'originals':len(results),'text_available':sum(r['text_status']=='text_available' for r in results),'extraction_errors':sum(r['text_status']=='extraction_error' for r in results),'not_recovered':sum(r['text_status']=='source_not_recovered' for r in results),'independent_table_enumeration':False},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
