#!/usr/bin/env python3
"""Independent, read-only audit of archived model joins, dates and numeric layers.

Uses Python's standard library only. Does not import or execute bundled audit code.
Input CSVs remain unchanged; all artifacts are written to the supplied output path.
"""
import argparse
import collections
import csv
import datetime as dt
from decimal import Decimal, localcontext
import hashlib
import json
from pathlib import Path
import sys
import unicodedata


def normalise(value):
    return ''.join(unicodedata.normalize('NFKC', value).split()).upper()


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f'duplicate column headers: {path}')
        return list(reader)


def dup_keys(rows, columns):
    counts = collections.Counter(tuple(row[column] for column in columns) for row in rows)
    return [{'key': list(key), 'rows': count} for key, count in counts.items() if count > 1]


def index_unique(rows, column):
    duplicates = dup_keys(rows, [column])
    if duplicates:
        raise ValueError(f'nonunique {column}: {duplicates[:5]}')
    return {row[column]: row for row in rows}


def possible_latest(rows, cutoff):
    """Keep all observations not necessarily followed by a certainly prior observation.

    A blank lower bound has no earliest known date. An observation is potentially
    before cutoff if its lower bound does not rule that out, and certainly before
    cutoff if its upper bound is at or before cutoff. Observation A is necessarily
    followed by B when B is certainly before cutoff and B.lower > A.upper.
    Exact same-day observations remain tied; no arbitrary row-order tie breaker.
    """
    potential = [row for row in rows
                 if not row['public_date_lower_bound'] or row['public_date_lower_bound'] <= cutoff]
    certain = [row for row in potential if row['public_date_upper_bound'] <= cutoff]
    latest = [row for row in potential
              if not any(other['public_date_lower_bound']
                         and other['public_date_lower_bound'] > row['public_date_upper_bound']
                         for other in certain)]
    return potential, certain, latest


def observed_state(events, cutoff):
    potential, certain, latest = possible_latest(events, cutoff)
    if not potential:
        active = '0'
    elif not certain:
        active = ''
    else:
        actions = {row['action'] for row in latest}
        active = '1' if actions == {'列入'} else '0' if actions == {'撤销'} else ''
    return {'active': active, 'potential_count': len(potential), 'latest_count': len(latest),
            'certain_count': len(certain), 'latest_ids': sorted(row['event_id'] for row in latest)}


def number(value):
    if value == '':
        return None
    result = Decimal(value)
    if not result.is_finite():
        raise ValueError(f'nonfinite number: {value!r}')
    return result


def density_from_energy_mass(row):
    energy = number(row['battery_energy_point'])
    mass = number(row['battery_mass_point'])
    if energy is None or mass is None or mass <= 0:
        return None
    with localcontext() as context:
        context.prec = 28
        return Decimal(1000) * energy / mass


def unanimous_point(rows, all_observed, getter):
    values = {getter(row) for row in rows}
    if all_observed and len(values) == 1 and None not in values:
        return next(iter(values))
    return None


def numeric_layer(ready, distance, density):
    if not ready:
        return '单值不足'
    if distance < 200 and density < 125:
        return '两项数值低于常规阈值'
    if distance < 200:
        return '续航单项低于常规阈值'
    if density < 125:
        return '密度代理单项低于常规阈值'
    return '两项数值均达到常规阈值'


def write_csv(path, rows):
    if not rows:
        raise ValueError('This audit expects nonempty exported exception groups')
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_root', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.input_root.resolve()
    out = args.output.resolve()
    if out == root or root in out.parents:
        raise ValueError('Output must be outside the input package')
    out.mkdir(parents=True, exist_ok=True)
    paths = {
        'members': '研究数据/样本成员重建.csv',
        'events': '研究数据/资格事件_重建去重表.csv',
        'event_sources': '研究数据/资格事件_逐原件连接.csv',
        'parameters': '研究数据/参数版本_原值与计算代理.csv',
        'snapshots': '研究数据/重建样本_两截点参数与暴露.csv',
        'states': '研究数据/重建样本_三截点状态.csv',
        'risk_input': '研究数据/公告前风险集_连续处理强度输入.csv',
        'trajectory': '研究数据/政策后资格轨迹与重申报标签.csv',
        'official': '官方技术清单/官方不符合技术要求_全表4160行.csv',
        'stored_layers': '官方技术清单/五档数值层_逐型号归属与判据.csv',
        'stored_join': '官方技术清单/重建3328_官方清单标记与资格轨迹.csv',
        'stored_outside_withdrawal': '官方技术清单/2024撤销观察_风险集外型号.csv',
    }
    data = {key: read_csv(root / value) for key, value in paths.items()}
    input_hashes = {value: hashlib.sha256((root / value).read_bytes()).hexdigest()
                    for value in paths.values()}
    members = index_unique(data['members'], 'model_key')
    official = index_unique(data['official'], 'model_key')
    events = index_unique(data['events'], 'event_id')
    parameters = index_unique(data['parameters'], 'record_id')
    risk_input = index_unique(data['risk_input'], 'model_key')
    trajectory = index_unique(data['trajectory'], 'model_key')
    stored_join = index_unique(data['stored_join'], 'model_key')
    stored_layers = index_unique(data['stored_layers'], 'model_key')
    member_keys = set(members)
    issues = collections.defaultdict(list)

    def mismatch(category, model_key, observed, recomputed):
        if observed != recomputed:
            issues[category].append({'model_key': model_key,
                                     'archived_value': observed,
                                     'recomputed_value': recomputed})

    def numeric_mismatch(category, model_key, observed, recomputed):
        # Decimal numeric equality ignores harmless differences in trailing zeroes.
        if observed != recomputed:
            issues[category].append({'model_key': model_key,
                                     'archived_value': None if observed is None else str(observed),
                                     'recomputed_value': None if recomputed is None else str(recomputed)})

    uniqueness = {}
    key_rules = {
        'members': ['model_key'], 'official': ['model_key'], 'events': ['event_id'],
        'event_natural_key': ['model_key', 'system', 'event_batch', 'action'],
        'event_sources': ['event_id', 'source_record_id'], 'parameters': ['record_id'],
        'snapshots': ['model_key', 'cutoff'], 'states': ['model_key', 'cutoff'],
        'risk_input': ['model_key'], 'trajectory': ['model_key'],
        'stored_layers': ['model_key'], 'stored_join': ['model_key'],
    }
    for key, columns in key_rules.items():
        rows = data['events' if key == 'event_natural_key' else key]
        duplicates = dup_keys(rows, columns)
        uniqueness[key] = {'key': columns, 'rows': len(rows),
                           'distinct_keys': len(rows) - sum(row['rows'] - 1 for row in duplicates),
                           'duplicates': duplicates}
        if duplicates:
            issues['duplicate_keys'].append({'table': key, 'duplicates': duplicates})
    for name, rows in data.items():
        for row in rows:
            if 'model_key' not in row:
                continue
            key = row['model_key']
            if normalise(key) != key:
                issues['noncanonical_key'].append({'table': name, 'model_key': key})
            if 'model_raw' in row and normalise(row['model_raw']) != key:
                issues['raw_key_mismatch'].append({'table': name, 'model_key': key,
                                                   'normalised_raw': normalise(row['model_raw'])})
    for table in ['risk_input', 'trajectory', 'stored_join']:
        mismatch('model_coverage', table, sorted(set(index_unique(data[table], 'model_key'))),
                 sorted(member_keys))
    for row in members.values():
        if row['admitted_to_analysis_cohort'] != '1' or row['classification_conflict_quarantined'] != '0':
            issues['member_admission'].append({'model_key': row['model_key']})

    event_by_model = collections.defaultdict(list)
    parameter_by_model = collections.defaultdict(list)
    for row in events.values():
        event_by_model[row['model_key']].append(row)
        if row['model_key'] not in members:
            issues['event_orphan_model'].append({'event_id': row['event_id'], 'model_key': row['model_key']})
        for field in ['public_date_lower_bound', 'public_date_upper_bound', 'publish_date_exact']:
            if row[field]:
                dt.date.fromisoformat(row[field])
        if not row['public_date_upper_bound']:
            raise ValueError(f'event with unknown upper bound: {row["event_id"]}')
        if row['public_date_lower_bound'] and row['public_date_lower_bound'] > row['public_date_upper_bound']:
            issues['date_interval_order'].append({'event_id': row['event_id']})
    for row in parameters.values():
        if row['admitted_to_analysis_cohort'] == '1':
            parameter_by_model[row['model_key']].append(row)
            if row['model_key'] not in members:
                issues['parameter_orphan_model'].append({'record_id': row['record_id']})
        numeric_mismatch('source_density_formula', row['model_key'],
                         number(row['density_proxy_point']), density_from_energy_mass(row))
        for field in ['public_date_lower_bound', 'public_date_upper_bound']:
            if row[field]:
                dt.date.fromisoformat(row[field])
    source_by_event = collections.defaultdict(list)
    for row in data['event_sources']:
        source_by_event[row['event_id']].append(row)
        if row['event_id'] not in events:
            issues['source_orphan_event'].append({'event_id': row['event_id']})
            continue
        event = events[row['event_id']]
        for field in ['model_key', 'action', 'system', 'event_batch',
                      'public_date_lower_bound', 'public_date_upper_bound']:
            mismatch('source_event_field', row['model_key'] + ':' + field,
                     row[field], event[field])
    for event_id, row in events.items():
        linked = source_by_event[event_id]
        mismatch('event_source_count', event_id, int(row['source_record_count']), len(linked))
        mismatch('event_source_ids', event_id,
                 sorted(filter(None, row['source_record_ids'].split('|'))),
                 sorted(source['source_record_id'] for source in linked))

    cutoff = '2023-12-10'
    announcement_members = {
        key for key in member_keys
        if any(row['action'] == '列入' and row['public_date_upper_bound'] <= cutoff
               for row in event_by_model[key])
    }
    pre_state = {key: observed_state(event_by_model[key], cutoff) for key in member_keys}
    risk_set = {key for key in announcement_members if pre_state[key]['active'] == '1'}
    for key in member_keys:
        mismatch('announcement_membership', key, members[key]['membership_announcement_cohort'],
                 str(int(key in announcement_members)))
        mismatch('risk_input_active', key, risk_input[key]['announcement_active_observed'], pre_state[key]['active'])
    potential_count_name_examples = []
    potential_count_different_from_total_count = 0
    for row in data['states']:
        calculated = observed_state(event_by_model[row['model_key']], row['cutoff'])
        mismatch('cutoff_state', row['model_key'] + ':' + row['cutoff'],
                 row['catalogue_active_observed'], calculated['active'])
        mismatch('cutoff_possible_event_ids', row['model_key'] + ':' + row['cutoff'],
                 sorted(filter(None, row['possible_last_event_ids'].split('|'))), calculated['latest_ids'])
        mismatch('cutoff_certain_event_count', row['model_key'] + ':' + row['cutoff'],
                 int(row['certain_observed_event_count']), calculated['certain_count'])
        mismatch('cutoff_potential_event_count', row['model_key'] + ':' + row['cutoff'],
                 int(row['potential_event_count']), calculated['latest_count'])
        if int(row['potential_event_count']) != calculated['potential_count']:
            potential_count_different_from_total_count += 1
            if len(potential_count_name_examples) < 5:
                potential_count_name_examples.append({
                    'model_key': row['model_key'], 'cutoff': row['cutoff'],
                    'archived_potential_event_count': int(row['potential_event_count']),
                    'total_potential_before_cutoff': calculated['potential_count'],
                    'surviving_latest_candidate_count': calculated['latest_count']})

    snapshot_index = {(row['model_key'], row['cutoff']): row for row in data['snapshots']}
    frozen = {}
    for key in sorted(member_keys):
        _, _, latest = possible_latest(parameter_by_model[key], cutoff)
        all_observed = bool(latest) and all(row['public_date_upper_bound'] <= cutoff for row in latest)
        distance = unanimous_point(latest, all_observed, lambda row: number(row['range_point']))
        density = unanimous_point(latest, all_observed, density_from_energy_mass)
        snapshot = snapshot_index[(key, cutoff)]
        record_ids = sorted(row['record_id'] for row in latest)
        mismatch('frozen_latest_source_ids', key,
                 sorted(filter(None, snapshot['possible_latest_record_ids'].split('|'))), record_ids)
        mismatch('frozen_all_sources_observed', key,
                 snapshot['all_possible_latest_observed_before_cutoff'], str(int(all_observed)))
        numeric_mismatch('frozen_range_point', key, number(snapshot['range_point']), distance)
        numeric_mismatch('frozen_density_point', key, number(snapshot['density_proxy_point']), density)
        two_points_available = distance is not None and density is not None
        ready = key in risk_set and all_observed and two_points_available
        mismatch('frozen_two_point_availability', key, snapshot['two_parameter_point_available'],
                 str(int(two_points_available)))
        mismatch('numeric_input_ready', key, risk_input[key]['descriptive_continuous_did_input_ready'],
                 str(int(ready)))
        layer = numeric_layer(ready, distance, density) if key in risk_set else ''
        frozen[key] = {'distance': distance, 'density': density, 'ready': ready,
                       'all_observed': all_observed, 'record_ids': record_ids,
                       'layer': layer, 'range_cycle_explicit': snapshot['range_cycle_explicit']}
        if key in risk_set:
            saved = stored_layers.get(key)
            if saved is None:
                issues['missing_saved_layer'].append({'model_key': key})
            else:
                mismatch('numeric_layer', key, saved['numeric_layer'], layer)
                numeric_mismatch('saved_layer_range', key, number(saved['range_point_km']), distance)
                numeric_mismatch('saved_layer_density', key,
                                 number(saved['density_proxy_point_Wh_per_kg']), density)
                mismatch('saved_layer_ready', key, saved['numeric_input_ready'], str(int(ready)))
                mismatch('saved_layer_source_ids', key,
                         sorted(filter(None, saved['possible_latest_record_ids'].split('|'))), record_ids)
    mismatch('saved_layer_coverage', 'risk_models', sorted(stored_layers), sorted(risk_set))

    start, end = '2024-01-01', '2024-12-31'
    withdrawals = {}
    relistings = {}
    for key in sorted(member_keys):
        withdrawal_events = [row for row in event_by_model[key] if row['action'] == '撤销'
                             and start <= row['public_date_upper_bound'] <= end]
        first_upper = min((row['public_date_upper_bound'] for row in withdrawal_events), default=None)
        relisting_events = [row for row in event_by_model[key]
                           if first_upper is not None and row['action'] == '列入'
                           and row['public_date_lower_bound']
                           and row['public_date_lower_bound'] > first_upper
                           and row['public_date_upper_bound'] <= end]
        if withdrawal_events:
            withdrawals[key] = withdrawal_events
        if relisting_events:
            relistings[key] = relisting_events
        mismatch('trajectory_withdrawal', key, trajectory[key]['post2024_withdrawal_observed'],
                 str(int(bool(withdrawal_events))))
        mismatch('trajectory_withdrawal_ids', key,
                 sorted(filter(None, trajectory[key]['withdrawal_event_ids'].split('|'))),
                 sorted(row['event_id'] for row in withdrawal_events))
        mismatch('trajectory_relisting', key, trajectory[key]['relisted_after_2024_withdrawal_observed'],
                 str(int(bool(relisting_events))))
        mismatch('trajectory_relisting_ids', key,
                 sorted(filter(None, trajectory[key]['relisting_event_ids'].split('|'))),
                 sorted(row['event_id'] for row in relisting_events))
    withdrawal_set = set(withdrawals)
    relisting_set = set(relistings)
    official_set = member_keys & set(official)
    official_risk_set = risk_set & official_set
    marked_without_withdrawal = official_risk_set - withdrawal_set
    official_outside_risk = official_set - risk_set
    threshold_met_marked = {key for key in official_risk_set
                            if frozen[key]['layer'] == '两项数值均达到常规阈值'}
    for key in member_keys:
        saved = stored_join[key]
        for field, value in [
            ('in_preannouncement_active_riskset', key in risk_set),
            ('numeric_input_ready', frozen[key]['ready']),
            ('official_nonconformance_list_presence_observed', key in official_set),
            ('post2024_withdrawal_observed', key in withdrawal_set),
            ('relisted_after_2024_withdrawal_observed', key in relisting_set),
        ]:
            mismatch('stored_join_flags', key + ':' + field, saved[field], str(int(value)))
        mismatch('stored_join_official_sequence', key, saved['official_list_seq'],
                 official[key]['seq'] if key in official_set else '')
        mismatch('no_preannouncement_backfill', key, saved['label_available_at_20231210'], '0')
    saved_outside_withdrawals = {row['model_key'] for row in data['stored_outside_withdrawal']}
    mismatch('stored_outside_withdrawal_coverage', 'outside_risk',
             sorted(saved_outside_withdrawals), sorted(withdrawal_set - risk_set))

    def export_record(key):
        mark = official[key]
        numeric = frozen[key]
        event_rows = withdrawals.get(key, [])
        relist_rows = relistings.get(key, [])
        reason = ('不属于公告前成员' if key not in announcement_members
                  else '公告前在册观察标记不为1' if key not in risk_set else '')
        return {
            'model_key': key,
            'official_list_seq': mark['seq'],
            'official_firm_raw': mark['firm_raw'],
            'official_product_name_raw': mark['product_name_raw'],
            'official_source_sha256': mark['source_sha256'],
            'official_public_date': mark['official_public_date'],
            'in_preannouncement_membership_recomputed': int(key in announcement_members),
            'preannouncement_active_recomputed': pre_state[key]['active'],
            'in_preannouncement_riskset_recomputed': int(key in risk_set),
            'riskset_exclusion_reason': reason,
            'numeric_input_ready_recomputed': int(numeric['ready']),
            'numeric_layer_recomputed': numeric['layer'],
            'frozen_range_km_recomputed': '' if numeric['distance'] is None else str(numeric['distance']),
            'frozen_density_proxy_Wh_per_kg_recomputed': '' if numeric['density'] is None else str(numeric['density']),
            'range_cycle_explicit_archived': numeric['range_cycle_explicit'],
            'frozen_possible_latest_record_ids_recomputed': '|'.join(numeric['record_ids']),
            'withdrawal_2024_recomputed': int(key in withdrawal_set),
            'withdrawal_event_ids_recomputed': '|'.join(sorted(row['event_id'] for row in event_rows)),
            'withdrawal_date_bounds_recomputed': '|'.join(sorted(
                row['public_date_lower_bound'] + '..' + row['public_date_upper_bound'] for row in event_rows)),
            'relisted_after_2024_withdrawal_recomputed': int(key in relisting_set),
            'relisting_event_ids_recomputed': '|'.join(sorted(row['event_id'] for row in relist_rows)),
            'member_source_record_ids_archived': members[key]['source_record_ids'],
            'qualification_scope': '仅已归档来源中的型号连接和事件观察；不认证全部官方集合、配置同一性或逐车法律资格',
        }
    exports = {
        'risk_official_marked_without_2024_withdrawal_81.csv': marked_without_withdrawal,
        'nonrisk_official_marked_15.csv': official_outside_risk,
        'risk_two_thresholds_met_official_marked_216.csv': threshold_met_marked,
    }
    for filename, keys in exports.items():
        write_csv(out / filename, [export_record(key) for key in sorted(keys)])
    layers = []
    for name in ['两项数值低于常规阈值', '两项数值均达到常规阈值', '单值不足',
                 '密度代理单项低于常规阈值', '续航单项低于常规阈值']:
        group = {key for key in risk_set if frozen[key]['layer'] == name}
        layers.append({'numeric_layer': name, 'risk_models': len(group),
                       'official_marked': len(group & official_set),
                       'official_not_marked': len(group - official_set),
                       'withdrawal_2024_models': len(group & withdrawal_set),
                       'official_marked_without_withdrawal_2024': len((group & official_set) - withdrawal_set)})
    counts = {
        'official_rows': len(data['official']), 'official_distinct_models': len(official),
        'members': len(member_keys), 'announcement_members_recomputed': len(announcement_members),
        'risk_models_recomputed': len(risk_set), 'nonrisk_models': len(member_keys - risk_set),
        'official_matched_cohort': len(official_set), 'official_matched_risk': len(official_risk_set),
        'official_matched_nonrisk': len(official_outside_risk),
        'official_unmatched_cohort': len(member_keys - official_set),
        'official_unmatched_risk': len(risk_set - official_set),
        'withdrawal_2024_event_rows': sum(len(rows) for rows in withdrawals.values()),
        'withdrawal_2024_models': len(withdrawal_set),
        'withdrawal_2024_risk_models': len(withdrawal_set & risk_set),
        'withdrawal_2024_nonrisk_models': len(withdrawal_set - risk_set),
        'withdrawal_2024_official_unmatched_models': len(withdrawal_set - official_set),
        'relisted_after_2024_withdrawal_models': len(relisting_set),
        'relisted_after_2024_withdrawal_risk_models': len(relisting_set & risk_set),
        'relisted_after_2024_withdrawal_nonrisk_models': len(relisting_set - risk_set),
        'risk_official_marked_without_2024_withdrawal': len(marked_without_withdrawal),
        'nonrisk_official_marked_with_2024_withdrawal': len(official_outside_risk & withdrawal_set),
        'nonrisk_official_marked_without_2024_withdrawal': len(official_outside_risk - withdrawal_set),
        'risk_two_thresholds_met_official_marked': len(threshold_met_marked),
        'risk_two_thresholds_met_marked_withdrawal': len(threshold_met_marked & withdrawal_set),
        'risk_two_thresholds_met_marked_without_withdrawal': len(threshold_met_marked - withdrawal_set),
    }
    hypothesis = {
        'official_rows': 4160, 'official_distinct_models': 4160, 'members': 3328,
        'risk_models_recomputed': 2805, 'nonrisk_models': 523,
        'official_matched_cohort': 591, 'official_matched_risk': 577,
        'official_matched_nonrisk': 14, 'withdrawal_2024_models': 503,
        'withdrawal_2024_risk_models': 496, 'withdrawal_2024_nonrisk_models': 7,
        'withdrawal_2024_official_unmatched_models': 0,
        'relisted_after_2024_withdrawal_models': 5,
        'relisted_after_2024_withdrawal_risk_models': 5,
        'relisted_after_2024_withdrawal_nonrisk_models': 0,
        'risk_official_marked_without_2024_withdrawal': 81,
        'nonrisk_official_marked_with_2024_withdrawal': 7,
        'nonrisk_official_marked_without_2024_withdrawal': 7,
        'risk_two_thresholds_met_official_marked': 217,
    }
    for key, expected in hypothesis.items():
        mismatch('reported_count_hypotheses', key, expected, counts[key])
    seq = [int(row['seq']) for row in data['official']]
    mismatch('official_sequence', 'seq', sorted(seq), list(range(1, len(seq) + 1)))
    outside_withdrawal_reasons = collections.Counter(
        '不属于公告前成员' if key not in announcement_members else '公告前在册观察标记不为1'
        for key in withdrawal_set - risk_set)
    all_reasons = collections.Counter(
        '不属于公告前成员' if key not in announcement_members else '公告前在册观察标记不为1'
        for key in official_outside_risk)
    output_hashes = {filename: hashlib.sha256((out / filename).read_bytes()).hexdigest()
                     for filename in exports}
    result = {
        'runtime': {'python': sys.version, 'dependencies': 'Python standard library only'},
        'scope': 'Current reconstructed v1.3 CSVs; risk-count reference comes from independent added-source impact, 73 historic missed withdrawals remove risk membership; one verified batch-date correction restores a re-listed model. No network, no input modified. '
                 'This is not certification of the complete external official source universe, '
                 'cross-catalogue configuration identity, causal effects, or vehicle-level legal eligibility.',
        'method': {
            'key_normalisation': 'NFKC, remove whitespace, uppercase; exact equality join after uniqueness checks',
            'risk': 'Membership reconstructed from listing upper bound <= 2023-12-10; '
                    'state independently reconstructed from interval event ordering; require active=1.',
            'numeric': 'Rebuild possible latest admitted parameter sources at 2023-12-10 using date intervals; '
                       'require all candidate observations known before cutoff and unanimous nonmissing point values; '
                       'density recomputed per source as 1000*energy_kWh/mass_kg, Decimal precision 28. '
                       'Compare raw frozen R and D against 200 and 125, inclusive on pass side. '
                       'No blank-to-zero conversion and no recommended-catalogue replacement.',
            'withdrawal': 'Distinct model with action=撤销 and upper bound in inclusive 2024 date window.',
            'relisting': 'Take earliest such withdrawal upper bound firstw; require listing lower bound > firstw '
                         'and listing upper bound <= 2024-12-31. Relisted models are already in withdrawal set.',
            'saved_tables_role': 'Archived derived flags, layers and trajectories are comparison targets only; '
                                 'they do not generate the recomputed groups.',
        },
        'counts': counts,
        'numeric_layers_recomputed': layers,
        'threshold_boundary_counts': {
            'risk_distance_exactly_200': sum(frozen[key]['distance'] == Decimal(200) for key in risk_set),
            'risk_density_exactly_125': sum(frozen[key]['density'] == Decimal(125) for key in risk_set),
            'ready_distance_exactly_200': sum(frozen[key]['ready'] and frozen[key]['distance'] == Decimal(200)
                                             for key in risk_set),
            'ready_density_exactly_125': sum(frozen[key]['ready'] and frozen[key]['density'] == Decimal(125)
                                            for key in risk_set),
        },
        'field_semantics_observations': {
            'potential_event_count': 'Archived field equals surviving possible-latest event candidates, '
                                     'rather than all events potentially before cutoff. '
                                     'All 9984 archived rows match this candidate-count interpretation.',
            'rows_where_total_potential_count_differs_from_archived_field': potential_count_different_from_total_count,
            'examples': potential_count_name_examples,
        },
        'key_uniqueness': uniqueness,
        'join_cardinality': {
            'member_left_join_official_before': len(member_keys),
            'member_left_join_official_after': sum(max(1, sum(row['model_key'] == key
                for row in data['official'])) for key in member_keys),
            'official_match_rows': len(official_set),
            'member_left_join_pre_cutoff_parameter_snapshot_before': len(member_keys),
            'member_left_join_pre_cutoff_parameter_snapshot_after': sum(max(1, sum(
                row['model_key'] == key and row['cutoff'] == cutoff for row in data['snapshots']))
                for key in member_keys),
            'deduplicated_event_rows': len(events),
            'event_source_rows': len(data['event_sources']),
            'event_source_extra_rows_expected_from_multiple_sources': len(data['event_sources']) - len(events),
        },
        'nonrisk_marked_reasons': dict(all_reasons),
        'nonrisk_withdrawal_reasons': dict(outside_withdrawal_reasons),
        'nonrisk_official_marked_without_2024_withdrawal_models': sorted(official_outside_risk - withdrawal_set),
        'nonrisk_official_marked_with_2024_withdrawal_models': sorted(official_outside_risk & withdrawal_set),
        'relisted_models_and_events': {key: {
            'withdrawals': [{field: row[field] for field in ['event_id', 'system', 'event_batch',
                             'public_date_lower_bound', 'public_date_upper_bound']} for row in withdrawals[key]],
            'relistings': [{field: row[field] for field in ['event_id', 'system', 'event_batch',
                            'public_date_lower_bound', 'public_date_upper_bound']} for row in relistings[key]]}
            for key in sorted(relisting_set)},
        'input_sha256': input_hashes,
        'export_sha256': output_hashes,
        'mismatch_counts': {key: len(value) for key, value in issues.items() if value},
        'mismatches': {key: value for key, value in issues.items() if value},
        'mismatch_total': sum(len(value) for value in issues.values()),
    }
    if result['join_cardinality']['member_left_join_official_after'] != len(member_keys):
        result['mismatch_total'] += 1
        result['mismatches']['official_join_expansion'] = result['join_cardinality']
    if result['join_cardinality']['member_left_join_pre_cutoff_parameter_snapshot_after'] != len(member_keys):
        result['mismatch_total'] += 1
        result['mismatches']['snapshot_join_expansion'] = result['join_cardinality']
    final_input_hashes = {value: hashlib.sha256((root / value).read_bytes()).hexdigest()
                          for value in paths.values()}
    result['input_hashes_unchanged'] = final_input_hashes == input_hashes
    if not result['input_hashes_unchanged']:
        result['mismatch_total'] += 1
    (out / 'detailed_results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n',
                                              encoding='utf-8')
    print(json.dumps({'counts': counts, 'mismatch_total': result['mismatch_total'],
                      'mismatch_counts': result['mismatch_counts'],
                      'input_hashes_unchanged': result['input_hashes_unchanged']},
                     ensure_ascii=False, indent=2))
    return 0 if result['mismatch_total'] == 0 and result['input_hashes_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
