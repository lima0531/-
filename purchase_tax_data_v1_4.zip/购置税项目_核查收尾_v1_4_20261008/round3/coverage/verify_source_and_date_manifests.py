import csv,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
index=read(B/'原件索引/完整归档_106份原件嵌套索引_历史记录.csv');mfpath=R.parent/'archive/106原件公开回收清单.csv';manifest=read(mfpath);datespath=R.parent/'dates/97批次日期_本轮官方登记补采更新.csv';dates=read(datespath)
assert len(index)==len(manifest)==106
key=lambda x:(x['scope'],x['system'],x['source_file'])
i={key(x):x for x in index};assert len(i)==106 and set(i)==set(key(x) for x in manifest)
exact=[];pending=[]
for row in manifest:
 old=i[key(row)];assert old['source_sha256']==row['source_sha256'] and old['source_bytes']==row['source_bytes']
 if row['recovery_status']!='sha256_exact':pending.append({'source_file':row['source_file'],'expected_sha256':row['source_sha256']});continue
 p=Path(row['recovered_path']);b=p.read_bytes();assert len(b)==int(old['source_bytes']);assert hashlib.sha256(b).hexdigest()==old['source_sha256']==row['recovered_sha256'];exact.append(row['source_file'])
assert len(dates)==97 and {(x['system'],int(x['batch'])) for x in dates}=={('免征目录',n) for n in range(1,74)}|{('减免目录',n) for n in range(1,25)}
unknown=[]
for row in dates:
 lo,up=row['public_date_lower_bound'],row['public_date_upper_bound'];assert up and (not lo or lo<=up)
 if row['publish_date_exact_is_verified']=='1':assert row['publish_date_exact'] and row['publish_date_exact']==lo==up
 else:unknown.append({'system':row['system'],'batch':row['batch']})
 assert row['full_historical_first_online_time_verified']=='0'
for name in ['withdrawal_20180522','withdrawal_batch28']:
 rec=json.loads((R/'raw'/(name+'.json')).read_text());p=R/'raw'/(name+'.doc');assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'] and len(p.read_bytes())==rec['bytes']
result={'original_source_index_rows':106,'archive_manifest_rows':len(manifest),'exact_original_files_physically_verified':len(exact),'not_exactly_recovered_originals':pending,'manifest_sha256_at_verification':hashlib.sha256(mfpath.read_bytes()).hexdigest(),'date_ledger_rows':97,'date_ledger_unique_batch_keys':97,'registered_exact_date_rows':97-len(unknown),'registered_exact_date_missing':unknown,'registered_exact_dates_equal_interval_bounds':True,'interval_chronology_valid':True,'all_first_online_certified_flags_remain_zero':True,'date_ledger_sha256_at_verification':hashlib.sha256(datespath.read_bytes()).hexdigest(),'two_added_formal_withdrawal_originals_fingerprint_verified':True,'input_index_modified':False}
(R/'source_and_date_manifest_independent_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
