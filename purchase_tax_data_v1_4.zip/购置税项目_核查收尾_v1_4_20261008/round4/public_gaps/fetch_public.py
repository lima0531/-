from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode, urljoin
from urllib.error import HTTPError
from concurrent.futures import ThreadPoolExecutor
from html.parser import HTMLParser
import json, hashlib, datetime, re, ssl
ROOT = Path(__file__).parent
def fetch(url, name):
    dst = ROOT / name
    receipt = Path(str(dst) + '.receipt.json')
    if dst.exists() and receipt.exists():
        return json.loads(receipt.read_text())
    dst.parent.mkdir(parents=True, exist_ok=True)
    rec = dict(requested_url=url, fetched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), tls_verification=True)
    try:
        with urlopen(Request(url, headers={'User-Agent':'Mozilla/5.0'}), timeout=30, context=ssl.create_default_context()) as r:
            raw = r.read()
            dst.write_bytes(raw)
            rec.update(status='ok', http_status=r.status, final_url=r.url, response_headers=dict(r.headers.items()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), local_path=str(dst))
    except HTTPError as e:
        rec.update(status='http_error', http_status=e.code, error=str(e))
    except Exception as e:
        rec.update(status='fetch_error', error=repr(e))
    receipt.write_text(json.dumps(rec, ensure_ascii=False, indent=2)+'\n')
    return rec
def miit_search(query, name):
    args=dict(websiteid='110000000000000',scope='basic',q=query,pg='40',p='1',cateid='47',pos='title_text,titlepy,infocontent,filenumbername,keyword,contentdescribe',selectFields='title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode',group='distinct',level='6',sortFields='[{"name":"deploytime","type":"desc"}]')
    rec=fetch('https://www.miit.gov.cn/search-front-server/api/search/info?'+urlencode(args),name+'.json')
    results=[]
    def walk(v):
        if isinstance(v,dict):
            if 'title' in v and 'url' in v:results.append(v)
            for x in v.values():walk(x)
        elif isinstance(v,list):
            for x in v:walk(x)
    if rec['status']=='ok':walk(json.loads(Path(rec['local_path']).read_text()))
    (ROOT/(name+'.hits.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
    return results
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[];self.current=None
    def handle_starttag(self,t,a):
        if t=='a':self.current=[dict(a).get('href',''),'']
    def handle_endtag(self,t):
        if t=='a' and self.current:self.links.append(self.current);self.current=None
    def handle_data(self,d):
        if self.current:self.current[1]+=d
if __name__=='__main__':
    tasks=[('https://fgk.chinatax.gov.cn/zcfgk/c100013/c5207235/content.html','batch26_tax_primary.html'),('https://fgk.chinatax.gov.cn/','fgk_home.html')]
    with ThreadPoolExecutor(max_workers=2) as e:
        for rec in e.map(lambda x:fetch(*x),tasks):print(json.dumps(rec,ensure_ascii=False))
