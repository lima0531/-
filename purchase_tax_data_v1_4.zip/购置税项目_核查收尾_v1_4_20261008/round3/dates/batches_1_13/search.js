var webid = "";
//提取http
var httprq = window.location.href.substring(0,window.location.href.indexOf(":"));
//创建站点数组
var webdata = [
    {"webid":"ec6bd4391c9a43fcb2adb4d5c0ccb1e6","webname":"四川省通信管理局"},
    {"webid":"9e105e416ada4a87884f4b83cd6646a8","webname":"内蒙古自治区通信管理局"},
    {"webid":"0fef8d742a87437fb68543959c47749a","webname":"陕西省通信管理局"},
    {"webid":"292c1b1f3eec48508c88f668a1ffdd8f","webname":"江西省通信管理局"},
    {"webid":"d3af1320083e41178815869d3f9d081e","webname":"广西壮族自治区通信管理局"},
    {"webid":"eb31cdc9f10d4d169377d773df1de2ea","webname":"安徽省通信管理局"},
    {"webid":"61ffafe14b3f4ccc94ceafac68fd0b33","webname":"中国消费品三品战略"},
    {"webid":"ce44e901869b40dfa04d5517f6958a9d","webname":"中国中小企业信息网"},
    {"webid":"a78336034387485e8193cadede928d03","webname":"天津市通信管理局"},
    {"webid":"8538c551720443489f4410a90efaa24e","webname":"云南省通信管理局"},
    {"webid":"e0e2c179f776433d8e2bf7b8b4d017f9","webname":"贵州省通信管理局"},
    {"webid":"6e331199dd13477a8edaf22f9c9ba1c2","webname":"重庆市通信管理局"},
    {"webid":"5babc0e79ce94951a4f24d7b992dd5ee","webname":"海南省通信管理局"},
    {"webid":"2087b99b0d764438bb7fe1d1f81966a4","webname":"湖北省通信管理局"},
    {"webid":"6f4285f1275c40f4aeaf243a1d6e4439","webname":"福建省通信管理局"},
    {"webid":"6c620603cc944086b9daf1a87047f63a","webname":"甘肃省通信管理局"},
    {"webid":"5c0b3935e5114b75b2fcc84b0d5cd7b6","webname":"河北省通信管理局"},
    {"webid":"2e1e2d7095dc4ff1bd767d43bc6f041c","webname":"广东省通信管理局"},
    {"webid":"25b2fd3da2f44402bedeb4364e630274","webname":"北京市通信管理局"},
    {"webid":"f109df7d3c8d4072af97285d27aa7515","webname":"青海省通信管理局"},
    {"webid":"b9320314a8974379b06722b1509a0c31","webname":"河南省通信管理局"},
    {"webid":"0358b2276d1244a2819faf77e9ad0867","webname":"西藏自治区通信管理局"},
    {"webid":"6582b43ec020431c817da299a43ded43","webname":"湖南省通信管理局"},
    {"webid":"d0fdf9f4c8fd4134a079c5cd9cea6bb3","webname":"山东省通信管理局"},
    {"webid":"cf6a2b1524b941d295fe27fcba2224f3","webname":"江苏省通信管理局"},
    {"webid":"17a7032dba33486aa0730140fe77cd35","webname":"上海市通信管理局"},
    {"webid":"46e653bf5b344403bcf5a138feeebb0c","webname":"吉林省通信管理局"},
    {"webid":"75fe7d5704aa4cd6a73fb3c937812d7f","webname":"浙江省通信管理局"},
    {"webid":"418dde5534b64bbb991f32c2797c37fd","webname":"宁夏回族自治区通信管理局"},
    {"webid":"c833cafc883e47be96ecb00ea10a7a24","webname":"新疆维吾尔自治区通信管理局"},
    {"webid":"0e74139644d54ec09e667d081e8e785b","webname":"山西省通信管理局"},
    {"webid":"1a02ce9103214e3ebb11ee589691cfb8","webname":"辽宁省通信管理局"},
    {"webid":"54f03e8fc3c74d0d901c06928c20cc8b","webname":"黑龙江省通信管理局"},
]

//创建分页
function pagination(p, pg) {
    var total = $("#total").val();
    // console.log("total"+total);
    var pageCount = total % pg == 0 ? total / pg : total / pg + 1;
    /// console.log("pageCount"+pageCount);
    $('#pagecount').attr("data-pagecount", pageCount);
    if (pageCount < 2) {
        $('#pagination').html("");
    }
    if ($("#pagination").myPagination) {
        $("#pagination").myPagination({
            cssStyle: 'manu',
            pageNumber: 5,
            currPage: p,
            pageCount: pageCount,
            ajax: {
                onClick: function (page) {
                    $('#p').val(page);
                    search_init();
                }
            },
            panel: {
                links: "javascript:void(0);",
                first_on: true,
                last_on: true
            }
        });
    }
}

function searchmanage_init(datasearchmanage) {
    ajaxGet("../../" + $('#search-form').data('path') + "api/structure/list-searchmanager", {
        type: 'json',
        data: datasearchmanage,
        success: function (result) {
            $('.jcse-seachmanage').html("");
            if (result) {
                var datasearchmanage;
                searchmanagers = result.data.searchManagers;
                for (var i = 0, len = searchmanagers.length; i < len; i++) {
                    var manage = searchmanagers[i];
                    if(manage.iid != "50"){
                        $('.jcse-seachmanage').append('<li class="search-manage" id="one' + manage.iid + '" onmouseover=' + '&#39;setTab3("one","' + manage.iid + '")&#39; data-searchmanageid="' + manage.iid + '" data-id="">' + manage.name + '</li>');
                    }

                }

                /*判断分类执行
                if(getQueryString('searchmanagersid') != "" || getQueryString('searchmanagersid') !=null){
                    $('#input-searchid').val(getQueryString('searchmanagersid'));
                }else{
                    $('#input-searchid').val(initsearchid);
                }
                */
                var initsearchid = "";
                var sidv = getQueryString('cateid');

                if(sidv != "" && sidv != null){
                    $('#input-searchid').val(sidv);
                }else{
                    initsearchid = searchmanagers[0].iid;
                    $('#input-searchid').val(initsearchid);
                }

                cate_init();
                manage_search();
                relateImages();
                plugin_criterias_init();

            }



        }
    })
}

//创建默认列表
function cate_init() {
    $('.yyfw').remove();
    $('.sjk-box').html('');
    $('.ui-noresult-box').hide();
    var initsearchid = $('#input-searchid').val();
    var datacate = "websiteid=" + getQueryString('websiteid') + "&searchid=" + initsearchid;
    ajaxGet("../../" + $('#search-form').data('path') + "api/structure/list-category", {
        type: 'json',
        data: datacate,
        success: function (result) {
            if (!(result && result.data && result.data.categories)) {
                $('.ui-noresult-box').show();
                $(".prompting span,.maction span").text("0");

            } else {
                var datacatenmanage = result.data.categories;
                if (datacatenmanage) {
                    for (var i = 0, len = datacatenmanage.length; i < len; i++) {
                        var cate = datacatenmanage[i];
                        var catehtml = '<div class="yyfw">'+
                            '	<div class="col_title" style="display:none ！important;">'+
                            '		<div class="col_name" data-sign="yyss" data-cateid="' + cate.iid + '" data-arrange-rank="' + cate.rankSign + '" data-datanumber="' + cate.dataNumber + '" data-mergee="' + cate.mergee + '" data-page="1">'+
                            '			<span class="t_s2">' + cate.name + '</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+
                            '		</div>'+
                            '	</div>'+
                            '	<div class="zffw_list" data-cate-sign=""  data-highlight-fields="title"></div>'+
                            '</div>';
                        //$('.con_left').prepend(catehtml);
                        $('.zwfw-banner').after(catehtml);

                    }
                }
                ajaxGet("../../" + $('#search-form').data('path') + "api/structure/dimension-input", {
                    type: 'json',
                    data: datacate,
                    success: function (result) {
                        if (result && result.data && result.data.dimenInput) {
                            $('#dimension-content').html(result.data.dimenInput);
                        }
                    }
                })

                $("#p").val(1);

                search_init();


            }
        }


    })
}

function search_init() {
    var sid = $('#input-searchid').val();
    if(sid == "47"){
        $(".zwfw-banner").show();
    }else{
        $(".zwfw-banner").hide();
    }

    setTab3('one', sid);
    var $yyfw = $('.yyfw');
    var backNum = 0;
    var num = $('.col_name').data("cateid");
    $yyfw.each(function (index, cateGroupInfo) {
        var $cateGroupInfo = $(cateGroupInfo);
        //var p = $('.col_name', $cateGroupInfo).data('page');
        var pg = "";
        //console.log($cateGroupInfo.data());
        var catepg = $('#pg').val();
        var datanumber = $cateGroupInfo.find('.col_name').data("datanumber");
        if (!catepg) {
            catepg = datanumber;
        }
        var q = $('#q').val();
        var p = $('#p').val();


        var websiteid = $('#webid').val();
        var category = $cateGroupInfo.find('.col_name').data("sign");

        var mergee = $cateGroupInfo.find('.col_name').data("mergee");
        //var highlightFields = $cateGroupInfo.data('highlight-fields');
        var pos = $('#pos').val();
        //var sortType = $('#sortType').val();
        var end = $('#date_end').val();
        var begin = $('#date_start').val();
        var pq = $('#pq').val();
        var oq = $('#oq').val();
        var eq = $('#eq').val();
        //  var tpl = $('#tpl').val();

        var ranksign = $cateGroupInfo.find('.col_name').data("arrange-rank");
        //var dimension = $(.dimension-field).val();
        var data = "websiteid=" + websiteid;
        var $dimensions = $('.dimension-field');
        var dim = "";
        var sortType = $('#od').val();
        var selectFields = $('#search-form').data('selectfield');
        $dimensions.each(function (index, dimension) {
            var $dimension = $(dimension);
            dim += '&' + $dimension.attr("name") + '=' + $dimension.val();
        });

        var colname = "";
        var sjksx = $("#sjk-sx").val();
        if(sid == "50"){
            $("#jsearch-condition-box-content,.content").hide();
            $(".sjk-wrap").show();
            pg=12;
            if(sjksx != ""){
                colname ="&_cus_eq_columnname=" + encodeURIComponent(sjksx);
            }

        }else{
            $("#jsearch-condition-box-content,.content").show();
            $(".sjk-wrap").hide();
            pg = $('.col_name', $cateGroupInfo).data('datanumber');
        }

		//默认排序
		var qz = $("#q").val().trim().length;
		var wzn1 = '[{"name":"deploytime","type":"desc"}]';
		var wzn2 = '[{"name":"jsearch_score","type":"desc"}]';
		var yzn1 = '[{"name":"extend1","type":"desc"},{"name":"deploytime","type":"desc"}]';
		var yzn2 = '[{"name":"extend1","type":"desc"},{"name":"jsearch_score","type":"desc"}]';
		var qz = $("#q").val().trim().length;
		if(qz == 0){
			$(".od-box1").attr('data-value',wzn1);
			$(".od-box2").attr('data-value',wzn2);
			$(".od-box3").attr('data-value',wzn1);

		}else{
			$(".od-box1").attr('data-value',yzn1);
			$(".od-box2").attr('data-value',yzn2);
			$(".od-box3").attr('data-value',yzn1);
		}
		if(qz == 0){
			$("#od").val(wzn1);
		}else{
			$("#od").val(yzn2);
		}

		var odtxt = $("#od-box .jsearch-condition-box-title span").text();
		if(odtxt == "默认" || odtxt == "默认时间"){
			if(qz == 0){
				$("#od").val(wzn1);
			}else{
				$("#od").val(yzn2);
			}
		}else if(odtxt == "相关度"){
			if(qz == 0){
				$("#od").val(wzn2);
			}else{
				$("#od").val(yzn2);
			}
			
		}else if(odtxt == "时间"){
			if(qz == 0){
				$("#od").val(wzn1);
			}else{
				$("#od").val(yzn1);
			}
		}


        data += '&scope=basic&q=' + encodeURIComponent(q) + '&pg=' + pg + '&cateid=' + num + colname + '&pos='+ pos +'&pq=' + encodeURIComponent(pq) + '&oq=' + encodeURIComponent(oq) + '&eq=' + encodeURIComponent(eq) + '&begin=' + begin + '&end=' + end + '&dateField=deploytime' + dim + '&selectFields=' + selectFields + '&group=distinct' + '&highlightConfigs=[{"field":"infocontent","numberOfFragments":2,"fragmentOffset":0,"fragmentSize":110,"noMatchSize":110}]' + '&highlightFields=title_text,infocontent,webid&level=6' + '&sortFields='+$('#od').val() + '&hidCol=fbafd13557fa453d9c59432567d2b150';

        var searchdata = data + '&p=' + p;
        //var searchdata = "websiteid=110000000000000&scope=basic&q=%E8%8B%97%E5%9C%A9&pg=10&cateid=47&pos=title_text%2Cinfocontent&pq=&oq=&eq=&begin=&end=&dateField=deploytime&selectFields=title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,webid,columnid&group=distinct&highlightConfigs=%5B%7B%22field%22%3A%22infocontent%22%2C%22numberOfFragments%22%3A2%2C%22fragmentOffset%22%3A0%2C%22fragmentSize%22%3A30%2C%22noMatchSize%22%3A50%7D%5D&highlightFields=title_text%2Cinfocontent&level=6&sortFields=%5B%7B%22name%22%3A%22deploytime%22%2C%22type%22%3A%22desc%22%7D%5D&p="+ encodeURIComponent(p);
        ajaxGet('../../' + $('#search-form').data('path') + 'api/search/info', {
            type: 'json',
            data: searchdata,
            success: function (result) {
                $('.zffw_list', $cateGroupInfo).html("");
                //pagination(parseInt(1), pg);
                if (result && result.data && result.data.searchResult && result.data.searchResult.total > 0) {
                    $('.col_title', $cateGroupInfo).show();
                    $('.ui-noresult-box').hide();
                    var total = result.data.searchResult.total;
                    $('#total').val(total);
                    var resultinfo = result.data.searchResult.dataResults;
                    var infos = '';
                    var reinfos = '';
                    if (respFunctions) {
                        infos = respFunctions(resultinfo, q);
                    }
                    $('.mergeeaction', $cateGroupInfo).show();
                    $('.maction').text("");
                    //infos = '<div class="mergeeaction"><span>此分类下搜索方式为<em>向上</em>站点搜索<span><div>'+infos;
                    $('.maction').html("为您找到相关结果约<span>"+ toThousands(total) + "</span>个");
                    $('.prompting span').text(toThousands(total));
                    $('.maction').show();
                    if (ranksign == "leftfloat") {
                        var cssdata = '<div class="yyfw_box">' + infos + '</div>';
                        reinfos += cssdata;
                    } else if (ranksign == "fallstream") {
                        var cssdata = '<div class="yyfw_box">' + infos + '</div>';
                        reinfos += cssdata;;
                    } else if (ranksign == "newstype") {
                        var cssdata = '<div class="news-type">' + infos + '</div>';
                        reinfos += cssdata;;
                    } else if (ranksign == "workstype") {
                        var cssdata = '<div class="work-type">' + infos + '</div>';
                        reinfos += cssdata;
                    } else if (!ranksign) {
                        var cssdata = '<div class="news-type">' + infos + '</div>';
                        reinfos += cssdata;

                    }
                    if (ranksign == "leftfloat" || ranksign == "newstype" || ranksign == "workstype" || !ranksign) {
                        $('.zffw_list', $cateGroupInfo).html(reinfos);

                    } else if (ranksign == "fallstream") {
                        $('.zffw_list', $cateGroupInfo).html(reinfos);
                    }
                    if (total <= datanumber) {
                        $('.uploadmore', $cateGroupInfo).hide();
                        $('.more', $cateGroupInfo).hide();

                    }

                    var $resultboxs = $('.jcse-result-box', $cateGroupInfo);
                    $resultboxs.each(function (index, resultbox) {
                        if (index >= datanumber) {
                            return false;
                        }
                        $(this).show();
                    })

                    if( p==""){
                        pagination(parseInt(1), pg);
                    }else{
                        pagination(parseInt(p), pg);
                    }

                    if(total > 15){
                        $("#pagination").show();
                    }else{
                        $("#pagination").hide();
                    }



                    /*相似文章*/
                    $('.zffw_list', $cateGroupInfo).show();
                    var $similarlys = $('.jcse-result-box', $cateGroupInfo);
                    $similarlys.each(function (index, similarly) {
                        var $similarly = $(similarly);
                        $('.jcse-similarly-head a span', $similarly).click(function () {
                            var $btn = $('.jcse-similarly-items', $similarly).toggleClass("similarlyon");
                            if ($btn.hasClass('similarlyon')) {
                                $('.jcse-similarly-items', $similarly).show();
                            } else {
                                $('.jcse-similarly-items', $similarly).hide();
                            }

                        });
                    });


                } else {
//					$cateGroupInfo.parent().find('.cate-search-noresult').show();
                    //$cateGroupInfo.hide();
                    /*backNum++;
                   if (backNum >= $('.col_title').length) {
                       $('.ui-noresult-box').show();
					   $(".prompting span,.maction span").text("0");
                   }
                  $('.col_title', $cateGroupInfo).hide();*/
                    $(".maction").hide();
                    $(".prompting span,.maction span").text("0");
                    $("#pagination").hide();
                    $(".ui-noresult-box").show();

                }
                var searchid = $('#input-searchid').val();

                /*
                $('.more', $cateGroupInfo).click(function () {
                    var data = "websiteid=" + websiteid + "&q=" + encodeURIComponent($('#q').val());
                    data += "&p=1" + "&cateid=" + encodeURIComponent(cateid) + '&searchid=' + searchid + dim + "&start=" + encodeURIComponent($('#date_start').val()) + "&end=" + encodeURIComponent($('#date_end').val());
                    window.open('result.html?' + data);
                });
                */
                var $attachs = $('.jsearch-attach', $cateGroupInfo);
                $attachs.each(function (index, attach) {
                    var $attach = $(attach);
                    if ($attach.html() != "") {
                    }
                    $('.jsearch-attachs-tip').show();
                })

            },
            error: function (result) {

            }

        });


    });


}


//应用服务

function respFunctions(results, q) {
    var data = '';
    var num = 0;

    $.each(results, function (index, result) {
        var content = "";
        var resulthtml;
        var groupdata = result.groupData;
        var content0 = "";
        var rpcontent = "";
        if (result.groupData) {
            var columnname = groupdata[0].data.columnname;
			var deploytime = dateFormat(groupdata[0].data.deploytime);
            if(groupdata[0].data.infocontentattribute != ''){
                var infocontentattribute = groupdata[0].data.infocontentattribute;
                var nfocontentattributejson = JSON.parse(infocontentattribute);
            }
            var title = groupdata[0].data.title_text;
            var url = groupdata[0].data.url;
            var Dwebid = groupdata[0].data.webid;
			var webname = "";

            content = groupdata[0].data.infocontent;
			
			/*
			for(var i=0; i < webdata.length ; i++){
				if(webdata[i].webid == "d3af1320083e41178815869d3f9d081e"){
					webname = webdata[i].webname;
				}
			}
			*/

            if(Dwebid == "<em>19be5b068419473d8b805aa266b2f5f0</em>"){
                if(url.indexOf("http") == "-1"){
                    url = "https://ythxxfb.miit.gov.cn" + url;
                }
            }else{
                if(url.indexOf("http") == "-1"){
                    if( Dwebid == "<em>ec6bd4391c9a43fcb2adb4d5c0ccb1e6</em>" ){//四川省通信管理局
                        url= httprq + '://scca.miit.gov.cn' + url;
						webname = "所属站点：四川省通信管理局 ";
                    }else if( Dwebid == "<em>9e105e416ada4a87884f4b83cd6646a8</em>" ){//内蒙古自治区通信管理局
                        url= httprq + '://nmca.miit.gov.cn' + url;
						webname = "所属站点：内蒙古自治区通信管理局 ";
                    }else if( Dwebid == "<em>0fef8d742a87437fb68543959c47749a</em>" ){//陕西省通信管理局
                        url= httprq + '://shxca.miit.gov.cn' + url;
						webname = "所属站点：陕西省通信管理局 ";
                    }else if( Dwebid == "<em>292c1b1f3eec48508c88f668a1ffdd8f</em>" ){//江西省通信管理局
                        url= httprq + '://jxca.miit.gov.cn' + url;
						webname = "所属站点：江西省通信管理局 ";
                    }else if( Dwebid == "<em>d3af1320083e41178815869d3f9d081e</em>" ){//广西壮族自治区通信管理局
                        url= httprq + '://gxca.miit.gov.cn' + url;
						webname = "所属站点：广西壮族自治区通信管理局 ";
                    }else if( Dwebid == "<em>eb31cdc9f10d4d169377d773df1de2ea</em>" ){//安徽省通信管理局
                        url= httprq + '://ahca.miit.gov.cn' + url;
						webname = "所属站点：安徽省通信管理局 ";
                    }else if( Dwebid == "<em>61ffafe14b3f4ccc94ceafac68fd0b33</em>" ){//中国消费品三品战略
                        url= httprq + '://spzl.miit.gov.cn' + url;
						webname = "所属站点：中国消费品三品战略 ";
                    }else if( Dwebid == "<em>ce44e901869b40dfa04d5517f6958a9d</em>" ){//中国中小企业信息网
                        url= httprq + '://zxqyxx.miit.gov.cn' + url;
						webname = "所属站点：中国中小企业信息网 ";
                    }else if( Dwebid == "<em>a78336034387485e8193cadede928d03</em>" ){//天津市通信管理局
                        url= httprq + '://tjca.miit.gov.cn' + url;
						webname = "所属站点：天津市通信管理局 ";
                    }else if( Dwebid == "<em>8538c551720443489f4410a90efaa24e</em>" ){//云南省通信管理局
                        url= httprq + '://ynca.miit.gov.cn' + url;
						webname = "所属站点：云南省通信管理局 ";
                    }else if( Dwebid == "<em>e0e2c179f776433d8e2bf7b8b4d017f9</em>" ){//贵州省通信管理局
                        url= httprq + '://gzca.miit.gov.cn' + url;
						webname = "所属站点：贵州省通信管理局 ";
                    }else if( Dwebid == "<em>6e331199dd13477a8edaf22f9c9ba1c2</em>" ){//重庆市通信管理局
                        url= httprq + '://cqca.miit.gov.cn' + url;
						webname = "所属站点：重庆市通信管理局 ";
                    }else if( Dwebid == "<em>5babc0e79ce94951a4f24d7b992dd5ee</em>" ){//海南省通信管理局
                        url= httprq + '://hnca.miit.gov.cn' + url;
						webname = "所属站点：海南省通信管理局 ";
                    }else if( Dwebid == "<em>2087b99b0d764438bb7fe1d1f81966a4</em>" ){//湖北省通信管理局
                        url= httprq + '://hubca.miit.gov.cn' + url;
						webname = "所属站点：湖北省通信管理局 ";
                    }else if( Dwebid == "<em>6f4285f1275c40f4aeaf243a1d6e4439</em>" ){//福建省通信管理局
                        url= httprq + '://fjca.miit.gov.cn' + url;
						webname = "所属站点：福建省通信管理局 ";
                    }else if( Dwebid == "<em>6c620603cc944086b9daf1a87047f63a</em>" ){//甘肃省通信管理局
                        url= httprq + '://gsca.miit.gov.cn' + url;
						webname = "所属站点：甘肃省通信管理局 ";
                    }else if( Dwebid == "<em>5c0b3935e5114b75b2fcc84b0d5cd7b6</em>" ){//河北省通信管理局
                        url= httprq + '://hbca.miit.gov.cn' + url;
						webname = "所属站点：河北省通信管理局 ";
                    }else if( Dwebid == "<em>2e1e2d7095dc4ff1bd767d43bc6f041c</em>" ){//广东省通信管理局
                        url= httprq + '://gdca.miit.gov.cn' + url;
						webname = "所属站点：广东省通信管理局 ";
                    }else if( Dwebid == "<em>25b2fd3da2f44402bedeb4364e630274</em>" ){//北京市通信管理局
                        url= httprq + '://bjca.miit.gov.cn' + url;
						webname = "所属站点：北京市通信管理局 ";
                    }else if( Dwebid == "<em>f109df7d3c8d4072af97285d27aa7515</em>" ){//青海省通信管理局
                        url= httprq + '://qhca.miit.gov.cn' + url;
						webname = "所属站点：青海省通信管理局 ";
                    }else if( Dwebid == "<em>b9320314a8974379b06722b1509a0c31</em>" ){//河南省通信管理局
                        url= httprq + '://hca.miit.gov.cn' + url;
						webname = "所属站点：河南省通信管理局 ";
                    }else if( Dwebid == "<em>0358b2276d1244a2819faf77e9ad0867</em>" ){//西藏自治区通信管理局
                        url= httprq + '://xzca.miit.gov.cn' + url;
						webname = "所属站点：西藏自治区通信管理局 ";
                    }else if( Dwebid == "<em>6582b43ec020431c817da299a43ded43</em>" ){//湖南省通信管理局
                        url= httprq + '://hunca.miit.gov.cn' + url;
						webname = "所属站点：湖南省通信管理局 ";
                    }else if( Dwebid == "<em>d0fdf9f4c8fd4134a079c5cd9cea6bb3</em>" ){//山东省通信管理局
                        url= httprq + '://sdca.miit.gov.cn' + url;
						webname = "所属站点：山东省通信管理局 ";
                    }else if( Dwebid == "<em>cf6a2b1524b941d295fe27fcba2224f3</em>" ){//江苏省通信管理局
                        url= httprq + '://jsca.miit.gov.cn' + url;
						webname = "所属站点：江苏省通信管理局 ";
                    }else if( Dwebid == "<em>17a7032dba33486aa0730140fe77cd35</em>" ){//上海市通信管理局
                        url= httprq + '://shca.miit.gov.cn' + url;
						webname = "所属站点：上海市通信管理局 ";
                    }else if( Dwebid == "<em>46e653bf5b344403bcf5a138feeebb0c</em>" ){//吉林省通信管理局
                        url= httprq + '://jlca.miit.gov.cn' + url;
						webname = "所属站点：吉林省通信管理局 ";
                    }else if( Dwebid == "<em>75fe7d5704aa4cd6a73fb3c937812d7f</em>" ){//浙江省通信管理局
                        url= httprq + '://zjca.miit.gov.cn' + url;
						webname = "所属站点：浙江省通信管理局 ";
                    }else if( Dwebid == "<em>418dde5534b64bbb991f32c2797c37fd</em>" ){//宁夏回族自治区通信管理局
                        url= httprq + '://nxca.miit.gov.cn' + url;
						webname = "所属站点：宁夏回族自治区通信管理局 ";
                    }else if( Dwebid == "<em>c833cafc883e47be96ecb00ea10a7a24</em>" ){//新疆维吾尔自治区通信管理局
                        url= httprq + '://xjca.miit.gov.cn' + url;
						webname = "所属站点：新疆维吾尔自治区通信管理局 ";
                    }else if( Dwebid == "<em>0e74139644d54ec09e667d081e8e785b</em>" ){//山西省通信管理局
                        url= httprq + '://sxca.miit.gov.cn' + url;
						webname = "所属站点：山西省通信管理局 ";
                    }else if( Dwebid == "<em>1a02ce9103214e3ebb11ee589691cfb8</em>" ){//辽宁省通信管理局
                        url= httprq + '://lnca.miit.gov.cn' + url;
						webname = "所属站点：辽宁省通信管理局 ";
                    }else if( Dwebid == "<em>54f03e8fc3c74d0d901c06928c20cc8b</em>" ){//黑龙江省通信管理局
                        url= httprq + '://hljca.miit.gov.cn' + url;
						webname = "所属站点：黑龙江省通信管理局 ";
                    }else{
                        url= '../../search-front-server/visit/link?url=' + url + '&amp;websiteid=' + webid + '&amp;q='
                    }
                }
            }

            var metaid = groupdata[0].data.metaid;
            var bexxgk = groupdata[0].data.bexxgk;

            //栏目id
            var columnid = groupdata[0].data.columnid;

            var infoleaderextends = groupdata[0].data.infoextends;
            var infoleaderarray = "";
            var leaderElementList = "";
            if(infoleaderextends != ""){
                infoleaderarray = JSON.parse(infoleaderextends);
                leaderElementList = infoleaderarray.elementList;
            }

            var pic = groupdata[0].data.picpath;
            //相似文章
            var similar;
            var similarcontent = "";
            var similardetail = "";
            if (groupdata.length > 1) {
                for (var i = 1; i < groupdata.length; i++) {
                    var urli = groupdata[i].data.url;
					var Dwebidi = groupdata[i].data.webid;
					var webnamei = "";
					/*
                    if( Dwebidi == "<em>19be5b068419473d8b805aa266b2f5f0</em>"){
                        urli = "https://ythxxfb.miit.gov.cn" + urli;
                    }
					*/

					if(Dwebidi == "<em>19be5b068419473d8b805aa266b2f5f0</em>"){
						if(urli.indexOf("http") == "-1"){
							urli = "https://ythxxfb.miit.gov.cn" + urli;
						}
					}else{
						if(urli.indexOf("http") == "-1"){
							if( Dwebidi == "<em>ec6bd4391c9a43fcb2adb4d5c0ccb1e6</em>" ){//四川省通信管理局
								urli= httprq + '://scca.miit.gov.cn' + urli;
								webnamei = "所属站点：四川省通信管理局 ";
							}else if( Dwebidi == "<em>9e105e416ada4a87884f4b83cd6646a8</em>" ){//内蒙古自治区通信管理局
								urli= httprq + '://nmca.miit.gov.cn' + urli;
								webnamei = "所属站点：内蒙古自治区通信管理局 ";
							}else if( Dwebidi == "<em>0fef8d742a87437fb68543959c47749a</em>" ){//陕西省通信管理局
								urli= httprq + '://shxca.miit.gov.cn' + urli;
								webnamei = "所属站点：陕西省通信管理局 ";
							}else if( Dwebidi == "<em>292c1b1f3eec48508c88f668a1ffdd8f</em>" ){//江西省通信管理局
								urli= httprq + '://jxca.miit.gov.cn' + urli;
								webnamei = "所属站点：江西省通信管理局 ";
							}else if( Dwebidi == "<em>d3af1320083e41178815869d3f9d081e</em>" ){//广西壮族自治区通信管理局
								urli= httprq + '://gxca.miit.gov.cn' + urli;
								webnamei = "所属站点：广西壮族自治区通信管理局 ";
							}else if( Dwebidi == "<em>eb31cdc9f10d4d169377d773df1de2ea</em>" ){//安徽省通信管理局
								urli= httprq + '://ahca.miit.gov.cn' + urli;
								webnamei = "所属站点：安徽省通信管理局 ";
							}else if( Dwebidi == "<em>61ffafe14b3f4ccc94ceafac68fd0b33</em>" ){//中国消费品三品战略
								urli= httprq + '://spzl.miit.gov.cn' + urli;
								webnamei = "所属站点：中国消费品三品战略 ";
							}else if( Dwebidi == "<em>ce44e901869b40dfa04d5517f6958a9d</em>" ){//中国中小企业信息网
								urli= httprq + '://zxqyxx.miit.gov.cn' + urli;
								webnamei = "所属站点：中国中小企业信息网 ";
							}else if( Dwebidi == "<em>a78336034387485e8193cadede928d03</em>" ){//天津市通信管理局
								urli= httprq + '://tjca.miit.gov.cn' + urli;
								webnamei = "所属站点：天津市通信管理局 ";
							}else if( Dwebidi == "<em>8538c551720443489f4410a90efaa24e</em>" ){//云南省通信管理局
								urli= httprq + '://ynca.miit.gov.cn' + urli;
								webnamei = "所属站点：云南省通信管理局 ";
							}else if( Dwebidi == "<em>e0e2c179f776433d8e2bf7b8b4d017f9</em>" ){//贵州省通信管理局
								urli= httprq + '://gzca.miit.gov.cn' + urli;
								webnamei = "所属站点：贵州省通信管理局 ";
							}else if( Dwebidi == "<em>6e331199dd13477a8edaf22f9c9ba1c2</em>" ){//重庆市通信管理局
								urli= httprq + '://cqca.miit.gov.cn' + urli;
								webnamei = "所属站点：重庆市通信管理局 ";
							}else if( Dwebidi == "<em>5babc0e79ce94951a4f24d7b992dd5ee</em>" ){//海南省通信管理局
								urli= httprq + '://hnca.miit.gov.cn' + urli;
								webnamei = "所属站点：海南省通信管理局 ";
							}else if( Dwebidi == "<em>2087b99b0d764438bb7fe1d1f81966a4</em>" ){//湖北省通信管理局
								urli= httprq + '://hubca.miit.gov.cn' + urli;
								webnamei = "所属站点：湖北省通信管理局 ";
							}else if( Dwebidi == "<em>6f4285f1275c40f4aeaf243a1d6e4439</em>" ){//福建省通信管理局
								urli= httprq + '://fjca.miit.gov.cn' + urli;
								webnamei = "所属站点：福建省通信管理局 ";
							}else if( Dwebidi == "<em>6c620603cc944086b9daf1a87047f63a</em>" ){//甘肃省通信管理局
								urli= httprq + '://gsca.miit.gov.cn' + urli;
								webnamei = "所属站点：甘肃省通信管理局 ";
							}else if( Dwebidi == "<em>5c0b3935e5114b75b2fcc84b0d5cd7b6</em>" ){//河北省通信管理局
								urli= httprq + '://hbca.miit.gov.cn' + urli;
								webnamei = "所属站点：河北省通信管理局 ";
							}else if( Dwebidi == "<em>2e1e2d7095dc4ff1bd767d43bc6f041c</em>" ){//广东省通信管理局
								urli= httprq + '://gdca.miit.gov.cn' + urli;
								webnamei = "所属站点：广东省通信管理局 ";
							}else if( Dwebidi == "<em>25b2fd3da2f44402bedeb4364e630274</em>" ){//北京市通信管理局
								urli= httprq + '://bjca.miit.gov.cn' + urli;
								webnamei = "所属站点：北京市通信管理局 ";
							}else if( Dwebidi == "<em>f109df7d3c8d4072af97285d27aa7515</em>" ){//青海省通信管理局
								urli= httprq + '://qhca.miit.gov.cn' + urli;
								webnamei = "所属站点：青海省通信管理局 ";
							}else if( Dwebidi == "<em>b9320314a8974379b06722b1509a0c31</em>" ){//河南省通信管理局
								urli= httprq + '://hca.miit.gov.cn' + urli;
								webnamei = "所属站点：河南省通信管理局 ";
							}else if( Dwebidi == "<em>0358b2276d1244a2819faf77e9ad0867</em>" ){//西藏自治区通信管理局
								urli= httprq + '://xzca.miit.gov.cn' + urli;
								webnamei = "所属站点：西藏自治区通信管理局 ";
							}else if( Dwebidi == "<em>6582b43ec020431c817da299a43ded43</em>" ){//湖南省通信管理局
								urli= httprq + '://hunca.miit.gov.cn' + urli;
								webnamei = "所属站点：湖南省通信管理局 ";
							}else if( Dwebidi == "<em>d0fdf9f4c8fd4134a079c5cd9cea6bb3</em>" ){//山东省通信管理局
								urli= httprq + '://sdca.miit.gov.cn' + urli;
								webnamei = "所属站点：山东省通信管理局 ";
							}else if( Dwebidi == "<em>cf6a2b1524b941d295fe27fcba2224f3</em>" ){//江苏省通信管理局
								urli= httprq + '://jsca.miit.gov.cn' + urli;
								webnamei = "所属站点：江苏省通信管理局 ";
							}else if( Dwebidi == "<em>17a7032dba33486aa0730140fe77cd35</em>" ){//上海市通信管理局
								urli= httprq + '://shca.miit.gov.cn' + urli;
								webnamei = "所属站点：上海市通信管理局 ";
							}else if( Dwebidi == "<em>46e653bf5b344403bcf5a138feeebb0c</em>" ){//吉林省通信管理局
								urli= httprq + '://jlca.miit.gov.cn' + urli;
								webnamei = "所属站点：吉林省通信管理局 ";
							}else if( Dwebidi == "<em>75fe7d5704aa4cd6a73fb3c937812d7f</em>" ){//浙江省通信管理局
								urli= httprq + '://zjca.miit.gov.cn' + urli;
								webnamei = "所属站点：浙江省通信管理局 ";
							}else if( Dwebidi == "<em>418dde5534b64bbb991f32c2797c37fd</em>" ){//宁夏回族自治区通信管理局
								urli= httprq + '://nxca.miit.gov.cn' + urli;
								webnamei = "所属站点：宁夏回族自治区通信管理局 ";
							}else if( Dwebidi == "<em>c833cafc883e47be96ecb00ea10a7a24</em>" ){//新疆维吾尔自治区通信管理局
								urli= httprq + '://xjca.miit.gov.cn' + urli;
								webnamei = "所属站点：新疆维吾尔自治区通信管理局 ";
							}else if( Dwebidi == "<em>0e74139644d54ec09e667d081e8e785b</em>" ){//山西省通信管理局
								urli= httprq + '://sxca.miit.gov.cn' + urli;
								webnamei = "所属站点：山西省通信管理局 ";
							}else if( Dwebidi == "<em>1a02ce9103214e3ebb11ee589691cfb8</em>" ){//辽宁省通信管理局
								urli= httprq + '://lnca.miit.gov.cn' + urli;
								webnamei = "所属站点：辽宁省通信管理局 ";
							}else if( Dwebidi == "<em>54f03e8fc3c74d0d901c06928c20cc8b</em>" ){//黑龙江省通信管理局
								urli= httprq + '://hljca.miit.gov.cn' + urli;
								webnamei = "所属站点：黑龙江省通信管理局 ";
							}else{
								urli= '../../search-front-server/visit/link?url=' + urli + '&amp;websiteid=' + webid + '&amp;q='
							}
						}
					}

                    similar = '<div class="jcse-similarly-item"><p><i></i><a target="_blank" href="' + urli + '" class="jcse-similarly-item-title" onclick="gotoLink()">' + groupdata[i].data.title_text + '</a><span class="similarcore">'+ webnamei +' 所属栏目：'+ groupdata[i].data.columnname+'- <span class="jcse-similarly-item-date">[' + dateFormat(groupdata[i].data.deploytime) + ']</span></span></p></div>';
                    similarcontent += similar;
                }
                similardetail = '<div class="jcse-similarly-box"> <div class="jcse-similarly-head"><a><span>相似文章<span></span></span></a></div> <div class="jcse-similarly-items">' + similarcontent + '</div>\n' +
                    '    </div>';
            }


            var sid = $('#input-searchid').val();
			//所属栏目 
			var xxdown = "";

            if (metaid == "beabab15c158409c990a3e4254377e8c" || metaid == "eccdf1857a19438399e15b893c571da0" || metaid == "e40704a3e49a418b8fc45c26f8eeb011" || metaid == "de6b2da5ee7d48e2a1767c05ee0a7ad9" || metaid == "1094d7290ba64ed8a39853e8c601303a" || metaid == "b2f79820c5164c0e9f8e74220e34576b" || metaid == "be5ad45c850b4f15add98158735f81e3" || metaid == "6ae5f027504e40ab8818ab1b97e65a12" || metaid == "81a6e08f44174a4a8554bda7c3c8747a" || metaid == "b7744984b0844fcf901ee8ca831e675a" || metaid == "cc020544f75d4c21911b2aac8bd4873c" || metaid == "29300e4f26254dee883c19cc83182979" || metaid == "cb5e0cbf4214432aa9de20a5ba0f5a34" || metaid == "52253a3da8d0464286f85c9e63596298" || metaid == "966704e098254acfb78ce539d08774a3" || metaid == "531a763482f64278b3e5cba6750e6180" || metaid == "cf9f9940e9d041d18928dc2daa34bde4" || metaid == "4f3bcf01e32a4a37a7c22e28ecd4e070"){
                if (leaderElementList) {
                    var strk = "";
                    if(metaid == "b2f79820c5164c0e9f8e74220e34576b"){
                        //执法人员
                        var t00 = leaderElementList[1].fieldTitle;
                        var t0 = leaderElementList[3].fieldTitle;
                        var t1 = leaderElementList[0].fieldTitle;
                        var t2 = leaderElementList[2].fieldTitle;

                        var v00 = leaderElementList[1].fieldValue;
                        var v0 = leaderElementList[3].fieldValue;
                        var v1 = leaderElementList[0].fieldValue;
                        var v2 = leaderElementList[2].fieldValue;
                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　";

                    }else if(metaid == "be5ad45c850b4f15add98158735f81e3"){
                        //执法事项
                        var t0 = leaderElementList[7].fieldTitle;
                        var t1 = leaderElementList[0].fieldTitle;
                        var t2 = leaderElementList[5].fieldTitle;
                        var t3 = leaderElementList[6].fieldTitle;
                        var t4 = leaderElementList[3].fieldTitle;
                        var t5 = leaderElementList[2].fieldTitle;
                        var t00 = leaderElementList[1].fieldTitle;

                        var v0 = leaderElementList[7].fieldValue;
                        var v1 = leaderElementList[0].fieldValue;
                        var v2 = leaderElementList[5].fieldValue;
                        var v3 = leaderElementList[6].fieldValue;
                        var v4 = leaderElementList[3].fieldValue;
                        var v5 = leaderElementList[2].fieldValue;
                        var v00 = leaderElementList[1].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　" +
                            t5 +"："+ v5 +"　"  ;
                    }else if(metaid == "beabab15c158409c990a3e4254377e8c"){
                        //标准规范
                        var t0 = leaderElementList[2].fieldTitle;
                        var t1 = leaderElementList[1].fieldTitle;
                        var t2 = leaderElementList[5].fieldTitle;
                        var t3 = leaderElementList[4].fieldTitle;
                        var t4 = leaderElementList[3].fieldTitle;
                        var t00 = leaderElementList[0].fieldTitle;

                        var v0 = leaderElementList[2].fieldValue;
                        var v1 = leaderElementList[1].fieldValue;
                        var v2 = leaderElementList[5].fieldValue;
                        var v3 = leaderElementList[4].fieldValue;
                        var v4 = leaderElementList[3].fieldValue;
                        var v00 = leaderElementList[0].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　"  ;
                    }else if(metaid == "e40704a3e49a418b8fc45c26f8eeb011"){
                        //批准开采黄金矿产的企业名单
                        var t0 = leaderElementList[0].fieldTitle;
                        var t1 = leaderElementList[5].fieldTitle;
                        var t2 = leaderElementList[4].fieldTitle;
                        var t3 = leaderElementList[3].fieldTitle;
                        var t4 = leaderElementList[7].fieldTitle;
                        var t5 = leaderElementList[1].fieldTitle;
                        //var t6 = leaderElementList[8].fieldTitle;
                        var t00 = leaderElementList[6].fieldTitle;

                        var v0 = leaderElementList[0].fieldValue;
                        var v1 = leaderElementList[5].fieldValue;
                        var v2 = leaderElementList[4].fieldValue;
                        var v3 = leaderElementList[3].fieldValue;
                        var v4 = leaderElementList[7].fieldValue;
                        var v5 = leaderElementList[1].fieldValue;
                        //var v6 = leaderElementList[8].fieldValue;
                        var v00 = leaderElementList[6].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　" +
                            t5 +"："+ v5 +"　"  ;
                    }else if(metaid == "eccdf1857a19438399e15b893c571da0"){
                        //新能源汽车动力蓄电池回收服务网点信息
                        var t0 = leaderElementList[5].fieldTitle;
                        var t1 = leaderElementList[6].fieldTitle;
                        var t2 = leaderElementList[0].fieldTitle;
                        var t3 = leaderElementList[1].fieldTitle;
                        var t4 = leaderElementList[2].fieldTitle;
                        var t00 = leaderElementList[4].fieldTitle;

                        var v0 = leaderElementList[5].fieldValue;
                        var v1 = leaderElementList[6].fieldValue;
                        var v2 = leaderElementList[0].fieldValue;
                        var v3 = leaderElementList[1].fieldValue;
                        var v4 = leaderElementList[2].fieldValue;
                        var v00 = leaderElementList[4].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　"  ;
                    }else if(metaid == "de6b2da5ee7d48e2a1767c05ee0a7ad9"){
                        //互联网电子公告服务专项审批及备案
                        var t0 = leaderElementList[5].fieldTitle;
                        var t1 = leaderElementList[8].fieldTitle;
                        var t2 = leaderElementList[7].fieldTitle;
                        var t3 = leaderElementList[6].fieldTitle;
                        var t4 = leaderElementList[4].fieldTitle;
                        var t5 = leaderElementList[3].fieldTitle;
                        var t6 = leaderElementList[2].fieldTitle;
                        var t7 = leaderElementList[9].fieldTitle;
                        var t00 = leaderElementList[1].fieldTitle;

                        var v0 = leaderElementList[5].fieldValue;
                        var v1 = leaderElementList[8].fieldValue;
                        var v2 = leaderElementList[7].fieldValue;
                        var v3 = leaderElementList[6].fieldValue;
                        var v4 = leaderElementList[4].fieldValue;
                        var v5 = leaderElementList[3].fieldValue;
                        var v6 = leaderElementList[2].fieldValue;
                        var v7 = leaderElementList[9].fieldValue;
                        var v00 = leaderElementList[1].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　" +
                            t5 +"："+ v5 +"　" +
                            t6 +"："+ v6 +"　" +
                            t7 +"："+ v7 +"　"  ;
                    }else if(metaid == "1094d7290ba64ed8a39853e8c601303a"){
                        //军工电子计量技术机构建立认定
                        var t0 = leaderElementList[0].fieldTitle;
                        var t1 = leaderElementList[6].fieldTitle;
                        var t2 = leaderElementList[1].fieldTitle;
                        var t3 = leaderElementList[3].fieldTitle;
                        var t4 = leaderElementList[5].fieldTitle;
                        var t5 = leaderElementList[2].fieldTitle;
                        var t6 = leaderElementList[7].fieldTitle;
                        var t00 = leaderElementList[4].fieldTitle;

                        var v0 = leaderElementList[0].fieldValue;
                        var v1 = leaderElementList[6].fieldValue;
                        var v2 = leaderElementList[1].fieldValue;
                        var v3 = leaderElementList[3].fieldValue;
                        var v4 = leaderElementList[5].fieldValue;
                        var v5 = leaderElementList[2].fieldValue;
                        var v6 = leaderElementList[7].fieldValue;
                        var v00 = leaderElementList[4].fieldValue;

                        strk +=  t0 +"："+ v0 +"　" +
                            t1 +"："+ v1 +"　" +
                            t2 +"："+ v2 +"　" +
                            t3 +"："+ v3 +"　" +
                            t4 +"："+ v4 +"　" +
                            t5 +"："+ v5 +"　" +
                            t6 +"："+ v6 +"　"  ;
                    }else{
                        for (var i = leaderElementList.length; i > 0 ; i--) {
                            var lv = leaderElementList[(i-1)].fieldValue;
                            if(lv != "" && lv != null){
                                strk +=  leaderElementList[(i-1)].fieldTitle +"："+ leaderElementList[(i-1)].fieldValue +" "
                            }
                        }
                    }
					
					xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                    resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a href="'+ url +
                        '" target="_blank" onclick="gotoLink()"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + strk +
                        '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                }
                data += resulthtml;

            }else{

                //领导信息
                if (metaid == "d874dec0e267498d8f8a7f4e88288b99") {
                    //职务
                    var post;
                    //简介
                    var brief;
                    //个人简历链接
                    var grjllink;
                    //主管工作地址
                    var zggzlink;
                    //领导活动地址
                    var ldhdlink;
                    //图片集锦地址
                    var tpjjlink;
                    //照片
                    var tophoto;
                    if (leaderElementList) {
                        for (var i = 0; i < leaderElementList.length; i++) {
                            post = leaderElementList[0].fieldValue;
                            brief = leaderElementList[1].fieldValue;
                            grjllink = leaderElementList[2].fieldValue;
                            zggzlink = leaderElementList[3].fieldValue;
                            ldhdlink = leaderElementList[4].fieldValue;
                            tpjjlink = leaderElementList[5].fieldValue;
                            tophoto = leaderElementList[6].fieldValue;
                        }
                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;"><div class="clearfix"><div class="imgLeft ldxx-l fl"><img src="' + pic +
                            '" alt="" width="122" style="height:auto;"></div><div class="txtRight ldxx-r fr"><a href="' + url + '" target="_blank" onclick="gotoLink()"><div class="itemdiv">' + post + '</div></a><p>' + brief +
                            '</p><a onclick="gotoLink()" href="' + grjllink + '" target="_blank"><span>个人简历</span></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onclick="gotoLink()" href="' + zggzlink +
                            '" target="_blank"><span>主管工作</span></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onclick="gotoLink()" href="' + ldhdlink + '" target="_blank"><span>重要活动</span></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a onclick="gotoLink()" href="' + tpjjlink + '" target="_blank"><span>图片集锦</span></a></div></div></div>';
                        data += resulthtml;
                    }

                }
                //办事事项
                else if (metaid == "fde2f9dc66eb4be9bbe183ec1b243c69") {
                    //政务服务站点-办事指南
                    resulthtml = '<div class="jcse-result-box news-result news-result2" style="display: block;"><div class="list item1"><div class="clearfix"><dl><dt>办事指南</dt><a onclick="gotoLink()" href="' + url + '" target="_blank"><div class="itemdiv">' + groupdata[0].data.title_text + '</div></a></dl></div></div></div>';
                    data += resulthtml;

                    /*已废弃
                                    var jgcxaddress;
                                    var zxzxaddress;
                                    if (leaderElementList) {
                                        for (var i = 0; i < leaderElementList.length; i++) {
                                            jgcxaddress = leaderElementList[0].fieldValue;
                                            zxzxaddress = leaderElementList[1].fieldValue;
                                        }
                                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;"><div class="list item5"><a\n' +
                                            '        href="' + url + '" target="_blank"\n' +
                                            '        title=""><div class="itemdiv">' + groupdata[0].data.title_text + '</div></a>\n' +
                                            '    <div class="clearfix">\n' +
                                            //'        <div class="lm"></div>\n' +
                                            '    </div>\n' +
                                            '</div></div>';
                                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;"><div class="list item5"><a\n' +
                                            '        href="' + url + '" target="_blank"\n' +
                                            '        title=""><div class="itemdiv">' + groupdata[0].data.title_text + '</div></a>\n' +
                                            '    <div class="clearfix">\n' +
                                            '        <div class="lm"><a href="' + jgcxaddress + '" target="_blank">结果查询</a> <a\n' +
                                            '                href="' + zxzxaddress + '" target="_blank">在线咨询</a></div>\n' +
                                            '    </div>\n' +
                                            '</div></div>';


                                    }
                    */
                } else {
                    //除领导介绍及办事事项外所有
                    //投诉类信息
                    if(!bexxgk && columnid == "ef2e828ca50046dfb7cf368efb7ea735"){
                        var tousupng = $('.tousuimg').attr('src');
                        resulthtml = '<div class="jcse-result-box news-result news-result2" style="display: block;"><div class="list item1"><div class="clearfix"><dl><dt><img src="'+tousupng+'" style="padding-left: 20px;padding-top: 3px;"></dt><a onclick="gotoLink()" href="' + url + '" target="_blank"><div class="itemdiv">' + groupdata[0].data.title_text + '</div></a></dl></div></div></div>';
                        data = data + resulthtml;
                    }
                    else if(!bexxgk && columnid == "ddfe2e26152b432290990098b009068e" ){
                        //机关司局类型
                        var sectitle = groupdata[0].data.sectitle;
                        resulthtml = '<div class="jcse-result-box news-result news-result2" style="display: block;"><div class="list item1"><div class="clearfix"><dl><dt>司局子站</dt><a onclick="gotoLink()" href="' + url + '" target="_blank"><div class="itemdiv">' + groupdata[0].data.title_text + sectitle + '</div></a></dl></div></div></div>';
                        data = data + resulthtml;
                    }
                    else if (bexxgk == 1) {
                        //信息公开类信息
                        if(!groupdata[0].data.themename){

                            if (leaderElementList) {
                                /*
                                for (var i = 0; i < leaderElementList.length; i++) {
                                    content0 = leaderElementList[0].fieldValue;
                                    content = content0.replace(/<[^>]+>/g,"");
                                }
                                */

                                var phopathArray = extract(infoleaderextends);
                                var phLength = 0;
                                if (phopathArray) {
                                    phLength = phopathArray.length;
                                }
                                if (phLength == 0) {
									xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                    resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url + '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                        '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                                    data += resulthtml;
                                } else if (phLength == 1) {
									xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                    resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item3">\n' +
                                        '        <a href="'+ url +'" target="_blank" onclick="gotoLink()">\n' +
                                        '            <div class="itemdiv">' + title + '</div>\n' +
                                        '        </a>\n' +
                                        '        <div class="clearfix">\n' +
                                        '            <div class="imgLeft fl">\n' +
                                        '                <img src="' + phopathArray[0] + '" width="142" height="104">\n' +
                                        '            </div>\n' +
                                        '            <div class="txtRight fr">\n' +
                                        '                <p>' + content + '</p>' + xxdown + '</div>\n' +
                                        '        </div>\n' +
                                        '    </div>'+similardetail+'</div>';
                                    data += resulthtml;
                                } else if(phLength == 2) {
									xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                    resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                        '        <a href="'+ url +'"  onclick="gotoLink()" target="_blank">\n' +
                                        '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                        '        </a>\n' +
                                        '        <div class="clearfix">\n' +
                                        '            <div class="tpList clearfix">\n' +
                                        '                <div class="imgLeft fl">\n' +
                                        '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                        '                </div>\n' +
                                        '                <div class="imgLeft fl">\n' +
                                        '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                        '                </div>\n' +
                                        '            </div>' + xxdown + '</div>\n' +
                                        '    </div>'+similardetail+'</div>';
                                    data += resulthtml;
                                } else if(phLength >= 3) {
									xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                    resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                        '        <a href="'+ url +'" onclick="gotoLink()" target="_blank">\n' +
                                        '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                        '        </a>\n' +
                                        '        <div class="clearfix">\n' +
                                        '            <div class="tpList clearfix">\n' +
                                        '                <div class="imgLeft fl">\n' +
                                        '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                        '                </div>\n' +
                                        '                <div class="imgLeft fl">\n' +
                                        '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                        '                </div>\n' +
                                        '                <div class="imgLeft fl">\n' +
                                        '                    <img src="'+phopathArray[2]+'" width="194" height="144">\n' +
                                        '                </div>\n' +
                                        '            </div>' + xxdown + '</div>\n' +
                                        '    </div>'+similardetail+'</div>';
                                    data += resulthtml;

                                }

                            }else{
                                //content = groupdata[0].data.infocontent;
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url +
                                    '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                    '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                                data += resulthtml;
                            }

                        }else{
							xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                            resulthtml = '<div class="jcse-result-box news-result" style="display: block;"><div class="list item2">\n' +
                                '    <div class="clearfix">\n' +
                                '        <div class="frro">\n' +
                                '            <a onclick="gotoLink()" href="' + url + '"\n' +
                                '               target="_blank"><div class="itemdiv">' + groupdata[0].data.title_text + '\n' +
                                '            </div>\n' +
                                '            </a>\n' +
                                '            <div class="extendAttr">\n' +
                                '                <dl>\n' +
                                '                    <dt>主题分类<i></i></dt>\n' +
                                '                    <dd>' + groupdata[0].data.themename + '</dd>\n' +
                                '                </dl>\n' +
                                '                <dl>\n' +
                                '                    <dt>成文日期<i></i></dt>\n' +
                                '                    <dd>' + dateFormat(groupdata[0].data.deploytime) + '</dd>\n' +
                                '                </dl>\n' +
                                '                <dl>\n' +
                                '                    <dt>发布机构<i></i></dt>\n' +
                                '                    <dd>' + groupdata[0].data.publishgroupname + '</dd>\n' +
                                '                </dl>\n' +
                                '            </div>\n' +
                                '            <p style="height: 100px"></p>' + xxdown + '</div>\n' +
                                '    </div>\n' +
                                '</div></div>';
                            data += resulthtml;
                        }

                    } else if(!bexxgk && bexxgk != 1 && metaid == "c5c3da465e61429995043ffaa84cd30d"){//多信息 除其他特殊栏目以外

                        if (leaderElementList) {
                            //content = groupdata[0].data.infocontent;
                            //content = groupdata[0].data.infoextends.substring(groupdata[0].data.infoextends.indexOf('\\\"fieldValue\\\":\\\"'),groupdata[0].data.infoextends.indexOf('\",\"metaId\"'));
                            var phopathArray = extract(infoleaderextends);
                            var phLength = 0;
                            if (phopathArray) {
                                phLength = phopathArray.length;
                            }

                            if (phLength == 0) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="' + url +
                                    '"  target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                    '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if (phLength == 1) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item3">\n' +
                                    '        <a onclick="gotoLink()" href="'+  url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">' + title + '</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="imgLeft fl">\n' +
                                    '                <img src="' + phopathArray[0] + '" width="142" height="104">\n' +
                                    '            </div>\n' +
                                    '            <div class="txtRight fr">\n' +
                                    '                <p>' + content + '</p>' + xxdown + '</div>\n' +
                                    '        </div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if(phLength == 2) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                    '        <a onclick="gotoLink()" href="'+ url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="tpList clearfix">\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '            </div>' + xxdown + '</div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if(phLength >= 3) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                    '        <a onclick="gotoLink()" href="'+ url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="tpList clearfix">\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[2]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '            </div>' + xxdown + '</div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            }

                        }else{
							xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                            resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url +
                                '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                            data += resulthtml;
                        }
                        //content = groupdata[0].data.infoextends.substring(groupdata[0].data.infoextends.indexOf('"fieldValue\\\":\\\"'),groupdata[0].data.infoextends.indexOf('\",\"metaId\"')).replace(/<[^>]+>/g,"")

                    }else if(!bexxgk && bexxgk != 1 && metaid == "ad47b8968a934d00afbdbb1778708b3e"){
                        //局长信箱
                        if (leaderElementList) {
                            rpcontent = leaderElementList[0].fieldValue;
                        }
                        rpcontent = rpcontent.replace(/<[^>]+>/g,"");
						xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url +
                            '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + rpcontent +
                            '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                        data += resulthtml;

                    }else if((!bexxgk && bexxgk != 1 && metaid != "c5c3da465e61429995043ffaa84cd30d") || metaid != "ad47b8968a934d00afbdbb1778708b3e"){
                        if (leaderElementList) {
                            //content = groupdata[0].data.infocontent;
                            //content = groupdata[0].data.infoextends.substring(groupdata[0].data.infoextends.indexOf('\\\"fieldValue\\\":\\\"'),groupdata[0].data.infoextends.indexOf('\",\"metaId\"'));
                            var phopathArray = extract(infoleaderextends);
                            var phLength = 0;
                            if (phopathArray) {
                                phLength = phopathArray.length;
                            }

                            if (phLength == 0) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="' + url +
                                    '"  target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                    '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if (phLength == 1) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item3">\n' +
                                    '        <a onclick="gotoLink()" href="'+  url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">' + title + '</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="imgLeft fl">\n' +
                                    '                <img src="' + phopathArray[0] + '" width="142" height="104">\n' +
                                    '            </div>\n' +
                                    '            <div class="txtRight fr">\n' +
                                    '                <p>' + content + '</p>' + xxdown + '</div>\n' +
                                    '        </div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if(phLength == 2) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                    '        <a onclick="gotoLink()" href="'+ url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="tpList clearfix">\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '            </div>' + xxdown + '</div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            } else if(phLength >= 3) {
								xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                                resulthtml = '<div class="jcse-result-box news-result" style="display: block;">'+'<div class="list item4">\n' +
                                    '        <a onclick="gotoLink()" href="'+ url +'" target="_blank">\n' +
                                    '            <div class="itemdiv">'+groupdata[0].data.title_text+'</div>\n' +
                                    '        </a>\n' +
                                    '        <div class="clearfix">\n' +
                                    '            <div class="tpList clearfix">\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[0]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[1]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '                <div class="imgLeft fl">\n' +
                                    '                    <img src="'+phopathArray[2]+'" width="194" height="144">\n' +
                                    '                </div>\n' +
                                    '            </div>' + xxdown + '</div>\n' +
                                    '    </div>'+similardetail+'</div>';
                                data += resulthtml;
                            }

                        }else{
							xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                            resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url +
                                '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                                '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                            data += resulthtml;
                        }

                        /*
                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a href="'+ url +
                            '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                        data += resulthtml;
                        */

                    }else{
						xxdown = '<span>'+ webname + '所属栏目：' + columnname + ' 发布时间：' + deploytime + '</span>';
                        resulthtml = '<div class="jcse-result-box news-result" style="display: block;">' + '<div class="list item2"><div class="clearfix">	<div class="txtRight frro" style="float:left"><a onclick="gotoLink()" href="'+ url +
                            '" target="_blank"><div class="itemdiv" alt="' + groupdata[0].data.title_text + '">' + groupdata[0].data.title_text + '</div></a><p>' + content +
                            '</p>' + xxdown + '</div></div></div>'+similardetail+'</div>';
                        data += resulthtml;

                    }

                }
            }
        }


    });
    return data;
};

//切换分类组，渲染信息
var manage_search = function () {
    var $search_manages = $('.search-manage');

    $search_manages.each(function (index, searchmanage) {
        $(searchmanage).click(function () {
            $('#input-searchid').val($(this).data("searchmanageid"));
            //$('#cateid').val($(this).data("searchmanageid"));
            cate_init();
            relateImages();
            mainframe_search();
            plugin_criterias_init();
            spellcheck();
            //pagination(parseInt(1), pg);
        });
    });


};

//处理图片
function extract(infoextends) {
    var picArray = new Array();
    if (!infoextends) {
        return picArray;
    }
    //var imgReg = /<img title=\\\\\\.*?(?:>|\/>)/gi;
    var imgReg = /<img\b.*?(?:\>|\/>)/gi;

	infoextends = infoextends.replace("https://jyhwzhq.miit.gov.cn","");
    var arr = infoextends.match(imgReg);
    if (arr && arr.length > 0) {
        var srcReg = /src=\\\\\\\"([^\'\"]*)\\\\\\\"/i;
        //var srcReg = /\bsrc\b\s*=\s*[\'\"]?([^\'\"]*)[\'\"]?/i;
        //var srcReg = /<img.+?src=('|")?([^'"]+)('|")?(?:\s+|>)/i;

        for (var i = 0; i < arr.length; i++) {
            var src = arr[i].match(srcReg);
            //获取图片地址
            if (src && src.length >= 2) {
                var pic = src[1];
                if (pic && $.inArray(pic, picArray) == -1) {
                    picArray.push(pic);
                }
            }
        }
    }
    return picArray;
}


//格式化数字 每三个后加逗号
function toThousands(num) {
    var result = [ ], counter = 0;
    num = (num || 0).toString().split('');
    for (var i = num.length - 1; i >= 0; i--) {
        counter++;
        result.unshift(num[i]);
        if (!(counter % 3) && i != 0) { result.unshift(','); }
    }
    return result.join('');
}



$(function () {
    var q = getQueryString("q");
    //  search_init();
    $("#q").val(q);

    $('#webid').val(getQueryString('websiteid'));
    webid = $("#webid").val();

    var datasearchmanage = "websiteid=" + getQueryString('websiteid') + "&depth=0" + "&callback=";
    //$('#input-searchid').val($('#search-form').data('initwebsiteid'));
    $('#webid').val(getQueryString('websiteid'));


    searchmanage_init(datasearchmanage);

    //pagination(parseInt(1), pg);

    $('.ipt_btn').click(function () {
        cate_init();
        mainframe_search();
        relateImages();
        //setCookie('_q', escape($('#q').val()) , 60 * 60 * 24 * 30);
        setCq();

        spellcheck();
        plugin_criterias_init();
    });



    //$("#jsearch-condition-box-content").append('<div class="sch-total"><span class="mergeeaction">此分类下为您找到相关结果约<span class="maction"></span>条</span></div>');

    $(".sjk-sxicon").toggle(function(){
        $(this).css("color","#999");
        $(this).siblings("ol").css("height","auto");
    },function(){
        $(this).css("color","#000");
        $(this).siblings("ol").css("height","30px");
    });
    $(".ruleName li").click(function(){
        $(this).addClass("hover").siblings("li").removeClass("hover");
        $("#sjk-sx").val($(this).attr("title"));
        search_init();
    });
});