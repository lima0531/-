// JavaScript Document
$(function(){
	placeholder.init();
	bindSearchForm();
//pagination();
	configMic();
	expandCateMerge();
	
    
});
// placeholder
var placeholder = {
	obj:null,
	init:function(){
		this.obj = $('.ui-placehoder');
		this.obj.click(function(){
			$('#q').focus();
		});
	},
	show:function(callBack){
		if(getQval()!=''){
			return;
		}
		this.obj.show(0, function(){
			if(callBack){
				callBack();
			}
		});
	},
	hide:function(callBack){
		this.obj.hide(0, function(){
			if(callBack){
				callBack();
			}
		});
	}
};
// 搜索
function firstPageSearch(){
	$('#p').val(1);
	$('#search-form').submit();
}
// 获得搜索框的值
function getQval(){
	return $.trim($('#q').val());
}
// 绑定输入框
function bindSearchForm(){
	$('#q').focus(function(){
		$(this).addClass('hover');
		placeholder.hide();
	}).blur(function(){
		$(this).removeClass('hover');
		placeholder.show();
	});

	$('#search-form').submit(function(){
		var q = getQval();
		/**
		if(q.length == 0){
			$('#q').focus();
			return false;
		}
		*/
		var maxlength = $('#q').attr('maxlength');
		if(q.length > maxlength){
			alert('检索词限制在' + maxlength + '个汉字以内');
			return false;
		}
		return true;
	}).keydown(function(event){
		if(event.keyCode == 13){
			firstPageSearch();
			return false;
		}
	});
	
	if($.trim(getQval()).length == 0){
		$('#q').focus();
	}
	
	$('.ui-search-btn').click(function(){
		firstPageSearch();
	});
}
// 设置麦克风
function configMic(){
	$('#jsearch-microphone-setup').click(function(){
		var src = $('#jsearch-microphone embed').attr('src');
		layer.open({
			type: 2,
			title: '语音设置',
			shadeClose: true,
			shade: 0.3,
			shift:9,
			area: ['400px', '300px'],
			content: src, //iframe的url
			btn: ['确定', '取消'],
			yes:function(index, layero){
				top.location.reload();
				layer.close(index);
			}
		}); 
	});
}
// 麦克风设置值
function setTxtValue(value){
	if(value && $.trim(value).length > 0){
		$('#q').val(value);
		firstPageSearch();
	}
}
/**
 * Ajax方式提交表单
 * 
 * @param url
 * @param setting
 * @returns
 */
function ajaxSubmit(url,setting){
	var opt = {
		async : true,
		type:'html',
		contentType : 'application/x-www-form-urlencoded',

		success:function(){},
		complete:function(){},
		data:null
	};
	opt = $.extend(opt, setting);
	$.ajax({
		type: "post",
		url: url,
		dataType: opt.type,
		error : opt.error,
		contentType : opt.contentType,
		data:opt.data,
		success : opt.success,
		complete:opt.complete
	});
}

function ajaxGet(url,setting){
	var opt = {
		async : true,
		type:'html',
		contentType : 'application/x-www-form-urlencoded',

		success:function(){},
		complete:function(){},
		data:null
	};
	opt = $.extend(opt, setting);
	$.ajax({
		type: "get",
		url: url,
		dataType: opt.type,
		error : opt.error,
		contentType : opt.contentType,
		data:opt.data,
		success : opt.success,
		complete:opt.complete
	});
}
// 分页
/*function pagination(){
	var p = parseInt($("#p").val())
	var pg = parseInt($('#pg').val());
	var total = $("#total").val();
	var pageCount = total%pg==0?total/pg:total/pg+1;
	if(pageCount < 2){
		return;
	}
	if($("#pagination").myPagination){
		$("#pagination").myPagination({
			cssStyle: 'manu',
			pageNumber : 10,
			currPage : p,
			pageCount : pageCount,
			ajax:{
				onClick:function(page){
					$('#p').val(page);
					$('#search-form').submit();
				}
			},
			panel:{
				links: "javascript:void(0);",
				first_on:true,
				last_on:false
			}
		});
	}
} */

function limitText(text, length){
	if(!length){
		length = 19;
	}
	//alert(text.length);
	if(text.length > length){
		text = text.substring(0,length-1) + '...';
	}
	return text;
}

function changeCate(cateSign){
	$('#category').val(cateSign);
	firstPageSearch();
}

function expandCateMerge(){
	$('.jsearch-category-merge').each(function(index, obj){
		var expandBtn = $(this).find('.jsearch-category-merge-expand-btn');//jsearch-category-merge-expand-btn
		var infoUl = $(this).find('ul');
		expandBtn.click(function(){
			infoUl.slideToggle();
		});
	});
}

function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) {
		return decodeURIComponent(r[2]);
	}
}

//设置cookie值
function setCookie(name, value, seconds) {
	//seconds有值就直接赋值，没有为0，这个根php不一样。
	seconds = seconds || 0;
	var cookie = getqCookie(name);
	var cvalue = cookie;
	var cvalueArray = "";
	if(cookie.indexOf(value) == -1 && value){
		cvalue = value+":"+cookie;
		cvalueArray = cvalue.split(":"+value);
	}
	if(cvalueArray.length>8){
		cvalue = cvalueArray[0];
	}
	var expires = "";
	if (seconds != 0 ) {
		var date = new Date();
		date.setTime(date.getTime()+(seconds*1000));
		expires = "; expires="+date.toGMTString();
	}
	document.cookie = name+"="+escape(cvalue)+expires+"; path=/";   //转码并赋值
}


function getqCookie(name) {
	var nameEQ = name + '='
	var ca = document.cookie.split(';') // 把cookie分割成组
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i] // 取得字符串
		while (c.charAt(0) == ' ') { // 判断一下字符串有没有前导空格
			c = c.substring(1, c.length) // 有的话，从第二位开始取
		}
		if (c.indexOf(nameEQ) == 0) { // 如果含有我们要的name
			return unescape(c.substring(nameEQ.length, c.length)) // 解码并截取我们要值
		}
	}
	return "";
}


function doKeyDown(){
	if (event.keyCode==13)  //回车键的键值为13
		document.getElementById("ipt_btn").click(); //调用登录按钮的登录事件
}

var dateFormat = function (timestamp) {
	var times = parseInt(timestamp);
	var date = new Date(times);
	var y = date.getFullYear();
	var m = date.getMonth() + 1;
	m = m < 10 ? ('0' + m) : m;
	var d = date.getDate();
	d = d < 10 ? ('0' + d) : d;
	return y + '-' + m + '-' + d  ;
};

function setTab(name, cursel, n) {
	for (var i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("con_" + name + "_" + i);
		var more = document.getElementById("more_" + name + "_" + i);
		menu.className = i == cursel ? "hover" : "";
		con.style.display = i == cursel ? "block" : "none";
		more.style.display = i == cursel ? "block" : "none";
	}
}

function setTab2(name, cursel, n) {
	for (i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("con_" + name + "_" + i);
		menu.className = i == cursel ? "hover" : "";
		con.style.display = i == cursel ? "block" : "none";
	}
}

function setTab3(name, cursel) {
	if ($('#' + name + cursel).hasClass("hover")) {
		return;
	} else {
		$('.search-manage').removeClass("hover");
		$('#' + name + cursel).addClass("hover");
	}
}


