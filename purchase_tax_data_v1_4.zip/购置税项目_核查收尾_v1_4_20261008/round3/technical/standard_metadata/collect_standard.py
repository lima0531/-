import urllib.request,urllib.parse,json,hashlib,concurrent.futures,pathlib,datetime
P=pathlib.Path(__file__).parent
H={'User-Agent':'Mozilla/5.0','Referer':'https://www.miit.gov.cn/search/'}
def fetch(name,url,suffix='.html'):
 target=P/(name+suffix)
 receipt=P/(name+'_receipt.json')
 if target.exists() and receipt.exists() and json.loads(receipt.read_text()).get('status')==200:return target.read_bytes()
 r={'url':url,'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls_verification':True}
 b=b''
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers=H),timeout=25) as q:
   b=q.read();r.update(status=q.status,content_type=q.headers.get('Content-Type'),final_url=q.geturl(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());target.write_bytes(b)
 except Exception as e:r['error']=str(e)
 receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2));print(name,json.dumps(r,ensure_ascii=False),flush=True)
 return b

def search(name,q,pos='title_text,titlepy,infocontent',begin='',end='',eq=''):
 params=dict(websiteid='110000000000000',scope='basic',q=q,pg='40',p='1',cateid='47',pos=pos,pq='',oq='',eq=eq,begin=begin,end=end,dateField='deploytime',selectFields='title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode',group='distinct',highlightConfigs='[{"field":"infocontent","numberOfFragments":2,"fragmentOffset":0,"fragmentSize":110,"noMatchSize":110}]',highlightFields='title_text,infocontent,webid',level='6',sortFields='[{"name":"deploytime","type":"desc"}]',hidCol='fbafd13557fa453d9c59432567d2b150')
 raw=fetch(name,'https://www.miit.gov.cn/search-front-server/api/search/info?'+urllib.parse.urlencode(params),'.json')
 if not raw:return []
 j=json.loads(raw);found=[]
 def walk(x):
  if isinstance(x,dict):
   if 'title' in x and 'url' in x:found.append(x)
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(j.get('data',{}).get('searchResult',{}).get('dataResults'))
 (P/(name+'_hits.json')).write_text(json.dumps(found,ensure_ascii=False,indent=2))
 print(name,[(x['title'],x['url']) for x in found],flush=True)
 return found
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
  list(ex.map(lambda x:search(*x),[
   ('standard_miit','18386.1'),
   ('policy32_title_miit','调整减免车辆购置税新能源汽车产品技术要求','title_text,titlepy','2023-12-01','2024-01-01'),
  ]))
