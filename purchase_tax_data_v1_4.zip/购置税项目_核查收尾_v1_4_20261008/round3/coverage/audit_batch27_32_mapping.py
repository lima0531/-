"""Independently prove the withdrawal-source/date misattachment and emit corrections.
Original event identifiers are opaque historical identifiers; preserve them and source
record ids while changing the source mapping and public-observation date.
"""
import csv,hashlib,json,re,unicodedata,collections,sys,html
from pathlib import Path
R=Path(__file__).resolve().parent;B=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008');A=R.parent/'archive';D=R.parent/'dates/main_25_31'
sys.path.insert(0,str(A));from word_piece_text import extract
SHA='c388317a1453e6b139a2a67bd21e4b5818d6711b0982feb55626f0ac886783ff';LATE='e349cf92d67a6f5d53457260d1cf9b06ef30f594181efd7cbea0528f8d302c46';DATE='2019-10-25';OLD='2020-06-02';URL='https://www.miit.gov.cn/jgsj/zbys/gzdt/art/2020/art_9f09e324e0064eb6ac473ff2949f699c.html'
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(n,rows,fields=None):
 with (R/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s)).upper()
manifest=read(A/'106原件公开回收清单.csv');early_path=Path(next(x['recovered_path'] for x in manifest if x['source_sha256']==SHA));late_path=Path(next(x['local_path'] for x in json.loads((A/'attachment_manifest.json').read_text()) if x.get('sha256')==LATE))
proofs=[];versions=[]
for p,want in [(early_path,SHA),(late_path,LATE)]:
 t,proof=extract(p);assert proof['source_sha256']==want;cells=[x.strip() for x in t.split('\t')];assert cells[1:6]==['企业名称','车辆型号','目录发布产品名称','批次','备注'];start=cells.index('1');rows=[]
 for i in range(424):
  c=cells[start+i*7:start+(i+1)*7];assert c[0]==str(i+1) and c[6]=='';rows.append(c[:6])
 assert not any(cells[start+424*7:]);versions.append(rows);proofs.append(proof)
assert [x[:5] for x in versions[0]]==[x[:5] for x in versions[1]]
remark_diffs=[{'sequence':i+1,'model_key':norm(x[2]),'earlier_remark':x[5],'later_remark':y[5]} for i,(x,y) in enumerate(zip(*versions)) if x[5]!=y[5]]
assert len(remark_diffs)==1 and remark_diffs[0]['sequence']==42
page27=(D/'batch27_department_primary.html').read_text();page27late=(D/'batch27_primary.html').read_text();page32=Path(next(x['local_path'] for x in json.loads((A/'page_manifest.json').read_text()) if x['system']=='免征目录' and x['batch']=='32')).read_text();tax=(R/'raw/batch32_legacy_tax_reference.html').read_text()
assert '发布时间：2019-10-25' in page27 and '7485456.doc' in page27
assert '发布时间：2019-10-30' in page27late and '7494591.doc' in page27late
assert '第二十七批' in tax and '2019年第45号' in tax and '2019-10-25' in tax
# Inspect every currently published 32-page annex rather than trust the link labels.
annex32=Path(next(x['recovered_path'] for x in manifest if x['source_file']=='mf_batch32.doc'));t32,p32=extract(annex32);trename,renameproof=extract(R/'raw/batch32_annex2_company_rename.doc')
assert '第三十二批' in t32 and '撤销' not in t32
assert '汽车生产企业名称变更名单' in trename and '撤销' not in trename
assert '撤销' not in html.unescape(re.sub('<[^>]+>','',page32))
# Match all 424 source rows to the supplied semantic rows independently of cohort.
history=read(B/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv');selected=[x for x in history if x['原件SHA256']==SHA];assert len(selected)==424
assert [norm(c[2]) for c in versions[0]]==[x['model_key'] for x in selected]
assert [norm(c[3]) for c in versions[0]]==[norm(x['目录发布产品名称']) for x in selected]
events=read(B/'研究数据/资格事件_重建去重表.csv');links=read(B/'研究数据/资格事件_逐原件连接.csv');target_links=[x for x in links if x['source_sha256']==SHA];ids={x['event_id'] for x in target_links};target_events=[x for x in events if x['event_id'] in ids];assert len(target_events)==len(target_links)==47
cohort_keys={x['model_key'] for x in read(B/'研究数据/样本成员重建.csv')};assert len(set(norm(c[2]) for c in versions[0])&cohort_keys)==47
basis='第27批较早主管部门现存原页登记公开观察日2019-10-25；第32批误挂修复；保留10-30另一发布页差异；不认证法定生效或历史首次上线'
corrected_events=[];corrected_links=[];overlays=[]
for x in target_events:
 assert x['event_batch']=='32' and x['publish_date_exact']==OLD
 y=dict(x,event_batch='27',publish_date_exact=DATE,public_date_lower_bound=DATE,public_date_upper_bound=DATE,event_date_basis=basis,source_batches='27');corrected_events.append(y)
 link=next(z for z in target_links if z['event_id']==x['event_id']);assert link['source_batch']=='32'
 overlays.append({'event_id':x['event_id'],'model_key':x['model_key'],'source_record_id':link['source_record_id'],'source_sha256':SHA,'old_event_batch':'32','new_event_batch':'27','old_source_batch':'32','new_source_batch':'27','old_publish_date_exact':OLD,'new_publish_date_exact':DATE,'old_public_date_lower_bound':x['public_date_lower_bound'],'new_public_date_lower_bound':DATE,'old_public_date_upper_bound':x['public_date_upper_bound'],'new_public_date_upper_bound':DATE,'new_signed_date_registered':DATE,'evidence_url':URL,'evidence_file':str(D/'batch27_department_primary.html'),'evidence_sha256':hashlib.sha256((D/'batch27_department_primary.html').read_bytes()).hexdigest(),'event_id_preserved':'1','source_record_id_preserved':'1','legal_effective_date':'','legal_effective_date_verified':'0'})
for x in target_links:
 corrected_links.append(dict(x,event_batch='27',source_batch='27',publish_date_exact=DATE,public_date_lower_bound=DATE,public_date_upper_bound=DATE,event_date_basis=basis,source_parameter_observation_lower=DATE,source_parameter_observation_upper=DATE))
semantic=[];semantic_overlay=[]
for x in selected:
 y=dict(x);changes={'撤销公告批次':'27','撤销事件日':DATE,'撤销事件日_raw':DATE,'撤销观察日':DATE,'signed_date':DATE,'signed_date_is_verified':'1','publish_date_is_verified':'1','date_basis':basis,'publish_date_source_url':URL,'signed_date_source_url':URL,'date_source_ref':str(D/'batch27_department_primary.html')}
 y.update(changes);semantic.append(y)
 for field,value in changes.items():
  if x[field]!=value:semantic_overlay.append({'input_csv_line_1based':x['input_csv_line_1based'],'model_key':x['model_key'],'source_sha256':SHA,'field':field,'old_value':x[field],'new_value':value,'evidence_file':str(D/'batch27_department_primary.html')})
full=[{'source_sha256':SHA,'sequence':c[0],'firm_raw':c[1],'model_raw':c[2],'model_key':norm(c[2]),'product_name_raw':c[3],'original_listing_batch':c[4],'remark_raw':c[5],'cohort_member':str(int(norm(c[2]) in cohort_keys)),'source_public_date_observed':DATE,'source_announcement_batch':'27'} for c in versions[0]]
write('batch27_original_full_enumeration_424.csv',full);write('batch27_event_correction_overlay_47.csv',overlays);write('batch27_corrected_events_47.csv',corrected_events,list(events[0]));write('batch27_corrected_source_links_47.csv',corrected_links,list(links[0]));write('batch27_corrected_semantic_records_424.csv',semantic,list(history[0]));write('batch27_semantic_correction_fields_424_rows.csv',semantic_overlay)
result={'conclusion':'旧撤销来源误挂第32批及2020-06-02；正确为第27批较早主管部门公开观察2019-10-25','earlier_source_sha256':SHA,'earlier_public_date':DATE,'earlier_signed_date':DATE,'later_source_sha256':LATE,'later_public_date':'2019-10-30','same_424_rows_firm_model_product_prior_batch':True,'remark_differences':remark_diffs,'target_source_rows':424,'cohort_intersection':47,'old_opaque_event_ids_preserved':True,'old_source_record_ids_preserved':True,'batch32_current_page_annex_count':2,'batch32_annex1':{'source_sha256':p32['source_sha256'],'content':'第三十二批免征目录','withdrawal_word_count':t32.count('撤销')},'batch32_annex2':{'source_sha256':renameproof['source_sha256'],'content':'仅2条企业名称变更','withdrawal_word_count':trename.count('撤销')},'legacy_tax_reference_title':'第27批/2019年第45号；旧3007自身引用此页，与32日期字段矛盾','legacy_tax_reference_receipt':str(R/'raw/batch32_legacy_tax_reference.json'),'scope_limit':'核查当前第32原页及全部两个附件；没有将其扩大为全互联网永不存在第三十二批相关撤销','source_reader_proofs':proofs}
(R/'batch27_32_source_date_conclusion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='source_reader_proofs'},ensure_ascii=False))
