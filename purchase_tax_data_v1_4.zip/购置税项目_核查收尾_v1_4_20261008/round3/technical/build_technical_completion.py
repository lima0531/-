import csv,json,pathlib,hashlib,re,collections,unicodedata
OUT=pathlib.Path(__file__).parent
INPUT=pathlib.Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
ROOT=pathlib.Path('/workspace/purchase_tax_audit/round3')
def rows(rel):return list(csv.DictReader((INPUT/rel).open(encoding='utf-8-sig')))
def writecsv(name,r,fields=None):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(r[0]));w.writeheader();w.writerows(r)
def norm(s):return ''.join(unicodedata.normalize('NFKC',s).split())
rec=rows('推荐参数/推荐参数_配置版本长表.csv')
manufacture=rows('参数版本边界/再申报92型号_制造日期待核口径.csv')
cat6path=ROOT/'archive/recovered/减免目录/cat_batch6.doc';cat6sha=hashlib.sha256(cat6path.read_bytes()).hexdigest()
assert cat6sha=='8017fdbcfa01dc3f5d2bd65fe4a06f5212edd78d39fee33fd47f6a2823eedcf7'
cat6text=(OUT/'converted/cat_batch6.txt').read_text(encoding='utf-8-sig')
start=cat6text.index('注：重新申报后符合新技术要求的车型');end=cat6text.index('序号\t企业名称\t车辆型号',start)
quote=cat6text[start:end].strip();(OUT/'第6批_整改制造日期与撤销生效原文.txt').write_text(quote+'\n')
oldjson=json.loads((INPUT/'参数版本边界/再申报制造日期条件_原件证据.json').read_text());originalquote=oldjson['evidence'][0]['raw_text']
assert norm(quote) in norm(originalquote)
cat6receipt={'source_file':str(cat6path.relative_to(ROOT)),'source_url':'https://www.miit.gov.cn/cms_files/filemanager/1226211233/attach/20244/4aabd4e028a74981be7faf6d7200bae5.doc','source_sha256':cat6sha,'source_sha256_matches_compact_evidence':True,'converted_text_sha256':hashlib.sha256((OUT/'converted/cat_batch6.txt').read_bytes()).hexdigest(),'quotation_matches_retained_evidence_after_whitespace_normalization':True,'note_start_character_0based':start,'withdrawal_effective_date':'2024-06-01','manufacture_threshold':'the actual re-listing date, inclusive','previous_batches_also_covered':True,'vehicle_manufacture_dates_obtained':False,'quote':quote}
(OUT/'cat6_manufacture_and_withdrawal_evidence.json').write_text(json.dumps(cat6receipt,ensure_ascii=False,indent=2)+'\n')
policy10text=(OUT/'policy10_primary_text.txt').read_text();policy10receipt=json.loads((OUT/'policy10_primary_request.json').read_text())
p10quotes={
 'purchase_date_evidence':'购置日期按照机动车销售统一发票或海关关税专用缴款书等有效凭证的开具日期确定。',
 'vehicle_class_definition':'新能源乘用车，是指在设计、制造和技术特性上主要用于载运乘客及其随身行李和（或）临时物品，包括驾驶员座位在内最多不超过9个座位的新能源汽车。',
 'vehicle_electronic_verification':'税务机关依据工业和信息化部校验后的减免税标识、换电模式标识和机动车销售统一发票（或有效凭证），办理车辆购置税减免税手续。'
}
for s in p10quotes.values():assert norm(s) in norm(policy10text)
p10={'policy_number':'2023年第10号','signed_date':'2023-06-19','page_registered_public_date':'2023-06-21','global_first_online_certified':False,'source_url':policy10receipt['url'],'source_sha256':policy10receipt['sha256'],'verified_quotes':p10quotes}
(OUT/'policy10_verified_conditions.json').write_text(json.dumps(p10,ensure_ascii=False,indent=2)+'\n')
# Configuration-level queues are requests for evidence, not new test or vehicle observations.
queues=[];priority=[]
for row in rec:
 names=['range_km_single','density_whkg_single','max_speed_30min_kmh_single','consumption_kwh100km_single','ordinary_consumption_target_from_mass']
 try:
  R,D,S,Y,T=map(float,(row[k] for k in names));conditional=R>=120 and D>=95 and S>=100 and Y<=T and (R<200 or D<125)
 except ValueError:conditional=False
 r={'observation_version_key':row['observation_version_key'],'source_id':row['source_id'],'source_public_date':row['source_public_date'],'source_sha256':row['source_sha256'],'firm_raw':row['firm_raw'],'model_key':row['model_key'],'recommendation_config_id':row['config_id'],'four_requirement_numeric_screen':row['four_requirement_numeric_screen'],'conditional_low_temperature_threshold_numeric_fit':int(conditional),'low_temperature_report_id':'','low_temperature_test_institution':'','test_standard_and_revision':'','annex_A_report_available':'','test_date':'','tested_configuration_identity_key':'','normal_temperature_test_range_km':'','low_temperature_test_range_km':'','range_degradation_percent_from_report':'','test_report_source_sha256':'','tax_catalogue_same_configuration_certificate':'','battery_manufacturer_model_and_variant':'','motor_manufacturer_model_and_variant':'','configuration_bridge_evidence_url_or_file':'','configuration_bridge_evidence_sha256':'','full_configuration_match_verified':0,'low_temperature_evidence_obtained':0,'collection_grain':'configuration-version evidence request; no test observation added','priority':'优先核低温例外所需检测证据' if conditional else '同配置身份及试验口径待核'}
 queues.append(r)
 if conditional:priority.append(r)
writecsv('推荐285配置_身份与低温报告待补清单.csv',queues)
writecsv('低温报告优先核查_19配置版本.csv',priority)
vehicle=[]
for r in manufacture:
 vehicle.append({'model_key':r['model_key'],'observed_reapplication_events':r['observed_reapplication_events'],'reapplication_event_ids':r['reapplication_event_ids'],'first_reapplication_observed_date_lower':r['first_reapplication_observed_date_lower'],'first_reapplication_observed_date_upper':r['first_reapplication_observed_date_upper'],'manufacture_condition_verified_source_sha256':cat6sha,'individual_vehicle_manufacture_dates_available':0,'individual_vehicle_eligibility_certified':0,'needed_vehicle_identifier':'VIN或项目内稳定车辆匿名键','needed_manufacture_date':'整车出厂合格证/进口车辆电子信息单的制造日期','needed_relisted_configuration_evidence':'实际重新列入日期及整改配置对应原件','needed_purchase_date':'销售统一发票/有效凭证开具日期','needed_checked_tax_relief_flag':'工业和信息化部校验后的减免税标识','needed_vehicle_to_configuration_link':'车辆电子信息与整改配置的可核查对应关系','collection_grain':'model-level collection checklist; no VIN/date/vehicle eligibility invented'})
writecsv('再申报92型号_逐车材料字段待补清单.csv',vehicle)
missing=[
 {'evidence_item':'同型号跨推荐目录与减免目录的同配置身份桥','grain':'配置版本/申报版本','required_fields':'申报配置ID，整车型号，企业，申报有效时间，电池生产企业及型号/版本，电机企业及型号，整备质量/尺寸，推荐配置ID和减免申报配置对应依据，来源及SHA','public_data_collected':'285配置版本的推荐官方原件与参数已取得；目录普通型号身份已保留','remaining_status':'not_available_in_current_input_or_public_downloads','cannot_substitute':'同型号、相同单个参数或近似字符串不能替代配置对应依据'},
 {'evidence_item':'附录A低温检测报告','grain':'配置及试验报告','required_fields':'报告编号/检测机构，报告日期，标准版本及附录A，试验配置识别，常温和低温里程，低温里程衰减率/计算口径，报告对应申报配置，原件及SHA','public_data_collected':'正式公告低温例外条件已核实；19配置版本列入条件性优先核查','remaining_status':'no_configuration_matched_report_obtained','cannot_substitute':'35%、95Wh/kg、120km是门槛而非实测值；标准元数据不能代替检测报告'},
 {'evidence_item':'逐车制造日期和购置凭证','grain':'单车VIN/稳定匿名车辆键','required_fields':'车型及整改配置，制造日期及合格证/电子信息单来源，购置凭证开具日期，重新列入日期，校验后减免税标识，必要时换电模式标识，原件及SHA','public_data_collected':'第6批正文明确制造日期条件；政策10正文明确购置日期及电子信息校验依据；92型号待补清单已生成','remaining_status':'no_vehicle_level_source_obtained','cannot_substitute':'月末目录在册和同型号重申报日期不能替代单车制造日期或税务校验'},
 {'evidence_item':'GB/T18386.1-2021标准登记元数据','grain':'标准版本','required_fields':'标准发布日期、实施日期、现行状态、代替标准、标准登记页原件及SHA','public_data_collected':'标准编号、名称、附录A引用已由政策附件确认','remaining_status':'official_registry_blocked_by_current_egress_proxy_403','cannot_substitute':'不能用政策发布日期或记忆代填标准登记字段'},
 {'evidence_item':'公告前无单值389风险集型号的参数/配置版本','grain':'税目录配置版本且公布不晚于2023-12-10','required_fields':'确定的配置身份，配对的续驶里程及明确试验工况，电池系统质量能量密度或可核算参数，公布日期与版本有效期，原件位置及SHA','public_data_collected':'原件目录补采另见archive目录；既有区间参数和复合原值保留','remaining_status':'ambiguous_or_missing_point_estimate_not_resolved_by_recommendation_model_match','cannot_substitute':'多值参数、上下界或政策后版本不能填成公告前单值；缺值不填0'}
]
writecsv('剩余所需数据_字段级材料规范.csv',missing)
# Portable source manifest: archival paths are relative to round3 and can be resolved after packaging.
manifest=[]
for sid in sorted({r['source_id'] for r in rec}):
 req=json.loads((OUT/(sid+'_original_request.json')).read_text());rr=[x for x in rec if x['source_id']==sid];f=OUT/(sid+'_original.pdf')
 manifest.append({'source_id':sid,'source_kind':'recommendation_parameter_pdf','relative_file':str(f.relative_to(ROOT)),'url':req['url'],'bytes':len(f.read_bytes()),'sha256':req['sha256'],'expected_input_sha256':rr[0]['source_sha256'],'sha256_matches_input':int(req['sha256']==rr[0]['source_sha256']),'config_version_rows':len(rr),'model_count':len({x['model_key'] for x in rr})})
writecsv('技术补采_推荐原件来源清单.csv',manifest)
summary={'recommendation_pdfs_recovered':3,'recommendation_config_versions':len(rec),'recommendation_distinct_configs':len({r['config_id'] for r in rec}),'recommendation_distinct_models':len({r['model_key'] for r in rec}),'ordinary_numeric_screen_counts':dict(collections.Counter(r['four_requirement_numeric_screen'] for r in rec)),'conditional_lowtemp_priority_config_versions':len(priority),'conditional_lowtemp_priority_distinct_models':len({r['model_key'] for r in priority}),'conditional_lowtemp_priority_is_compliance_certification':False,'reapplication_model_collection_checklist_rows':len(vehicle),'policy32_primary_and_exact_attachment_obtained':True,'policy10_primary_obtained':True,'cat6_manufacture_condition_exact_source_obtained':True,'new_vehicle_level_records':0,'new_configuration_matched_lowtemp_reports':0,'new_full_configuration_match_certifications':0,'original_input_modified':False}
verification=json.loads((OUT/'recommendation_original_verification.json').read_text())
assert verification['discrepancy_count']==0
summary.update(recommendation_raw_fields_checked=verification['fields_verified'],recommendation_raw_fields_mismatch_count=verification['discrepancy_count'],recommendation_header_page_boundary_cases=2,recommendation_neighbor_glyph_boundary_cases=4)
sourcepage=[]
for sid,expected in [('rec2020_04','2020-04-01'),('rec2022_04','2022-05-12'),('rec2022_12','2022-12-30')]:
 f=OUT/(sid+'_announcement.html');t=f.read_text();req=json.loads((OUT/(sid+'_announcement_request.json')).read_text())
 pub=re.search(r'<span class="xxgk-span1">发布日期：</span><span class="xxgk-span4">([^<]+)',t).group(1)
 signed=re.search(r'<span class="xxgk-span1">成文日期：</span><span class="xxgk-span2">([^<]+)',t).group(1)
 meta=re.search(r'<meta name="PubDate" content="([^"]+)"',t).group(1)
 assert pub==expected and hashlib.sha256(f.read_bytes()).hexdigest()==req['sha256']
 if sid=='rec2020_04':assert '2020年3月31日' in norm(re.sub('<[^>]*>','',t))
 sourcepage.append({'source_id':sid,'page_url':req['url'],'page_sha256':req['sha256'],'registered_public_date':pub,'structured_signed_date':signed,'body_signed_date':'2020-03-31' if sid=='rec2020_04' else signed,'body_vs_structured_signed_date_conflict':sid=='rec2020_04','meta_PubDate':meta,'meta_vs_visible_publication_date_conflict':meta[:10]!=pub,'global_first_online_certified':False,'retained_source_public_date_matches_primary_registered_date':True})
(OUT/'recommendation_primary_date_evidence.json').write_text(json.dumps(sourcepage,ensure_ascii=False,indent=2)+'\n')
summary['recommendation_primary_registered_date_match_count']=len(sourcepage)
(OUT/'technical_completion_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
