import pathlib,urllib.request,concurrent.futures,re,json,hashlib,datetime,html
OUT=pathlib.Path(__file__).parent
PAGES={8:'/zwgk/zcwj/wjfb/gg/art/2020/art_4894ed6fe7344ea089f37975b8cc6372.html',9:'/zwgk/zcwj/wjfb/gg/art/2020/art_0d2491acc4a149c39d94f0995e065ce5.html',12:'/zwgk/zcwj/wjfb/gg/art/2020/art_e06ed449b13b49be97209da2d73ba858.html',13:'/zwgk/zcwj/wjfb/gg/art/2020/art_7f81081be82f45628fb8e48e5eda2c6c.html'}
def get(item):
 batch,path=item;url='https://www.miit.gov.cn'+path
 try:
  resp=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.miit.gov.cn/search/'}),timeout=35);b=resp.read();fn=f'batch_{batch}_miit_gg.html';(OUT/fn).write_bytes(b);s=b.decode('utf8','replace');txt=html.unescape(re.sub('<[^>]+>',' ',s));txt=re.sub(r'\s+',' ',txt)
  evidence=[{'line':i,'raw':l.strip()} for i,l in enumerate(s.splitlines(),1) if re.search(r'PubDate|MakeTime|发布日期|发布时间|来源：|201[467](年|-)|attach/',l)]
  row=dict(batch=batch,url=url,final_url=resp.url,http_status=resp.status,sha256=hashlib.sha256(b).hexdigest(),raw_file=str(OUT/fn),retrieved_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence=evidence,plain_text=txt)
  (OUT/f'batch_{batch}_miit_gg_evidence.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf8');print(batch,json.dumps(evidence,ensure_ascii=False),flush=True)
 except Exception as e:print(batch,type(e).__name__,str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(get,PAGES.items()))
