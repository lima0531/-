# 购置税项目补采与修订 v1.3

本轮最终分析数据在 `reconstruction/data_v1_3/`；先读 `补采与数据修订报告_v1_3_20261008.md`。最终风险集2805、输入准备2424、风险内2024撤销496、风险外7，总撤销503。中间2804/2423仅表示新增73条撤销后的单步结果，未包含47条第27批错日期修复，不能与最终表混用。

数据保留3328成员、原冻结1991及参数值；补入73条遗漏撤销并修正47条公告批次/日期。核心包保留原上传精简ZIP、更新CSV、两份新增撤销原件、网页证据、逐行来源、修订记录、脚本及最终验证。公开原件包另含102份历史同字节原件、3份推荐PDF与第26批两份内容核对后的官方替代版本，107文件约16.1MiB；两包可独立解压，将原件包的目录合并到核心包的 `round3/`。

最终检查在 `validation/v1_3_panel/`（23 PASS）、`validation/final_delta_validation.json`（16 PASS）及 `validation/v1_3_joins/`（0差异）。旧脚本中2877/451等假设已由来源证明失效；本版连接检验使用对应最终2805/523，并保留其余同源计算核对。原指纹63项仍通过。各核查范围不相加。

`公开原件_分包索引.csv`给出原件路径、SHA和所属ZIP；核心ZIP内的指纹清单校验实际交付文件。日期、类别、技术证据的未闭合事项见最终报告和各子目录README。早期失败网页、传输异常及中间审计结果是过程留痕，来源可信结论以最终清单和实际指纹为准。

## 当前云环境复跑

Python3.12.14及所需PyMuPDF、pypdf、xlrd、pdfplumber、pandas、openpyxl已实测；LibreOffice和有界CFB读取器用于原件回读。实际版本保存在 `environment/runtime_versions.json`。源码库为空，本轮未改仓库、依赖声明或锁文件。

以下是当前云环境的已执行目录和脚本接口；下载到其他机器时需要恢复原输入路径或调整脚本的输入根。核心包将原上传ZIP保存在 `input/`，原数据始终单独保留。

```bash
python /workspace/purchase_tax_audit/round3/versioning/build_date_version.py '/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008' /workspace/purchase_tax_audit/round3/dates/accepted_registered_dates.csv /workspace/purchase_tax_audit/round3/versioning
python /workspace/purchase_tax_audit/round3/reconstruction/apply_batch27_source_correction.py
python /workspace/purchase_tax_audit/round3/reconstruction/rebuild_with_new_withdrawals.py --base /workspace/purchase_tax_audit/round3/reconstruction/corrected_source_base --coverage /workspace/purchase_tax_audit/round3/coverage --output /workspace/purchase_tax_audit/round3/reconstruction
python /workspace/purchase_tax_audit/round3/validation/validate_reconstructed_data.py /workspace/purchase_tax_audit/round3/reconstruction/data_v1_3 /workspace/purchase_tax_audit/round3/validation/v1_3_panel
python /workspace/purchase_tax_audit/round3/validation/validate_joins_v1_3.py /workspace/purchase_tax_audit/round3/reconstruction/data_v1_3 --output /workspace/purchase_tax_audit/round3/validation/v1_3_joins
python /workspace/purchase_tax_audit/round3/validation/validate_final_delta.py
```

日期版本和来源修订基底是可重建中间表，核心包不重复交付其全量CSV；推荐数据只交付最终v1.3。原文文本102份均可检索，但不代表97目录全表独立重抽。106历史原件仍有4个同字节目标未恢复；附录A报告、跨目录同配置、逐车制造等材料没有编造。

国家标准平台相关网络域名草稿已保存。草稿审阅、保存和发布在环境设置完成，保存工具本身不证明运行时生效；当前阻断和后续具体URL实测按报告逐项区分。
