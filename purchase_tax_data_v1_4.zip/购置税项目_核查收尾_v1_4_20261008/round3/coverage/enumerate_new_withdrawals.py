"""Enumerate every numbered row in two previously absent formal tax-withdrawal sources.
Input original files and cohort data are read-only; LibreOffice exported text is a derivative.
Sequences and column schema are checked before model keys are consulted.
"""
import csv,hashlib,json,re,unicodedata
from pathlib import Path
from collections import Counter,defaultdict
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows,fields=None):
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s)).upper()
cohort={x['model_key']:x for x in read(BASE/'研究数据/样本成员重建.csv')}
old_events=read(BASE/'研究数据/资格事件_重建去重表.csv');old_links=read(BASE/'研究数据/资格事件_逐原件连接.csv')
historic=read(BASE/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv')
old_source_hashes={x['source_sha256'] for x in read(BASE/'原件索引/完整归档_106份原件嵌套索引_历史记录.csv')}
old_by_model=defaultdict(list)
for e in old_events:old_by_model[e['model_key']].append(e)
sources=[{'tag':'withdrawal_20180522','event_batch':'2018-05-22独立撤销公告','signed_date':'2018-05-21','published_date':'2018-05-22','record_prefix':'new-wd20180522','expected_rows':1882},
 {'tag':'withdrawal_batch28','event_batch':'28','signed_date':'2019-12-06','published_date':'2019-12-10','record_prefix':'new-wd28','expected_rows':138}]
all_rows=[]; events=[];links=[];metadata=[]
for source in sources:
 tag=source['tag'];raw=ROOT/'raw'/(tag+'.doc');txt=ROOT/'text'/(tag+'.txt');b=raw.read_bytes();sha=hashlib.sha256(b).hexdigest()
 assert b[:8]==bytes.fromhex('d0cf11e0a1b11ae1'),tag
 receipt=json.loads((ROOT/'raw'/(tag+'.json')).read_text());page_receipt=json.loads((ROOT/'raw'/(tag+'_page.json')).read_text());page=(ROOT/'raw'/(tag+'_page.html')).read_text()
 assert receipt['status']==200 and receipt['sha256']==sha
 # Page-to-attachment identity is verified separately from website search snippets.
 assert receipt['requested_url'].split('www.miit.gov.cn',1)[-1] in page
 lines=txt.read_text(encoding='utf-8-sig').splitlines();numbered=[];firm_context=''
 for line_no,line in enumerate(lines,1):
  cells=line.split('\t')
  if len(cells)==5 and cells[0].isdigit():numbered.append((line_no,cells))
  elif '\t' in line:assert cells==['序号','企业名称','车辆型号','产品名称','批次' if tag.endswith('20180522') else '备注'],(tag,line_no,cells)
 assert [int(c[0]) for _,c in numbered]==list(range(1,source['expected_rows']+1))
 assert len(numbered)==source['expected_rows']
 models=[norm(c[2]) for _,c in numbered];assert len(set(models))==len(models)
 local_rows=[]
 for line_no,cells in numbered:
  seq,firm,model,product,remark=cells
  if firm:firm_context=firm
  key=norm(model);record=f"{source['record_prefix']}-row-{seq}";location=json.dumps({'text_line_1based':line_no,'row_sequence':int(seq),'model_column_1based':3,'engine':'LibreOffice Word97-to-text; 5-column full sequence enumeration'},ensure_ascii=False)
  row={'source_tag':tag,'source_file':str(raw),'source_sha256':sha,'source_url':receipt['requested_url'],'announcement_url':page_receipt['requested_url'],'announcement_page_sha256':page_receipt['sha256'],'signed_date_registered':source['signed_date'],'official_page_registered_public_date':source['published_date'],'full_historical_first_online_time_verified':'0','legal_effective_date':'','legal_effective_date_verified':'0','event_batch':source['event_batch'],'sequence':seq,'firm_raw':firm,'firm_context_candidate':firm_context,'firm_from_this_row':str(int(bool(firm))),'model_raw':model,'model_key':key,'product_name_raw':product,'original_batch_or_remark_raw':remark,'source_record_id':record,'source_location':location,'in_cohort_3328':str(int(key in cohort)),'in_existing_3007_historic_models':str(int(any(x['model_key']==key for x in historic))),'sha256_in_existing_106_source_index':str(int(sha in old_source_hashes))}
  all_rows.append(row);local_rows.append(row)
  if key not in cohort:continue
  date=source['published_date'];event_id='evt-'+hashlib.sha256('|'.join([key,'撤销','免征目录',source['event_batch'],date,sha]).encode()).hexdigest()[:16]
  event={'model_key':key,'action':'撤销','system':'免征目录','event_batch':source['event_batch'],'publish_date_exact':date,'public_date_lower_bound':date,'public_date_upper_bound':date,'event_date_basis':'主管部门原页明示登记发布日期；正式撤销名单公开观察，不认证法定生效日或历史首次上线','event_id':event_id,'source_record_count':'1','source_record_ids':record,'source_batches':source['event_batch'],'reapplication_signal':'0','effective_date_exception':'0'}
  link={'event_id':event_id,'model_key':key,'action':'撤销','system':'免征目录','event_batch':source['event_batch'],'source_batch':source['event_batch'],'source_record_id':record,'observation_kind':'撤销名单','source_owner':'round3_public_supplement','source_file':str(raw),'source_sha256':sha,'source_location':location,'publish_date_exact':date,'public_date_lower_bound':date,'public_date_upper_bound':date,'event_date_basis':event['event_date_basis'],'source_parameter_observation_lower':'','source_parameter_observation_upper':'','reapplication_signal':'0','effective_date_exception':'0'}
  events.append(event);links.append(link)
 metadata.append(dict(source,source_file=str(raw),source_sha256=sha,source_bytes=len(b),source_url=receipt['requested_url'],announcement_url=page_receipt['requested_url'],announcement_page_sha256=page_receipt['sha256'],full_table_rows=len(numbered),unique_models=len(set(models)),cohort_models=sum(x['in_cohort_3328']=='1' for x in local_rows),source_missing_from_106_index=sha not in old_source_hashes,legal_effective_date_verified=False))
assert len(events)==73 and len(set(e['model_key'] for e in events))==73
assert all(len(old_by_model[e['model_key']])==1 and old_by_model[e['model_key']][0]['action']=='列入' and old_by_model[e['model_key']][0]['public_date_upper_bound']<e['public_date_lower_bound'] for e in events)
assert not set(e['event_id'] for e in events)&set(e['event_id'] for e in old_events)
write('new_withdrawal_full_enumeration_2020_rows.csv',all_rows)
write('new_withdrawal_cohort_intersection_73.csv',[x for x in all_rows if x['in_cohort_3328']=='1'])
write('new_withdrawal_events.csv',events,list(old_events[0]))
write('new_withdrawal_source_links.csv',links,list(old_links[0]))
(ROOT/'new_withdrawal_sources.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_count':len(sources),'full_table_rows':len(all_rows),'unique_cohort_models':len(set(e['model_key'] for e in events)),'new_cohort_events':len(events),'all_73_existing_events_only_prior_listing':True,'event_count_after_addition':len(old_events)+len(events),'source_link_count_after_addition':len(old_links)+len(links)},ensure_ascii=False))
