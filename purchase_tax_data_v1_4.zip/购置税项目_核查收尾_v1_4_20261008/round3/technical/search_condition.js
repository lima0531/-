// JavaScript Document
$(function(){
	bindCondition();
	advSearch();
	calendarWidget();
	dateBox();
	posBox();
	odBox();
	doctypeBox();
	getvalueof();
});
// 搜索工具
var bindCondition = function(){
	$('.ui-body-inner').on('mouseover', '.jsearch-condition-box .jsearch-condition-box-item',function(){
		$(this).addClass('hover');
	}).on('mouseout', '.jsearch-condition-box .jsearch-condition-box-item',function(){
		$(this).removeClass('hover');
	});
	initJsearchConditionBox();
}

function initJsearchConditionBox(){
	var hideCondition = function(){
		$('.jsearch-condition-box-items').hide();
		$('.jsearch-condition-box-items').parent().find('.jsearch-criteria-btn').hide();
	}
	var height = $('#jsearch-condition-box-content').height();
	var boxes = $('.jsearch-condition-box');
	$('#jsearch-condition-box-content>.jsearch-condition-box>.jsearch-condition-box-items').on('click', function(event){
		event.stopPropagation();
	});
	$('#jsearch-condition-box-content>.jsearch-condition-box>.jsearch-condition-box-items>.jsearch-condition-box-item').on('hover', function(){
		$(this).toggleClass('selected');
	}).on('click', function(){
		hideCondition();
		//$(this).parents('.jsearch-condition-box').find('.jsearch-condition-box-title>span').text($(this).text());
	});
	boxes.hover(function(event){
		hideCondition();
		$('.jsearch-criteria-btn', this).show();
		var left = $(this).offset().left;
		var top = $(this).offset().top;
		var width = $(this).outerWidth();
		var itemsBox = $('.jsearch-condition-box-items',this);
		var paddingLeft = itemsBox.css('padding-left').replace('px','');
		//itemsBox.appendTo($('body'));
		itemsBox.css({
			'top':"38px",
			//'left':left,
			'width':width+1
		});
		boxes.removeClass('selected');
		//$(this).addClass('selected');
		itemsBox.toggle();
	},function(){
		hideCondition();
	}).on('blur', function(){
		
	}).on('click', function(event){
		event.stopPropagation();
	});
	$('body').on('click scroll', function(){
		hideCondition();
	});
}
// 高级检索
var advSearch = function(){
	/*$('body').click(function(){
		$('.jsearch-adv-btn').removeClass('hover');
		$('#jsearch-adv-box').fadeOut(200);
	});*/
	var $advSearchBox = $('#jsearch-adv-box');
	$('.ui-search-btn-adv').click(function(event){
		event.stopPropagation();
		var $hotwordrank = $('#jcse-hotwordrank').toggleClass('hotrank');
		//fixSearchBox();
		var $btn = $('.ui-search-btn-adv').toggleClass('hover');
		//var $advSearchBox = $('#jsearch-adv-box');
		if($btn.hasClass('hover')){
			$('input,select,textarea', $advSearchBox).removeAttr('disabled');
		}else{
			$('input,select,textarea', $advSearchBox).attr('disabled','disabled');
		}
		
		if($hotwordrank.hasClass("hotrank")){
			$('#jcse-hotwordrank').css({'position':'relative','top':'23px'});
		}else{
			$('#jcse-hotwordrank').css({'position':'relative','top':'0px'});
		}
		//$advSearchBox.toggle();
	});
	
	var pq = $.trim($('#pq').val());
	var oq = $.trim($('#oq').val());
	var eq = $.trim($('#eq').val());
	var doctype = $.trim($('#doctype').data('value'));
	
}
// 日历控件绑定
var calendarWidget = function(){
	$('.jsearch-widget-calendar').on('click', function(){
		var $this = $(this);
		var id = $this.attr('id');
		var minId = $this.data('date-start');
		var maxId = $this.data('date-end');
		var format = $this.data('date-format');
		var minFnc = '';
		var maxFnc = '';
		if(minId){
			minFnc = '#F{$dp.$D(\'' + minId + '\')}';
		}
		if(maxId){
			maxFnc = '#F{$dp.$D(\'' + maxId + '\')}';
		}
		var prop = {
			skin:'twoer',
			dateFmt:format,
			minDate:minFnc,
			maxDate:maxFnc,
			onpicked:function(){
				if(minId && $('#'+minId).val() ==''){
					$('#'+minId)[0].click();
				}
				if(maxId && $('#'+maxId).val() ==''){
					$('#'+maxId)[0].click();
				}
			}
		};
		WdatePicker(prop);
	});
}
// 日期条件
var dateBox = function(){
	var $date = $('#date-box');
	$('.jsearch-criteria-btn.ok', $date).click(function(){
		cate_init();
		relateImages();
		
	});
	$('.jsearch-criteria-btn.cancel', $date).click(function(){
		$('input', $date).val('');
	});
	var date = $('#date').val();
	if(!date){
		date = 0;
	}
	var getDateStr = function(nowDate){
		var month = (nowDate.getMonth() + 1) + '';
		if(month.length == 1){
			month = '0' + month;
		}
		var day = nowDate.getDate() + '';
		if(day.length == 1){
			day = '0' + day;
		}
		return nowDate.getFullYear()+ "-" + month+ "-" + day;
	};
	$('.jsearch-condition-box-item', $date).click(function(){
		var data_value = $(this).data('value');
		var nowDate = new Date();
		var dateStr = getDateStr(nowDate);
		var start = '';
		var end = dateStr;
		switch(data_value){
			case 0:
				start = '';
				end = '';
				break;
			case 1:
				start = dateStr;
				break;
			case 2:
				nowDate.setDate(nowDate.getDate()-7);
				start = getDateStr(nowDate);
				break;
			case 3:
				nowDate.setMonth(nowDate.getMonth()-1);
				start = getDateStr(nowDate);
				break;
			case 4:
				nowDate.setFullYear(nowDate.getFullYear()-1);
				start = getDateStr(nowDate);
				break;
		}
		$('#date_start', $date).val(start);
		$('#date_end', $date).val(end);

		cate_init();
		relateImages();
		


	}).removeClass('selected').show();
	$date.show();
};
// 搜索位置条件
var posBox = function(){
	var $pos = $('#pos-box');
	var pos = $('#pos').val();
	if(!pos){
		pos = '_default_search';
	}
	$('.jsearch-condition-box-item', $pos).click(function(){
		var data_value = $(this).data('value');
		$('#pos').val(data_value);
		cate_init();
		relateImages();

		var text = $(this).text();
	if(text){
		$('.jsearch-condition-box-title>span', $pos).text(text);
	}
	}).removeClass('selected').show();
	var text = $('.jsearch-condition-box-item[data-value="' + pos + '"]', $pos).text();
	if(text){
		$('.jsearch-condition-box-title>span', $pos).text(text);
	}
	$pos.show();
};

// 排序方式条件
var odBox = function(){
	var $od = $('#od-box');
	var od = $('#od').val();
	if(!od){
		od = '';
	}
	$('.jsearch-condition-box-item', $od).click(function(){
		var data_value = $(this).attr("data-value");
		//var data_value = $(this).data('value');
		//var value= "["+JSON.stringify(data_value[0])+"]";
		$('#od').val(data_value);
		$('.jsearch-condition-box-title span', $od).text($(this).text());
		cate_init();
		relateImages();
		

	}).removeClass('selected');
	var text = $('.jsearch-condition-box-item[data-value="' + od + '"]', $od).text();
	if(text){
		$('.jsearch-condition-box-title>span', $od).text(text);
	}
	$od.show();
};
// 搜索文档类型条件
var doctypeBox = function(){
	var doctype = $('#doctype').data('value');
	$('#doctype option[value="' + doctype + '"]').attr('selected',true);
};
var getvalueof = function(){
	var q = $('#q').val();
	$('#none_q').text(q);
}


/*
 function setTab(name, cursel, n) {
	for (var i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("con_" + name + "_" + i);
		var more = document.getElementById("more_" + name + "_" + i);
		menu.className = i == cursel ? "hover" : "";
		con.style.display = i == cursel ? "block" : "none";
		more.style.display = i == cursel ? "block" : "none";
	}
}

function setTab2(name, cursel, n) {
	for (i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("con_" + name + "_" + i);
		menu.className = i == cursel ? "hover" : "";
		con.style.display = i == cursel ? "block" : "none";
	}
}

function setTab3(name, cursel) {
	if ($('#' + name + cursel).hasClass("hover")) {
		return;
	} else {
		$('.search-manage').removeClass("hover");
		$('#' + name + cursel).addClass("hover");
	}
}
*/

$(function(){
	/*效果*/
	$(".jsearch-condition-box-title").mousemove(function(){
		$(this).siblings(".jsearch-condition-box-items").show();
	});

	$(".ui-search-btn-adv").click(function(){
		event.stopPropagation();
		$("#jsearch-adv-box").hasClass("openSl")
		if($("#jsearch-adv-box").hasClass("openSl")){
			$("#jsearch-adv-box").removeClass("openSl")
			$("#jsearch-adv-box").hide();
		}else{
			$("#jsearch-adv-box").addClass("openSl");
			$("#jsearch-adv-box").show();
		}
		
	});
});