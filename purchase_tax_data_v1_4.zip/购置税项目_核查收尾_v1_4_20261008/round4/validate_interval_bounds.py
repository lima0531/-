#!/usr/bin/env python3
"""Independent rational endpoint check of the interval audit (no builder imports)."""
import csv,json,itertools
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
params={r['record_id']:r for r in read(ROOT/'data_v1_4/研究数据/参数版本_原值与计算代理.csv')}
audit=read(ROOT/'parameters/381单值不足_原因与保守区间核查.csv')
diff=[];checked_density=0;checked_range=0
epsilon=F(1,10**22)
for row in audit:
    p=params[row['record_id']]
    if row['model_key']=='YGM7002BEVB4':ml=mu=F(138)
    elif p['battery_mass_lower'] and p['battery_mass_upper']:ml,mu=F(p['battery_mass_lower']),F(p['battery_mass_upper'])
    else:ml=mu=None
    if ml is not None and p['battery_energy_lower'] and p['battery_energy_upper']:
        el,eu=F(p['battery_energy_lower']),F(p['battery_energy_upper'])
        assert 0<ml<=mu and 0<el<=eu
        lower,upper=1000*el/mu,1000*eu/ml
        actual_lo,actual_hi=F(row['density_proxy_lower']),F(row['density_proxy_upper'])
        if abs(lower-actual_lo)>epsilon or abs(upper-actual_hi)>epsilon:diff.append((p['record_id'],'density endpoints'))
        # Each corner combination is enclosed, regardless of unknown option pairing.
        corners=[1000*e/m for e in (el,eu) for m in (ml,mu)]
        if any(v<lower or v>upper for v in corners):diff.append((p['record_id'],'corner enclosure'))
        checked_density+=1
    elif row['density_proxy_lower'] or row['density_proxy_upper']:diff.append((p['record_id'],'fabricated density'))
    if row['model_key']=='MR7001BEV18':lo,hi=F(616),F(650)
    elif p['range_lower'] and p['range_upper']:lo,hi=F(p['range_lower']),F(p['range_upper'])
    else:lo=hi=None
    if lo is not None:
        if F(row['range_lower'])!=lo or F(row['range_upper'])!=hi:diff.append((p['record_id'],'range bounds'))
        checked_range+=1
    if row['frozen_point_updated']!='0' or row['full_technical_conformity_certified']!='0' or row['configuration_identity_certified']!='0':diff.append((p['record_id'],'unwarranted certification'))
result=dict(audited_rows=len(audit),density_endpoints_independently_checked=checked_density,
    range_endpoints_independently_checked=checked_range,arithmetic='exact rational energy/mass corners, comparison tolerance 1e-22 Wh/kg for stored decimal rounding',
    unpaired_option_enclosure_verified=True,frozen_points_and_legal_certification_unchanged=True,differences=diff)
assert len(audit)==381 and checked_density==379 and checked_range==381 and not diff
(ROOT/'validation/interval_bounds_independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))

# A separate arithmetic review enumerates every unpaired option, rather than
# importing the recommendation envelope builder or assuming matching order.
evidence={}
for x in read(ROOT/'recommendation_interval/145原字段_完整字符串解析与单元格证据.csv'):
    evidence.setdefault(x['observation_version_key'],{})[x['field']]=[F(v) for v in json.loads(x['numbers'])]
versions=read(ROOT/'recommendation_interval/29配置版本_四技术条件保守外包络核查.csv')
options_checked=passed=failed=0;differences=[]
for x in versions:
    p=evidence[x['observation_version_key']]; outcomes=[]
    for speed,ran,den,mass,energy in itertools.product(*[p[k] for k in ['max_speed_30min_kmh','range_km','density_whkg','curb_mass_kg','consumption_kwh100km']]):
        cap=(F(112,10000)*mass+F(4,10)) if mass<=1000 else (F(78,10000)*mass+F(38,10)) if mass<=1600 else (F(48,10000)*mass+F(86,10))
        outcomes.append(speed>=100 and ran>=200 and den>=125 and energy<=cap)
        options_checked+=1
    if all(outcomes):passed+=1;expected='四项声明值在全部外包络满足常规门槛'
    elif not any(outcomes):failed+=1;expected='至少一项在全部外包络不满足常规门槛'
    else:expected='外包络仍跨越门槛，需配置配对证据'
    if x['four_requirement_interval_screen']!=expected:differences.append(x['observation_version_key'])
assert len(versions)==29 and passed==28 and failed==1 and not differences
result=dict(configuration_versions=29,parsed_fields=145,cartesian_corners_or_options_checked=options_checked,
    all_unpaired_options_satisfy_ordinary_numeric_conditions=passed,all_unpaired_options_fail_ordinary_numeric_conditions=failed,
    differences=differences,arithmetic='Independent exact rational calculation over every unpaired option; no physical configuration identity inferred')
(ROOT/'validation/recommendation_interval_independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
