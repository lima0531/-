#!/usr/bin/env python3
"""Rebuild observed event states from newly recovered official withdrawal records.

The analytical cohort and frozen original 1991 are preserved. This is observed
catalogue event reconstruction, not a claim about VIN-level eligibility or exit.
"""
from pathlib import Path
import argparse,csv,json,hashlib,shutil,collections,datetime
from decimal import Decimal

PANEL='研究数据/车型月度面板_2022至2024.csv'
STATES='研究数据/重建样本_三截点状态.csv'
RISK='研究数据/公告前风险集_连续处理强度输入.csv'
MEMBERS='研究数据/样本成员重建.csv'
EVENTS='研究数据/资格事件_重建去重表.csv'
LINKS='研究数据/资格事件_逐原件连接.csv'
TRAJ='研究数据/政策后资格轨迹与重申报标签.csv'
SNAP='研究数据/重建样本_两截点参数与暴露.csv'
JOIN='官方技术清单/重建3328_官方清单标记与资格轨迹.csv'
LAYERS='官方技术清单/五档数值层_逐型号归属与判据2877行.csv'
LAYER_ALIAS='官方技术清单/五档数值层_逐型号归属与判据.csv'
GROUPS='官方技术清单/公告前风险集_官方标记与数值层对账.csv'
WITHDRAW_GROUP='官方技术清单/2024撤销观察_分母与集合对账.csv'
OUTSIDE='官方技术清单/2024撤销观察_风险集外8型号.csv'
OUTSIDE_ALIAS='官方技术清单/2024撤销观察_风险集外型号.csv'
OFFICIAL='官方技术清单/官方不符合技术要求_全表4160行.csv'
ENUM='目录覆盖/原件逐表独立枚举.csv'


def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);rows=list(reader)
    assert len(reader.fieldnames)==len(set(reader.fieldnames)),str(path)
    return reader.fieldnames,rows


def write(path,fields,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)


def join(values):return '|'.join(sorted(set(values)-{''}))
def shortfall(value,threshold):return str(max(Decimal(0),(Decimal(threshold)-Decimal(value))/Decimal(threshold))) if value else ''


def observed_state(events,cutoff):
    possible=[r for r in events if not r['public_date_lower_bound'] or r['public_date_lower_bound']<=cutoff]
    certain=[r for r in possible if r['public_date_upper_bound']<=cutoff]
    required=max((r['public_date_lower_bound'] for r in certain),default='')
    latest=[r for r in possible if min(r['public_date_upper_bound'],cutoff)>=required]
    actions={r['action'] for r in latest}
    if not certain:actions.add('未观察到列入')
    if actions=={'列入'}:state,active,robust='在册（区间口径下的已收集事件）','1','1'
    elif actions=={'撤销'}:state,active,robust='已撤销（区间口径下的已收集事件）','0','1'
    elif actions=={'未观察到列入'}:state,active,robust='未列入（已收集记录范围）','0','1'
    else:state,active,robust='日期区间导致状态不确定','','0'
    exacts={r['publish_date_exact'] for r in latest}
    return dict(state=state,catalogue_active_observed=active,state_robust_under_date_bounds=robust,
      possible_last_event_ids=join(r['event_id'] for r in latest),possible_last_actions=join(actions),
      last_event_exact_date=next(iter(exacts)) if len(exacts)==1 else '',
      certain_observed_event_count=str(len(certain)),potential_event_count=str(len(latest)))


def layer(ready,distance,density):
    if not ready:return '单值不足'
    r=Decimal(distance)<200;d=Decimal(density)<125
    if r and d:return '两项数值低于常规阈值'
    if r:return '续航单项低于常规阈值'
    if d:return '密度代理单项低于常规阈值'
    return '两项数值均达到常规阈值'


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--base',type=Path,required=True);ap.add_argument('--coverage',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    base=args.base.resolve();cov=args.coverage.resolve();out=args.output.resolve();data=out/'data_v1_3';out.mkdir(parents=True,exist_ok=True)
    assert not(base==data or base in data.parents)
    csv_paths=sorted(base.rglob('*.csv'));baseline={str(p.relative_to(base)):read(p) for p in csv_paths}
    base_hashes={str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in csv_paths}
    shutil.copytree(base,data,dirs_exist_ok=True)
    fields,members=baseline[MEMBERS];membermap={r['model_key']:r for r in members};keys=set(membermap)
    assert len(members)==len(keys)==3328
    assert sum(r['in_frozen_1991']=='1' for r in members)==1991
    eventfields,oldevents=baseline[EVENTS];linkfields,oldlinks=baseline[LINKS]
    neweventfields,newevents=read(cov/'new_withdrawal_events.csv');newlinkfields,newlinks=read(cov/'new_withdrawal_source_links.csv')
    fullfields,fullenum=read(cov/'new_withdrawal_full_enumeration_2020_rows.csv')
    assert eventfields==neweventfields and linkfields==newlinkfields
    affected={r['model_key'] for r in newevents};assert len(newevents)==len(affected)==73 and affected<=keys
    eventids={r['event_id'] for r in oldevents};assert len(eventids)==len(oldevents)
    assert not eventids & {r['event_id'] for r in newevents}
    assert len(newlinks)==len(newevents)
    for r in newevents:
        assert r['action']=='撤销' and r['effective_date_exception']=='0' and r['reapplication_signal']=='0'
        assert r['publish_date_exact']==r['public_date_lower_bound']==r['public_date_upper_bound']
    fulllinks={r['source_record_id']:r for r in fullenum}
    assert len(fulllinks)==len(fullenum)==2020
    for r in newlinks:
        orig=fulllinks[r['source_record_id']]
        assert r['model_key']==orig['model_key'] and r['source_sha256']==orig['source_sha256']
        source_path=Path(r['source_file'])
        if not source_path.is_file():source_path=cov/'raw'/source_path.name
        assert hashlib.sha256(source_path.read_bytes()).hexdigest()==r['source_sha256']
        assert r['public_date_upper_bound']==orig['official_page_registered_public_date']
    events=sorted(oldevents+newevents,key=lambda r:(r['model_key'],r['public_date_upper_bound'],r['action'],r['event_id']))
    links=sorted(oldlinks+newlinks,key=lambda r:(r['model_key'],r['public_date_upper_bound'],r['event_id'],r['source_record_id']))
    natural=[(r['model_key'],r['system'],r['event_batch'],r['action']) for r in events]
    assert len(set(natural))==len(events)
    write(data/EVENTS,eventfields,events);write(data/LINKS,linkfields,links)
    bymodel=collections.defaultdict(list)
    for r in events:bymodel[r['model_key']].append(r)
    oldbymodel=collections.defaultdict(list)
    for r in oldevents:oldbymodel[r['model_key']].append(r)
    for key in affected:
        assert len(oldbymodel[key])==1 and oldbymodel[key][0]['action']=='列入'
    cache={}
    def state(key,cutoff):
        k=(key,cutoff)
        if k not in cache:cache[k]=observed_state(bymodel[key],cutoff)
        return cache[k]
    # Listing membership is computed from source upper dates; withdrawals cannot
    # remove cohort membership or change the original frozen sample.
    _,sources=baseline['研究数据/原件列入_成员来源长表.csv'];sourcesmodel=collections.defaultdict(list)
    for r in sources:sourcesmodel[r['model_key']].append(r)
    for r in members:
        first=min(x['public_date_upper_bound'] for x in sourcesmodel[r['model_key']])
        assert r['membership_announcement_cohort']==str(int(first<='2023-12-10'))
        assert r['membership_implementation_cohort']==str(int(first<='2023-12-31'))
    pre={k:state(k,'2023-12-10') for k in keys}
    riskset={k for k in keys if membermap[k]['membership_announcement_cohort']=='1' and pre[k]['catalogue_active_observed']=='1'}
    _,snapshots=baseline[SNAP];snapmap={(r['model_key'],r['cutoff']):r for r in snapshots}
    riskfields,oldrisk=baseline[RISK];risk=[];riskmap={}
    for old in oldrisk:
        r=dict(old);key=r['model_key'];p=snapmap[(key,'2023-12-10')]
        r['announcement_state']=pre[key]['state'];r['announcement_active_observed']=pre[key]['catalogue_active_observed']
        expected_range=shortfall(p['range_point'],'200');expected_density=shortfall(p['density_proxy_point'],'125')
        expected_joint=str(max(Decimal(expected_range),Decimal(expected_density))) if expected_range and expected_density else ''
        for col,expected in [('continuous_exposure_range',expected_range),('continuous_exposure_density_proxy',expected_density),('continuous_exposure_joint_max',expected_joint)]:
            assert (r[col]==expected=='') or (r[col] and expected and Decimal(r[col])==Decimal(expected))
        # Event additions cannot change the frozen parameter exposure. Preserve
        # the exact inherited strings as well as their Decimal values.
        r['exposure_record_ids']=p['possible_latest_record_ids'];r['exposure_max_observation_upper']=p['possible_date_upper_max'];r['range_cycle_explicit']=p['range_cycle_explicit']
        ready=key in riskset and bool(p['range_point']) and bool(p['density_proxy_point'])
        r['descriptive_continuous_did_input_ready']=str(int(ready))
        r['exclusion_from_numeric_primary_reason']='不属于公告前队列' if r['membership_announcement_cohort']!='1' else '公告前状态未稳定为在册' if key not in riskset else '两项单值暴露不足' if not ready else ''
        risk.append(r);riskmap[key]=r
    write(data/RISK,riskfields,risk)
    panel_fields,oldpanel=baseline[PANEL];panel=[]
    for old in oldpanel:
        r=dict(old);key=r['model_key'];end=r['month_end'];s=state(key,end);rr=riskmap[key]
        for col in ['state','catalogue_active_observed','state_robust_under_date_bounds','possible_last_event_ids','last_event_exact_date']:r[col]=s[col]
        r['explicit_withdrawal_observed_cumulative']=str(int(any(e['action']=='撤销' and e['public_date_upper_bound']<=end for e in bymodel[key])))
        r['reapplication_observed_cumulative']=str(int(any(e['reapplication_signal']=='1' and e['public_date_upper_bound']<=end for e in bymodel[key])))
        for dst,src in [('exposure_range_locked_preannouncement','continuous_exposure_range'),('exposure_density_proxy_locked_preannouncement','continuous_exposure_density_proxy'),('exposure_joint_max_locked_preannouncement','continuous_exposure_joint_max'),('exposure_source_ids','exposure_record_ids'),('descriptive_continuous_did_input_ready','descriptive_continuous_did_input_ready')]:r[dst]=rr[src]
        panel.append(r)
    write(data/PANEL,panel_fields,panel)
    sf,oldstates=baseline[STATES];states=[]
    for old in oldstates:
        r=dict(old);r.update(state(r['model_key'],r['cutoff']));states.append(r)
    write(data/STATES,sf,states)
    tf,oldtraj=baseline[TRAJ];traj=[];trajmap={}
    for old in oldtraj:
        r=dict(old);key=r['model_key'];ee=bymodel[key]
        withdrawals=[e for e in ee if e['action']=='撤销' and '2024-01-01'<=e['public_date_upper_bound']<='2024-12-31']
        first=min((e['public_date_upper_bound'] for e in withdrawals),default='9999-12-31')
        relisted=[e for e in ee if e['action']=='列入' and e['public_date_lower_bound']>first and e['public_date_upper_bound']<='2024-12-31']
        r.update(post2024_withdrawal_observed=str(int(bool(withdrawals))),withdrawal_event_ids=join(e['event_id'] for e in withdrawals),relisted_after_2024_withdrawal_observed=str(int(bool(relisted))),relisting_event_ids=join(e['event_id'] for e in relisted),reapplication_observed_by_2024_year_end=str(int(any(e['reapplication_signal']=='1' and e['public_date_upper_bound']<='2024-12-31' for e in ee))))
        for col,cut in [('state_preannouncement','2023-12-10'),('state_preimplementation','2023-12-31'),('state_year_end_2024','2024-12-31')]:r[col]=state(key,cut)['state']
        traj.append(r);trajmap[key]=r
    write(data/TRAJ,tf,traj)
    _,official=baseline[OFFICIAL];officialmap={r['model_key']:r for r in official};assert len(officialmap)==len(official)
    jf,oldjoins=baseline[JOIN];joins=[];joinmap={}
    for old in oldjoins:
        r=dict(old);key=r['model_key'];rr=riskmap[key];tt=trajmap[key]
        r['in_preannouncement_active_riskset']=str(int(key in riskset));r['numeric_input_ready']=rr['descriptive_continuous_did_input_ready']
        r['range_cycle_explicit']=rr['range_cycle_explicit'];r['range_exposure_pre20231210']=rr['continuous_exposure_range'];r['density_proxy_exposure_pre20231210']=rr['continuous_exposure_density_proxy']
        assert r['official_nonconformance_list_presence_observed']==str(int(key in officialmap))
        for col in ['post2024_withdrawal_observed','relisted_after_2024_withdrawal_observed','reapplication_observed_by_2024_year_end']:r[col]=tt[col]
        joins.append(r);joinmap[key]=r
    write(data/JOIN,jf,joins)
    lf,oldlayers=baseline[LAYERS];oldlayermap={r['model_key']:r for r in oldlayers};layers=[];layermap={}
    for key in sorted(riskset):
        r=dict(oldlayermap.get(key,{col:'' for col in lf}));rr=riskmap[key];p=snapmap[(key,'2023-12-10')];ready=rr['descriptive_continuous_did_input_ready']=='1'
        r.update(model_key=key,cutoff='2023-12-10',full_technical_conformity_certified='0',configuration_identity_certified='0')
        r.update(numeric_input_ready=str(int(ready)),range_point_km=p['range_point'],density_proxy_point_Wh_per_kg=p['density_proxy_point'],range_cycle_explicit=p['range_cycle_explicit'],possible_latest_record_ids=p['possible_latest_record_ids'],numeric_layer=layer(ready,p['range_point'],p['density_proxy_point']),insufficient_reason='' if ready else '两项单值暴露不足')
        r['raw_threshold_predicate']=f"numeric_input_ready=1; range_point < 200: {int(Decimal(p['range_point'])<200)}; density_proxy_point < 125: {int(Decimal(p['density_proxy_point'])<125)}" if ready else 'numeric_input_ready != 1；保持未知，不以0替代缺值'
        r['raw_threshold_matches_exposure_layer']='1';layers.append(r);layermap[key]=r
    write(data/LAYERS,lf,layers);write(data/LAYER_ALIAS,lf,layers)
    gf,oldgroups=baseline[GROUPS];groups=[]
    for old in oldgroups:
        r=dict(old);group={k for k in riskset if layermap[k]['numeric_layer']==r['numeric_layer']};marked={k for k in group if k in officialmap};wd={k for k in group if trajmap[k]['post2024_withdrawal_observed']=='1'};reapp={k for k in marked if trajmap[k]['reapplication_observed_by_2024_year_end']=='1'}
        n=len(marked);d=len(group)
        r.update(risk_models=str(d),official_marked=str(n),official_unmarked=str(d-n),marked_fraction=format(Decimal(n)/Decimal(d),'.6f') if d else '',marked_fraction_numerator=str(n),marked_fraction_denominator=str(d),marked_fraction_exact=f'{n}/{d}',**{'2024_withdrawal_observed':str(len(wd)),'marked_and_withdrawal_observed':str(len(marked&wd)),'marked_and_reapplication_observed':str(len(reapp))})
        groups.append(r)
    write(data/GROUPS,gf,groups)
    wdset={k for k in keys if trajmap[k]['post2024_withdrawal_observed']=='1'};relset={k for k in keys if trajmap[k]['relisted_after_2024_withdrawal_observed']=='1'};riskwd=wdset&riskset;outsidewd=wdset-riskset
    denomsets={'全队列2024撤销观察':(wdset,keys),'公告前风险集2024撤销观察':(riskwd,riskset),'风险集外2024撤销观察':(outsidewd,keys-riskset),'全队列撤销后再列入':(relset,wdset),'风险集撤销后再列入':(relset&riskset,riskwd)}
    df,olddenom=baseline[WITHDRAW_GROUP];denom=[]
    relation=f'再列入{len(relset)}个属于{len(wdset)}及{len(riskwd)}的子集，不另加；{len(wdset)}={len(riskwd)}+{len(outsidewd)}'
    for old in olddenom:
        r=dict(old);nn,dd=denomsets[r['metric']];n=len(nn);d=len(dd);r.update(numerator=str(n),denominator=str(d),exact_fraction=f'{n}/{d}',fraction_6dp=format(Decimal(n)/Decimal(d),'.6f') if d else '',relisting_relation=relation);denom.append(r)
    write(data/WITHDRAW_GROUP,df,denom)
    of,oldoutside=baseline[OUTSIDE];oldoutmap={r['model_key']:r for r in oldoutside};outside=[]
    for key in sorted(outsidewd):
        r=dict(oldoutmap.get(key,{col:'' for col in of}));rr=riskmap[key];jj=joinmap[key]
        r.update(model_key=key,membership_announcement_cohort=membermap[key]['membership_announcement_cohort'],in_preannouncement_active_riskset='0',announcement_state=rr['announcement_state'],official_nonconformance_list_presence_observed=jj['official_nonconformance_list_presence_observed'],post2024_withdrawal_observed='1',relisted_after_2024_withdrawal_observed=trajmap[key]['relisted_after_2024_withdrawal_observed'],risk_exclusion_basis='不属于公告前队列' if membermap[key]['membership_announcement_cohort']!='1' else '属于公告前队列，但冻结点在册观察标记不为1')
        outside.append(r)
    write(data/OUTSIDE,of,outside);write(data/OUTSIDE_ALIAS,of,outside)
    # The original nine-file / 3007-row tables remain explicitly scoped to their
    # retained sources. New source rows are kept separately and added to the
    # combined independent source enumeration so new event links have lineage.
    ef,oldenum=baseline[ENUM];expanded=list(oldenum)
    for src in fullenum:
        expanded.append(dict(source_file=src['source_file'],system='免征目录',kind='撤销名单',model_raw=src['model_raw'],model_key=src['model_key'],engine=json.loads(src['source_location'])['engine'],location=src['source_location'],sequence_raw=src['sequence'],source_sha256=src['source_sha256']))
    assert set(expanded[-1])==set(ef)
    write(data/ENUM,ef,expanded)
    write(data/'目录覆盖/新增2份历史撤销_独立全表枚举.csv',fullfields,fullenum)
    shutil.copyfile(cov/'new_withdrawal_sources.json',data/'目录覆盖/新增历史撤销_原页与SHA证据.json')
    # Changes and validation use newly observed counts. Old numeric constants
    # are recorded as comparison baselines, never asserted as new results.
    writes=[EVENTS,LINKS,PANEL,STATES,RISK,TRAJ,JOIN,LAYERS,GROUPS,WITHDRAW_GROUP,OUTSIDE,ENUM]
    change_stats=[]
    for rel in writes:
        oldrows=baseline[rel][1];_,newrows=read(data/rel)
        if rel in [PANEL,STATES]:pk=['model_key','month' if rel==PANEL else 'cutoff']
        elif rel==EVENTS:pk=['event_id']
        elif rel==LINKS:pk=['event_id','source_record_id']
        elif rel==GROUPS:pk=['numeric_layer']
        elif rel==WITHDRAW_GROUP:pk=['metric']
        elif rel==ENUM:pk=['source_sha256','location','model_raw']
        else:pk=['model_key']
        om={tuple(r[k] for k in pk):r for r in oldrows};nm={tuple(r[k] for k in pk):r for r in newrows};common=om.keys()&nm.keys();changed=[k for k in common if om[k]!=nm[k]]
        change_stats.append(dict(table=rel,old_rows=len(oldrows),new_rows=len(newrows),new_keys=len(nm.keys()-om.keys()),removed_keys=len(om.keys()-nm.keys()),changed_existing_rows=len(changed),changed_fields=dict(collections.Counter(col for k in changed for col in om[k] if om[k][col]!=nm[k][col]))))
    write(out/'data_v1_3_表变化.csv',['table','old_rows','new_rows','new_keys','removed_keys','changed_existing_rows','changed_fields'],[{**r,'changed_fields':json.dumps(r['changed_fields'],ensure_ascii=False)} for r in change_stats])
    affected_rows=[]
    for key in sorted(affected):
        newev=[e for e in newevents if e['model_key']==key][0];oldstate=observed_state(oldbymodel[key],'2023-12-10');oldrr=next(r for r in oldrisk if r['model_key']==key)
        affected_rows.append(dict(model_key=key,new_withdrawal_event_id=newev['event_id'],withdrawal_observed_date=newev['publish_date_exact'],state_preannouncement_before=oldstate['state'],state_preannouncement_after=pre[key]['state'],in_riskset_before=str(int(membermap[key]['membership_announcement_cohort']=='1' and oldstate['catalogue_active_observed']=='1')),in_riskset_after=str(int(key in riskset)),numeric_ready_before=oldrr['descriptive_continuous_did_input_ready'],numeric_ready_after=riskmap[key]['descriptive_continuous_did_input_ready'],official_marked=str(int(key in officialmap)),old_listing_event_ids=join(e['event_id'] for e in oldbymodel[key]),source_record_ids=newev['source_record_ids']))
    write(out/'73型号_撤销补漏对风险集的影响.csv',list(affected_rows[0]),affected_rows)
    statecounts=collections.Counter((r['cutoff'],r['state']) for r in states);panelcounts=collections.Counter(r['state'] for r in panel)
    assert len(events)==len(oldevents)+len(newevents) and len(links)==len(oldlinks)+len(newlinks)
    assert len(panel)==len(oldpanel)==len(keys)*36 and len(states)==len(keys)*3
    assert {r['model_key'] for r in risk}==keys and {r['model_key'] for r in joins}==keys
    assert {r['model_key'] for r in layers}==riskset and sum(int(r['risk_models']) for r in groups)==len(riskset)
    assert not riskset&affected
    assert relset<=wdset and sum(int(r['official_marked']) for r in groups)==len(riskset&officialmap.keys())
    assert all(hashlib.sha256((base/p).read_bytes()).hexdigest()==sha for p,sha in base_hashes.items())
    protected=[MEMBERS,SNAP,'研究数据/参数版本_原值与计算代理.csv','1991基线/1991_独立重建名单.csv','研究数据/原件列入_成员来源长表.csv',OFFICIAL]
    assert all(hashlib.sha256((data/p).read_bytes()).hexdigest()==base_hashes[p] for p in protected)
    summary=dict(generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_root=str(base),output_root=str(data),cohort_models=len(keys),original_frozen_models=sum(r['in_frozen_1991']=='1' for r in members),new_source_rows=len(fullenum),new_cohort_withdrawal_events=len(newevents),event_rows=len(events),event_source_links=len(links),preannouncement_risk_models=len(riskset),numeric_input_ready=sum(r['descriptive_continuous_did_input_ready']=='1' for r in risk),risk_single_value_insufficient=sum(k in riskset and riskmap[k]['descriptive_continuous_did_input_ready']!='1' for k in keys),official_marked_all=len(keys&officialmap.keys()),official_marked_in_risk=len(riskset&officialmap.keys()),official_marked_outside_risk=len((keys-riskset)&officialmap.keys()),post2024_withdrawn_models=len(wdset),post2024_withdrawn_in_risk=len(riskwd),post2024_withdrawn_outside_risk=len(outsidewd),post2024_relisted_models=len(relset),cutoff_state_counts=[dict(cutoff=c,state=s,models=n) for (c,s),n in sorted(statecounts.items())],month_end_state_counts=dict(panelcounts),numeric_layer_groups=groups,changed_tables=change_stats,protected_source_and_parameter_files_unchanged=protected,input_base_unchanged=True,observed_state_not_legal_eligibility=True,new_withdrawal_legal_effective_dates_certified=False,first_online_times_certified=False,legacy_layer_filename_compatibility_only=LAYERS,canonical_layer_filename=LAYER_ALIAS,canonical_outside_withdrawal_filename=OUTSIDE_ALIAS,source_correction_base_used=base.name=='corrected_source_base')
    (out/'reconstruction_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    source_note = '另修正源SHA c388317a...的47条事件：旧第32批/2020-06-02改为主管原页可证的第27批/2019-10-25，424条历史语义来源同时同步；原opaque事件ID、来源ID保留。CSA6461FBEV3在2019-12-10重新列入，因此公告前恢复在册。本版修订既含73条漏撤销，也含这组错批日期修复。\n\n' if base.name == 'corrected_source_base' else ''
    (data/'README_版本v1_3.md').write_text(f'''# 数据版本 v1.3：历史撤销补齐与公告批次修正\n\n本版本保留原冻结1991及重建3328成员，参数来源和冻结点单值不变。新增2018-05-22独立撤销名单1882行、第28批撤销名单138行，全表共2020行；其中73个队列型号新增正式撤销观察。{source_note}已按完整新事件重新计算2022—2024每月月末状态、三截点状态、公告前风险集、输入准备标记、后续轨迹、官方标记分层及分母对账。\n\n公告前风险集现为{len(riskset)}；两项单值输入准备型号{summary['numeric_input_ready']}；风险集单值不足{summary['risk_single_value_insufficient']}。这些值取决于已取得来源，仍不认证全目录穷尽、法律资格、低温例外、同配置或市场退出。2024撤销观察集合共{len(wdset)}，风险集内{len(riskwd)}、风险集外{len(outsidewd)}。历史补漏不属于2024撤销，不能把新增73叠加到2024的503。\n\n新增撤销使用主管部门页面明确登记公开观察日期。落款分别2018-05-21和2019-12-06；采用的公开观察日期分别2018-05-22和2019-12-10。尚无逐车型法定撤销生效日期证据，不将公开观察日期改称法定资格失效日。\n\n`五档数值层_逐型号归属与判据.csv` 为规范使用文件。继承的 `五档数值层_逐型号归属与判据2877行.csv` 仅为旧校验脚本的兼容入口，两者内容完全相同，真实行数为{len(layers)}，文件名旧人数不作为本版本统计。\n\n`9份历史撤销...3007行` 等旧范围表仍表示原9份保留来源，未伪称11份；新增两份全表单列于 `目录覆盖/新增2份历史撤销_独立全表枚举.csv`，合并原件逐表枚举已加入2020新增行。\n\n完整差异、输入保护校验和生成脚本见父目录。推荐后续分析使用本v1.3，不再将仅补日期的v1.2作为完整事件数据。\n''',encoding='utf8')
    manifests=[]
    for p in sorted(data.rglob('*')):
        if p.is_file():manifests.append(dict(path=str(p.relative_to(data)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    write(out/'data_v1_3_manifest.csv',['path','bytes','sha256'],manifests)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['numeric_layer_groups','changed_tables','protected_source_and_parameter_files_unchanged']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
