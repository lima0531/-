# 第一批目录公开来源补查

目标历史原件为 `mf_batch01.pdf`，442,883 字节，SHA256 `eac13628c37f01c4da157a2d1916d97acc81fdc295f18e1783549075ce7e5aa7`。本次未取得该相同字节 PDF。

## 新增公告正文影像

官方税务转载页：<https://neimenggu.chinatax.gov.cn/zcwj/zxwj/201809/t20180929_419165.html>。已保存页面的第 224 行真实 `img src="./W020180921737489676085.png"` 指向：<https://neimenggu.chinatax.gov.cn/zcwj/zxwj/201809/W020180921737489676085.png>。

该图片保存为 `nmg_batch1_embedded_notice.png`，338,896 字节，SHA256 `7dd39a3baf4ca82379952a3ea2969e0bfda8c0c30ef8e67bef9ffff3fc20d965`，网络回执同名 `.request.json`。目视核实为工业和信息化部、国家税务总局 2014 年第 54 号盖章公告第一页，落款 2014-08-27。正文明确：

> 现将《免征车辆购置税的新能源汽车车型目录》（第一批）予以公告，自2014年9月1日起开始实施。

因此影像支持第一批公告正文和明示实施日期 2014-09-01，补充既有落款日期证据。它没有目录车型表，不是上述历史 PDF，不认证主管网站公开登记日或全网首次上线时间。顶部手写收文章不作为公开日期证据。

## EIDC 官方历史栏目分页

已读取缓存 <https://www.miit-eidc.org.cn/col/col1536/index.html>，其中明示 `totalRecord=644`、`perPage=15`、`groupSize=1`，并有真实 `nextgroup` 链接。

- 网页引用的 `/module/web/jpage/jquery.jpage.js` 首次 HTTP 502，一次相同 URL 瞬时重试仍 HTTP 502，分别保存回执；没有改变 URL 或编码尝试绕过代理。
- 依据原 `nextgroup` 链接，只把合法分页参数 `page=1` 改为 `page=20`，保留其余参数原串及百分号编码。请求来源和唯一改动保留在 `eidc_native_page20_derivation.json`。
- page=20 返回 HTTP 200，但只有 74 字节空 `<datastore></datastore>`，并无条目。已保存 XML、完整响应头和 SHA256，不能把 HTTP 200 计作目录或日期补齐，也不能据此断言第一批资料不存在。
- 没有请求未发现的文章 ID，没有重试已有 403 URL，未继续遍历任意页号。

## MIIT 原生检索

本子任务最初获授权使用当前官方原生检索，保存了“免征车辆购置税的新能源汽车车型目录 第一批”、“2014年第54号”、“免征车辆购置税 首批”响应和摘要，均无第一批原公告匹配。收到其他代理此前缓存已覆盖这些检索的消息后，没有追加 MIIT 检索。

以上所有文件只写入补采目录，未修改精简包输入。
