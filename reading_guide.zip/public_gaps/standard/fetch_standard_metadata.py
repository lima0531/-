import pathlib, importlib.util, concurrent.futures, json
OUT=pathlib.Path(__file__).parent
SRC=pathlib.Path('/workspace/purchase_tax_audit/round3/technical/complete_technical.py')
spec=importlib.util.spec_from_file_location('old_fetch',SRC)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.OUT=OUT
queries=[('18386','18386'),('std_ev_methods','电动汽车 能量消耗量 续驶里程 试验方法'),('std2021_notice','2021 国家标准 公告'),('18386_1','18386.1-2021'),('18386_2025','18386.1 2025')]
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  results=list(ex.map(lambda x:mod.search(*x),queries))
 print([(queries[i][0],len(r)) for i,r in enumerate(results)])
