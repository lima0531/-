#!/usr/bin/env python3
"""Build a fingerprinted core delivery with only the final analytical CSVs."""
import csv
import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
TARGET=Path('/workspace/购置税项目_补采与修订_v1_3_20261008.zip')
PREFIX='购置税项目_补采与修订_v1_3_20261008'
EXCLUDED_PREFIXES=['archive/recovered/','archive/downloads/','versioning/data_v1_2/',
 'versioning/independent_validation/','versioning/independent_validation_final/',
 'reconstruction/corrected_source_base/','reconstruction/intermediate_2804/',
 'reconstruction/legacy_joins/']
files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file():continue
    rel=str(p.relative_to(ROOT))
    if '__pycache__' in p.parts or any(rel.startswith(x) for x in EXCLUDED_PREFIXES):continue
    if p.suffix.lower()=='.zip':continue
    if rel.startswith('technical/rec') and rel.endswith('_original.pdf'):continue
    if rel.startswith('archive/version_search/') and p.suffix.lower() in {'.wps','.doc','.docx','.xls','.pdf'}:continue
    files.append((p,f'{PREFIX}/round3/{rel}'))
inputzip=Path('/workspace/attachments/0661372f-7991-49f9-8916-4bc9c099b967/购置税项目_必要数据精简包_20261008.zip')
assert hashlib.sha256(inputzip.read_bytes()).hexdigest()=='5e9efd529f45f68065720fa9c98199ea602d5448be53bba1569fe650ae5f1d75'
files.append((inputzip,f'{PREFIX}/input/{inputzip.name}'))
files.append((ROOT/'README.md',f'{PREFIX}/README.md'))
manifest=[{'archive_member':arc,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,arc in files]
assert len(manifest)==len({r['archive_member'] for r in manifest})
with zipfile.ZipFile(TARGET,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p,arc in files:z.write(p,arc)
    z.writestr(f'{PREFIX}/交付文件_SHA256.txt',''.join(f"{r['sha256']}  {r['archive_member'][len(PREFIX)+1:]}\n" for r in manifest))
with zipfile.ZipFile(TARGET) as z:
    assert z.testzip() is None
    for row in manifest:
        b=z.read(row['archive_member'])
        assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert TARGET.stat().st_size<32*1024*1024
result={'path':str(TARGET),'bytes':TARGET.stat().st_size,'sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),
        'files':len(manifest)+1,'all_members_crc_and_sha_verified':True,'original_input_zip_exact':True,
        'canonical_data_root':f'{PREFIX}/round3/reconstruction/data_v1_3'}
(ROOT/'core_package_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
