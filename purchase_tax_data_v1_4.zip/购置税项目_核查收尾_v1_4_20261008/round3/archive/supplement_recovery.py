#!/usr/bin/env python3
"""Collect explicit tax attachments in cached native government pages.

The initial HTMLParser omitted anchors embedded in Shanghai's JavaScript
fileName/document.write fragments. Regex below reads literal anchor elements,
without executing JavaScript or guessing attachment paths. Dates are not used.
"""
import concurrent.futures, csv, hashlib, html, json, re, shutil
from pathlib import Path
from urllib.parse import urljoin
import collect_official_originals as base

ROOT=base.ROOT

def candidates():
    links=[]
    for rec in json.loads((ROOT/'page_manifest.json').read_text()):
        if rec['status']!='ok':continue
        content=Path(rec['local_path']).read_text(encoding='utf-8',errors='replace')
        for href,label in re.findall(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',content,re.I|re.S):
            label=html.unescape(re.sub(r'<[^>]+>','',label)).strip()
            if not ('购置税' in label and re.search(r'\.(?:docx?|pdf|wps)(?:[?#].*)?$',href,re.I)):continue
            url=urljoin(rec['final_url'],html.unescape(href))
            for actual in base.attachment_candidates(url):
                links.append({'url':actual,'label':label,'system':rec['system'],'batch':rec['batch'],'page_url':rec['final_url'],'page_link_url':url,'extraction_method':'literal_anchor_in_page_including_js_fragment'})
    path=Path('/workspace/purchase_tax_audit/round3/dates/cached_page_attachment_urls.json')
    if path.exists():
        for item in json.loads(path.read_text()):
            if '购置税' not in item['text']:continue
            for actual in base.attachment_candidates(item['attachment_url']):
                links.append({'url':actual,'label':item['text'],'page_file':item['page_file'],'page_link_url':item['attachment_url'],'extraction_method':'date_agent_cached_native_page_anchor'})
    index={}
    for item in links:index.setdefault(item['url'],{'url':item['url'],'links':[]})['links'].append(item)
    return index

def rebuild(out):
    matches={}
    for record in out:
        if record.get('status')=='ok' and record.get('sha256') in base.BYHASH:
            file=Path(record['local_path'])
            if file.is_file() and base.sha(file.read_bytes())==record['sha256']:matches.setdefault(record['sha256'],record)
    rows=[]
    for target in base.TARGETS:
        record=matches.get(target['source_sha256']);row=dict(target)
        if record:
            dst=ROOT/'recovered'/target['system']/target['source_file'];dst.parent.mkdir(parents=True,exist_ok=True)
            if not dst.exists():shutil.copyfile(record['local_path'],dst)
            if base.sha(dst.read_bytes())!=target['source_sha256']:raise ValueError('Recovered path SHA disagreement: '+str(dst))
            row.update(recovery_status='sha256_exact',recovered_path=str(dst),download_url=record['requested_url'],recovered_sha256=record['sha256'],recovered_bytes=record['bytes'])
        else:row.update(recovery_status='not_recovered',recovered_path='',download_url='',recovered_sha256='',recovered_bytes='')
        rows.append(row)
    with (ROOT/'106原件公开回收清单.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    pages=json.loads((ROOT/'page_manifest.json').read_text())
    unique={r['sha256'] for r in out if r.get('status')=='ok'}
    summary={'target_originals':len(base.TARGETS),'page_success':sum(r['status']=='ok' for r in pages),'page_total':len(pages),'candidate_attachments':len({r['requested_url'] for r in out}),'attachment_success':sum(r['status']=='ok' for r in out),'unique_successful_attachment_sha256':len(unique),'sha256_exact_recovered':len(matches),'catalogue_exact_recovered':sum(r['scope']=='目录' and r['recovery_status']=='sha256_exact' for r in rows),'historic_withdrawal_exact_recovered':sum(r['scope']=='历史撤销' and r['recovery_status']=='sha256_exact' for r in rows),'unmatched_attachment_versions':len(unique-set(base.BYHASH))}
    (ROOT/'recovery_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False),flush=True)

def main():
    master=json.loads((ROOT/'attachment_manifest.json').read_text())
    oldurls={r['requested_url']:r for r in master}
    todo=[item for url,item in candidates().items() if url not in oldurls]
    out=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures={pool.submit(base.fetch,item['url'],'attachment'):item for item in todo}
        for f in concurrent.futures.as_completed(futures):
            record=dict(f.result(),links=futures[f]['links'],collection_stage='supplement_literal_cached_anchors')
            out.append(record);print(record['status'],record.get('bytes'),record.get('sha256') in base.BYHASH,record['requested_url'],flush=True)
    (ROOT/'supplement_attachment_manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    master.extend(out)
    (ROOT/'attachment_manifest.json').write_text(json.dumps(master,ensure_ascii=False,indent=2));rebuild(master)
if __name__=='__main__':main()
