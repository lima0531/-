import pathlib,json,csv,hashlib,datetime
OUT=pathlib.Path(__file__).parent
PRIOR=pathlib.Path('/workspace/purchase_tax_audit/round3/technical/standard_metadata')
old=json.loads((PRIOR/'standard_policy32_metadata.json').read_text())
policy13_text=(OUT/'policy2021_adjustment.txt').read_text()
implementation_quote='一、自2021年10月1日起，《插电式混合动力电动乘用车 技术条件》（GB/T 32694-2021）、《轻型混合动力电动汽车能量消耗量试验方法》（GB/T 19753-2021）、《电动汽车能量消耗量和续驶里程试验方法 第1部分：轻型汽车》（GB/T 18386.1-2021）等标准（以下简称新版标准）正式实施。'
assert ''.join(implementation_quote.split()) in ''.join(policy13_text.split()),'implementation date quotation mismatch'
policy13_receipt=json.loads((OUT/'policy2021_adjustment_request.json').read_text())
assert policy13_receipt['status']==200
assert hashlib.sha256((OUT/'policy2021_adjustment.html').read_bytes()).hexdigest()==policy13_receipt['sha256']
receipts=[]
for p in sorted(OUT.glob('*_request.json')):
 r=json.loads(p.read_text());r['receipt_file']=p.name
 receipts.append(r)
status={
 'standard_number':old['standard_number'],
 'standard_name':old['standard_name'],
 'standard_number_and_name_provenance':'2023年第32号公告原始技术要求附件，第1页一第4项；政策引用证据，非标准登记页',
 'policy_attachment_sha256':old['policy_attachment_sha256'],
 'standard_release_date':None,'standard_implementation_date':'2021-10-01',
 'standard_implementation_date_evidence':{
  'evidence_type':'联合主管部门正式公告正文明确列出标准编号及正式实施日，非标准登记页',
  'policy_number':'2021年第13号','policy_signed_date':'2021-04-30',
  'policy_page_registered_public_date':'2021-05-13','clause':'第一条',
  'source_url':policy13_receipt['url'],'source_sha256':policy13_receipt['sha256'],
  'raw_quote':implementation_quote,
 },
 'standard_current_status':None,'replaces_standard':None,'replaced_by_standard':None,
 'registry_metadata_completion_status':'partial_one_date_completed_from_official_policy_registry_not_obtained',
 'public_gaps_are_not_private_data':True,
 'current_samr_registry_access_retested':False,
 'source_access_note':'上轮标准登记平台与主管机关主站已经由执行环境代理以403拒绝；本轮未重复已拒绝的URL。新检索工信部官方原生站内API与三个地方市场监管局官网，仍未取得登记字段。',
 'unaccepted_evidence':[{
  'file':'pure_ev2021_explanation.docx',
  'url':'https://www.miit.gov.cn/cms_files/filemanager/1226211233/attach/20216/3755e95d908347499ecfdcaa48d5d929.docx',
  'reason':'2021年《纯电动乘用车技术条件》征求意见稿编制说明仅引用GB/T 18386.1编号和名称；其中其他标准的日期/代替关系不能移用到GB/T 18386.1-2021。',
 },{
  'files':['exact_stdname.json','exact_national2021_3.json'],
  'reason':'q为空、pq不为空的原生接口请求返回全站81323组数据，不能证明完整词组检索成功，也不能作为该标准检索命中。',
 }],
 'manual_request':{
  'source':'全国标准信息公共服务平台或国家标准全文公开系统中的GB/T 18386.1-2021具体标准详情页',
  'minimum_fields':['完整标准编号及名称','发布日期','页面查询时的状态','代替标准','被代替标准（如有）','详情页完整URL','查询时间'],
  'already_completed':'实施日期已由2021年第13号公告正文明确确证为2021-10-01；取得登记页后可交叉核对，不需要用户单独寻找此日期。',
  'acceptable_capture':'官方详情页保存的HTML/PDF，或包含网址与上述字段的截图；若改用国家标准公告，保留正文和该标准所在附件行。',
  'not_required':'仅补登记元数据不必购买标准全文，也不必提供任何账户密码。',
  'impact':'不影响已按2023年第32号政策原文确证的编号、名称、附录A及政策门槛；实施日期已经确证；尚不能审定标准发布日期、替代链或2026年现行状态。',
 },
 'new_request_receipts':receipts,
 'build_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(OUT/'standard_register_completion.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
with (OUT/'标准登记_待人工补字段.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['standard_number','field','value','status','source_required']);w.writeheader()
 for field in ['standard_release_date','standard_current_status','replaces_standard','replaced_by_standard']:
  w.writerow(dict(standard_number=old['standard_number'],field=field,value='',status='未取得官方登记证据，保持为空',source_required='官方具体标准详情页或国家标准发布公告的具体附件行'))
with (OUT/'文件_SHA256.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['file','bytes','sha256']);w.writeheader()
 for p in sorted(OUT.iterdir()):
  if p.is_file() and p.name!='文件_SHA256.csv':
   b=p.read_bytes();w.writerow(dict(file=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
print(json.dumps({'status':status['registry_metadata_completion_status'],'new_receipts':len(receipts),'manual_fields':4,'newly_completed_field':'standard_implementation_date','implementation_date':'2021-10-01','independent_checks':['exact_official_clause_quote','http_200_receipt','source_file_sha256']},ensure_ascii=False))
