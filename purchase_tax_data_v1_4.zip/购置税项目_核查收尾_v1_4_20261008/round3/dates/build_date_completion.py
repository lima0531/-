from pathlib import Path
import csv,json,re,html,hashlib
ROOT=Path(__file__).parent
BASELINE=ROOT.parents[1]/'round2'/'dates'/'97批次日期_第29批续查更新.csv'
INPUT=ROOT.parents[1]/'compact_input_20261008'/'购置税项目_必要数据精简包_20261008'
MAP={
8:('batches_1_13/batch_8_miit_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_4894ed6fe7344ea089f37975b8cc6372.html'),
9:('completed_primary/batch9_announcement.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_0d2491acc4a149c39d94f0995e065ce5.html'),
12:('batches_1_13/batch_12_miit_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_e06ed449b13b49be97209da2d73ba858.html'),
13:('batches_1_13/batch_13_miit_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_7f81081be82f45628fb8e48e5eda2c6c.html'),
15:('completed_primary/batch15_announcement.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_f2dc8105eaa2477c8889cf41df461d54.html'),
19:('batches_15_23/batch19_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_ea889ad4dc414d8394edc59f54dcc197.html'),
20:('completed_primary/batch20_announcement.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_62c81fa8bf2743fe977f78d9ef5498db.html'),
21:('batches_15_23/batch21_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_3a0e67adcbc54e819d5568aea044bd2a.html'),
23:('batches_15_23/batch23_gg.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_f3634936dfbd4b199332a3790b8ade25.html'),
25:('main_25_31/batch25_primary.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_91235426781c4b31a7fa457ff0126e10.html'),
27:('main_25_31/batch27_department_primary.html','https://www.miit.gov.cn/jgsj/zbys/gzdt/art/2020/art_9f09e324e0064eb6ac473ff2949f699c.html'),
30:('main_25_31/batch30_primary.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_c381d802c32e41c8a392227d224dcbe1.html'),
31:('main_25_31/batch31_primary.html','https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_865ff0307b114be9a87325b20e15f25b.html'),
}
# Saved receipts bind names to URLs; use those as source of truth, never guessed article IDs.
for b,(f,u) in list(MAP.items()):
 p=ROOT/f
 if p.with_name(p.stem+'_evidence.json').exists():
  j=json.loads(p.with_name(p.stem+'_evidence.json').read_text());u=j['url']
 if p.with_name(p.name+'.request.json').exists():
  j=json.loads(p.with_name(p.name+'.request.json').read_text());u=j['request_url']
 if p.with_suffix('.json').exists():
  j=json.loads(p.with_suffix('.json').read_text());u=j.get('source_url',u)
 MAP[b]=(f,u)

def evidence(path,url,batch):
 raw=path.read_bytes();text=raw.decode('utf8','replace')
 plain=html.unescape(re.sub('<[^>]*>',' ',text));plain=re.sub(r'\s+',' ',plain)
 title=html.unescape(re.search(r'<title>(.*?)</title>',text,re.S)[1]).strip()
 date=re.search(r'发布日期：\s*</span>\s*<span[^>]*>\s*(\d{4}-\d{2}-\d{2})',text)
 con=re.search(r'id="con_time"[^>]*>\s*发布时间：\s*(\d{4}-\d{2}-\d{2})([^<]*)',text)
 signed=re.search(r'成文日期：\s*</span>\s*<span[^>]*>\s*(\d{4}-\d{2}-\d{2})',text)
 meta=re.search(r'<meta name="PubDate" content="([^"]+)"',text)
 make=re.search(r'<meta name="MakeTime" content="([^"]+)"',text)
 exact=date[1] if date else con[1]
 assert date or con, str(path)
 assert not (date and con and date[1]!=con[1]),str(path)
 rec={'system':'免征目录','source_batch':batch,'publish_date_exact':exact,'evidence_file':str(path),'source_url':url,'evidence_sha256':hashlib.sha256(raw).hexdigest(),'page_title':title,'visible_publish_date':date[1] if date else '', 'visible_publish_time':con[1]+' '+con[2].strip() if con else '', 'signed_date_on_page':signed[1] if signed else '', 'page_meta_pubdate':meta[1] if meta else '', 'page_meta_maketime':make[1] if make else '', 'publication_metadata_conflict':int(bool(meta and meta[1][:10]!=exact)), 'other_official_registered_date':'2019-10-30' if batch==27 else '', 'historical_first_online_time_verified':0,'registered_date_definition':'主管部门现存官方页明确登记公开观察日；不认证历史首次上线时间','date_evidence':[{'line':i,'raw':s.strip()} for i,s in enumerate(text.splitlines(),1) if any(x in s for x in ['PubDate','MakeTime','成文日期','发布日期','id="con_time"'])]}
 if batch==27:rec['conflict_explanation']='装备工业司工作动态页明确2019-10-25；公告页明确2019-10-30。采用较早主管部门公开观察登记日，保留两页差异。两页目录原件SHA相同且与历史目标一致；撤销附件只有10-25部门页匹历史目标SHA。'
 return rec

records=[evidence(ROOT/f,u,b) for b,(f,u) in MAP.items()]
# Required carry-forward accepted sources from the prior round, with source evidence preserved.
p2=ROOT/'completed_primary'/'batch2_department.html'
archive_p2=ROOT.parent/'archive'/'pages'/'b0da6e3962135f4ae5215089f7c803bc44b1d03ce9ebb20a5c407c8ca79e301c.html'
p2.write_bytes(archive_p2.read_bytes())
ev2=evidence(p2,'https://www.miit.gov.cn/jgsj/zbys/wjfb/art/2020/art_f6a1b9208b574ad080f292b86a6add91.html',2)
assert ev2['publish_date_exact']=='2014-10-29'
ev2['prior_eidc_evidence_file']=str(INPUT/'日期续查'/'已保存原页_mf02_eidc.html')
ev2['registered_date_definition']='主管部门现存官方文件页发布时间2014-10-29，与第2轮装备中心登记日一致；不认证首次上线时刻；原签署日期冲突仍保留'
records.append(ev2)
p29=ROOT.parents[1]/'round2'/'batch29_primary_live.html'
records.append(evidence(p29,'https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_4081b22322a54680896d5325ef0fe936.html',29))
records.sort(key=lambda r:r['source_batch'])
(ROOT/'registered_date_evidence.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
cols=['system','source_batch','publish_date_exact','evidence_file','source_url','evidence_sha256','registered_date_definition','publication_metadata_conflict','other_official_registered_date','historical_first_online_time_verified']
with (ROOT/'accepted_registered_dates.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(records)
base=list(csv.DictReader(BASELINE.open(encoding='utf-8-sig')));changes=[];rmap={(r['system'],str(r['source_batch'])):r for r in records}
extra=['round3_registered_date_update_applied','round3_evidence_file','round3_evidence_sha256','round3_page_meta_pubdate','round3_page_meta_maketime','round3_publication_metadata_conflict','round3_other_official_registered_date','round3_date_conflict_explanation']
for r in base:
 r.update({k:'' for k in extra})
 key=(r['system'],r['batch'])
 if key not in rmap or int(r['batch']) not in MAP:continue
 ev=rmap[key]; changes.append({'system':r['system'],'batch':r['batch'],'before_exact':r['publish_date_exact'],'before_lower':r['public_date_lower_bound'],'before_upper':r['public_date_upper_bound'],'after_exact':ev['publish_date_exact'],'evidence_file':ev['evidence_file'],'source_url':ev['source_url']})
 r['publish_date_exact']=ev['publish_date_exact'];r['publish_date_exact_is_verified']='1';r['public_date_lower_bound']=ev['publish_date_exact'];r['public_date_upper_bound']=ev['publish_date_exact'];r['date_basis']=ev['registered_date_definition'];r['bound_chronology_assumption']='';r['source_url']=ev['source_url'];r['source_ref']=ev['evidence_file'];r['current_upper_bound_page_opened']='1';r['full_historical_first_online_time_verified']='0';r['this_continuation_primary_page_retrieved']='1';r['本轮是否重取原页']='1';r['原页取证阶段']='第3轮官方主管部门缺批登记日期补采'
 r.update(round3_registered_date_update_applied='1',round3_evidence_file=ev['evidence_file'],round3_evidence_sha256=ev['evidence_sha256'],round3_page_meta_pubdate=ev.get('page_meta_pubdate',''),round3_page_meta_maketime=ev.get('page_meta_maketime',''),round3_publication_metadata_conflict=str(ev['publication_metadata_conflict']),round3_other_official_registered_date=ev.get('other_official_registered_date',''),round3_date_conflict_explanation=ev.get('conflict_explanation',''))
 assert r['public_date_lower_bound']<=r['public_date_upper_bound']
with (ROOT/'97批次日期_本轮官方登记补采更新.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(base[0]));w.writeheader();w.writerows(base)
with (ROOT/'13批日期_本轮变更明细.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(changes[0]));w.writeheader();w.writerows(changes)
missing=[r for r in base if not r['publish_date_exact']]
assert len(base)==97 and len(changes)==13 and len(missing)==1 and missing[0]['batch']=='1'
summary={'baseline_exact_count':sum(bool(r['publish_date_exact']) for r in csv.DictReader(BASELINE.open(encoding='utf-8-sig'))),'new_registered_dates':13,'updated_exact_count':96,'ledger_rows':97,'remaining_exact_missing':[{'system':r['system'],'batch':r['batch'],'known_lower':r['public_date_lower_bound'],'known_upper':r['public_date_upper_bound'],'source_url':r['source_url']} for r in missing],'first_online_time_not_verified_for_all_sources':True,'independent_model_state_or_parameter_recompute_in_this_script':False,'publication_metadata_conflict_retained':True,'accepted_date_file_rows':len(records)}
(ROOT/'date_completion_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
