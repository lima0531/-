#!/usr/bin/env python3
"""Bind historical withdrawal SHA to literal cached official attachment links.

Page date extraction is independent of prior date CSV values. URLs from
request receipts/recorded date evidence are used only as locators. Registration
date is a current official page observation, never a certified first-online
timestamp or legal effective date. The input is never changed.
"""
import csv,hashlib,html,json,re
from collections import defaultdict
from pathlib import Path
from urllib.parse import urljoin,urlparse
import collect_official_originals as base

ROOT=base.ROOT;DATES=ROOT.parent/'dates';INPUT=base.INPUT
OLD=list(csv.DictReader((INPUT/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv').open(encoding='utf-8-sig')))
GROUP=defaultdict(list)
for r in OLD:GROUP[r['原件SHA256']].append(r)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def clean(s):return html.unescape(re.sub('<[^>]+>',' ',s)).strip()
def match(pattern,s):
    m=re.search(pattern,s,re.S|re.I);return clean(m.group(1)) if m else ''
def datevalue(s):
    m=re.search(r'(20\d{2})[-年]\s*(\d{1,2})[-月]\s*(\d{1,2})',s)
    return f'{int(m[1]):04}-{int(m[2]):02}-{int(m[3]):02}' if m else ''
def cnnum(s):
    n={'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'零':0}
    if s.isdigit():return s
    if '十' in s:
        a,b=s.split('十');return str((n.get(a,1) if a else 1)*10+(n.get(b,0) if b else 0))
    return str(n.get(s,''))
def page_info(path,url):
    content=Path(path).read_text(encoding='utf-8',errors='replace')
    title=match(r'<meta\s+name=["\']ArticleTitle["\']\s+content=["\']([^"\']*)',content) or match(r'<title>(.*?)</title>',content)
    batch=match(r'免征车辆购置税的新能源汽车车型目录[》\s]*[（(]第([^）)]+?)批',title)
    signed=match(r'成文日期：</span>\s*<span[^>]*>(.*?)</span>',content)
    published=match(r'发布日期：</span>\s*<span[^>]*>(.*?)</span>',content)
    time=match(r'<span[^>]*id=["\']con_time["\'][^>]*>(.*?)</span>',content)
    if not time:time=match(r'发布时间：\s*<span[^>]*>(.*?)</span>',content) or match(r'发布时间：\s*(20\d{2}-\d{2}-\d{2}[^<\r\n]*)',content)
    meta=match(r'<meta\s+name=["\']PubDate["\']\s+content=["\']([^"\']*)',content)
    body_dates=re.findall(r'20\d{2}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日',clean(content))
    body_signed=datevalue(body_dates[-1]) if body_dates else ''
    evidence=[{'line':i,'raw':line.strip()} for i,line in enumerate(content.splitlines(),1) if '成文日期' in line or '发布日期' in line or 'id="con_time"' in line or 'name="PubDate"' in line]
    return {'page_url':url,'page_local_path':str(path),'page_sha256':sha(path),'page_title':title,'page_tax_batch':cnnum(batch),'page_is_primary_miit':urlparse(url).hostname=='www.miit.gov.cn','page_explicit_publish_date':datevalue(published),'page_visible_publish_time':time,'page_registered_public_date':datevalue(published or time),'page_explicit_signed_date':datevalue(signed),'page_body_signed_date':body_signed,'page_meta_pubdate':meta,'page_date_raw_evidence_json':json.dumps(evidence,ensure_ascii=False)},content

def main():
    # Establish cached page path<->URL locators without trusting extracted dates.
    paths={};urlbyfile={}
    for x in json.loads((ROOT/'page_manifest.json').read_text()):
        if x['status']=='ok':paths[x['requested_url']]=x['local_path'];urlbyfile[x['local_path']]=x['requested_url']
    for f in list((ROOT/'receipts').glob('*.json'))+list(DATES.glob('**/*.request.json'))+list((ROOT/'version_search').glob('*.request.json')):
        try:x=json.loads(f.read_text())
        except (ValueError,OSError):continue
        if isinstance(x,dict) and x.get('status')=='ok' and x.get('local_path') and str(x['local_path']).endswith('.html'):
            paths[x['requested_url']]=x['local_path'];urlbyfile[x['local_path']]=x['requested_url']
    for x in json.loads((DATES/'registered_date_evidence.json').read_text()):
        paths[x['source_url']]=x['evidence_file'];urlbyfile[x['evidence_file']]=x['source_url']
    extra=json.loads((DATES/'new_page_attachment_urls.json').read_text())
    for x in extra:
        if x.get('page_url'):paths[x['page_url']]=x['page_file'];urlbyfile[x['page_file']]=x['page_url']
    # This locator is present in cached official native search_batch27.json.
    u27='https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_316eeb2aad034a3bbe515fe8e95a27da.html'
    f27=str(DATES/'main_25_31/batch27_primary.html');paths[u27]=f27;urlbyfile[f27]=u27
    records=json.loads((ROOT/'attachment_manifest.json').read_text())
    records.extend(json.loads((ROOT/'withdrawal20_primary_binding_results.json').read_text()))
    records.extend(json.loads((ROOT/'version_search/handoff_attachments.json').read_text()))
    rows=[];seen=set()
    def append(target_sha,record,link,role):
        old=GROUP[target_sha][0];file=link.get('page_file')
        url=link.get('page_url') or urlbyfile.get(file)
        file=file or paths.get(url)
        if not url or not file or not Path(file).exists():return
        key=(target_sha,record.get('requested_url',''),url,role)
        if key in seen:return
        seen.add(key);info,content=page_info(file,url)
        original=record.get('requested_url','');anchor=link.get('page_link_url') or original
        literal=anchor.split('://',1)[-1].split('/',1)[-1] in content or urlparse(original).path in html.unescape(content)
        status=record.get('status');hash_exact=status=='ok' and record.get('sha256')==target_sha
        current_sha=record.get('sha256','')
        if record.get('local_path') and Path(record['local_path']).exists() and sha(record['local_path'])!=current_sha:raise ValueError('Attachment hash has changed')
        row={'historical_file':old['原件文件'],'historical_target_sha256':target_sha,'historical_semantic_rows':len(GROUP[target_sha]),'old_attributed_batch':old['撤销公告批次'],'old_observation_date':old['撤销观察日'],'old_signed_date':old['signed_date'],'binding_role':role,'attachment_url':original,'attachment_current_sha256':current_sha,'attachment_is_target_sha':hash_exact,'literal_page_attachment_link_verified':literal}
        row.update(info);row.update(old_batch_matches_page=old['撤销公告批次']==info['page_tax_batch'],old_observation_matches_page_registered=old['撤销观察日']==info['page_registered_public_date'],old_signed_matches_page=(old['signed_date']==(info['page_explicit_signed_date'] or info['page_body_signed_date'])),historical_first_online_verified=False,legal_effective_date_verified=False)
        rows.append(row)
    for rec in records:
        if rec.get('status')!='ok':continue
        h=rec.get('sha256')
        if h in GROUP:
            for link in rec.get('links',[]):append(h,rec,link,'target_sha_exact_current_page_binding')
    h26='f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544'
    for rec in records:
        if rec.get('status')=='ok' and rec.get('sha256')=='ee9325e79d91945e2e22986ebc4cb7894634e21f3be04611ab38942c799eebe7':
            for link in rec.get('links',[]):append(h26,rec,link,'different_sha_current_official_version_324_rows_and_three_fields_compared')
    h27='c388317a1453e6b139a2a67bd21e4b5818d6711b0982feb55626f0ac886783ff'
    for rec in records:
        if rec.get('status')!='ok' or rec.get('sha256')==h27:continue
        for link in rec.get('links',[]):
            if link.get('page_file')==f27 and '撤销' in link.get('label',''):append(h27,rec,link,'related_batch27_announcement_attachment_different_sha')
    # Preserve, but explicitly reject, the old batch32 page association.
    u32=GROUP[h27][0]['publish_date_source_url'];info,content=page_info(paths[u32],u32)
    old=GROUP[h27][0];row={'historical_file':old['原件文件'],'historical_target_sha256':h27,'historical_semantic_rows':len(GROUP[h27]),'old_attributed_batch':old['撤销公告批次'],'old_observation_date':old['撤销观察日'],'old_signed_date':old['signed_date'],'binding_role':'legacy_batch32_attribution_unbound_no_withdrawal_attachment','attachment_url':'','attachment_current_sha256':'','attachment_is_target_sha':False,'literal_page_attachment_link_verified':False};row.update(info);row.update(old_batch_matches_page=True,old_observation_matches_page_registered=True,old_signed_matches_page=True,historical_first_online_verified=False,legal_effective_date_verified=False);rows.append(row)
    rows.sort(key=lambda r:(r['historical_file'],r['binding_role'],r['page_url']))
    with (ROOT/'historic_withdrawal_date_source_audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summarized=[]
    for h,oldrows in GROUP.items():
        relevant=[r for r in rows if r['historical_target_sha256']==h and r['page_is_primary_miit'] and r['literal_page_attachment_link_verified']]
        exact=[r for r in relevant if r['attachment_is_target_sha']]
        choices=exact or [r for r in relevant if r['binding_role'].startswith('different_sha_current_official_version')]
        batches=sorted({r['page_tax_batch'] for r in choices});pubs=sorted({r['page_registered_public_date'] for r in choices if r['page_registered_public_date']});signed=sorted({r['page_explicit_signed_date'] or r['page_body_signed_date'] for r in choices if r['page_explicit_signed_date'] or r['page_body_signed_date']})
        old=oldrows[0]
        summarized.append({'historical_file':old['原件文件'],'target_sha256':h,'rows':len(oldrows),'old_batch':old['撤销公告批次'],'old_public_observation_date':old['撤销观察日'],'old_signed_date':old['signed_date'],'verified_primary_batches':batches,'verified_primary_registered_dates_exact_sha':sorted({r['page_registered_public_date'] for r in exact}),'verified_primary_registered_dates_current_semantic_alternative':pubs if not exact else [],'verified_signed_dates':signed,'batch_change_required':bool(batches) and old['撤销公告批次'] not in batches,'observation_date_change_required':bool(pubs) and old['撤销观察日'] not in pubs,'signed_date_change_required':bool(signed) and old['signed_date'] not in signed,'original_sha_recovered':bool(exact),'historical_first_online_verified':False,'legal_effective_date_verified':False})
    summary={'historical_sources':9,'sha_exact_sources_with_primary_page_binding':sum(x['original_sha_recovered'] for x in summarized),'primary_semantic_alternative_sources':sum(bool(x['verified_primary_registered_dates_current_semantic_alternative']) for x in summarized),'sources_requiring_observation_date_revision':sum(x['observation_date_change_required'] for x in summarized),'sources_requiring_batch_revision':sum(x['batch_change_required'] for x in summarized),'sources_requiring_signed_date_revision':sum(x['signed_date_change_required'] for x in summarized),'date_evidence_rows':len(rows),'results':summarized}
    (ROOT/'historic_withdrawal_date_source_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
