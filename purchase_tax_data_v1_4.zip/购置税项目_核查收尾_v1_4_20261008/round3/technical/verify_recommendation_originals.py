import pathlib,csv,json,hashlib,unicodedata,fitz,collections
OUT=pathlib.Path(__file__).parent
INPUT=pathlib.Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
rows=list(csv.DictReader((INPUT/'推荐参数/推荐参数_配置版本长表.csv').open(encoding='utf-8-sig')))
def norm(s):return ''.join(unicodedata.normalize('NFKC',s or '').split())
fields=[k[:-len('_source_location')] for k in rows[0] if k.endswith('_source_location')]
docs={sid:fitz.open(OUT/(sid+'_original.pdf')) for sid in {r['source_id'] for r in rows}}
summary={'source_count':len(docs),'configuration_versions':len(rows),'distinct_configuration_ids':len({r['config_id'] for r in rows}),'geometry_or_page_boundary_resolutions':[],'discrepancies':[],'fields_verified':0,'nonempty_fields_verified':0,'source_hashes':[]}
for sid,doc in docs.items():
 b=(OUT/(sid+'_original.pdf')).read_bytes();actual=hashlib.sha256(b).hexdigest();expected={r['source_sha256'] for r in rows if r['source_id']==sid};ok=expected=={actual}
 summary['source_hashes'].append({'source_id':sid,'expected_sha256':list(expected),'actual_sha256':actual,'bytes':len(b),'pages':len(doc),'match':ok})
 assert ok
extracted=[]
page_texts={}
textpages={}
for row in rows:
 doc=docs[row['source_id']];page=doc[int(row['page_first_1based'])-1];page_key=(row['source_id'],int(row['page_first_1based']))
 if page_key not in page_texts:page_texts[page_key]=norm(page.get_text())
 page_text=page_texts[page_key]
 hdr_ok=norm(row['heading_raw']) in page_text;cfg_ok=norm(row['config_header_raw']) in page_text
 if not hdr_ok and int(row['page_first_1based'])>1:
  prev_key=(row['source_id'],int(row['page_first_1based'])-1)
  if prev_key not in page_texts:page_texts[prev_key]=norm(doc[prev_key[1]-1].get_text())
  if norm(row['heading_raw']) in page_texts[prev_key]+page_text:
   hdr_ok=True;summary['geometry_or_page_boundary_resolutions'].append({'observation_version_key':row['observation_version_key'],'field':'heading','reason':'heading_on_previous_page_or_split_across_pages','heading_page_1based':prev_key[1],'configuration_table_page_1based':page_key[1]})
 if not(hdr_ok and cfg_ok):summary['discrepancies'].append({'observation_version_key':row['observation_version_key'],'field':'heading_or_config','heading_present':hdr_ok,'config_present':cfg_ok})
 for field in fields:
  locraw=row[field+'_source_location'];raw=row.get(field+'_raw','')
  if not locraw:
   if raw:summary['discrepancies'].append({'observation_version_key':row['observation_version_key'],'field':field,'expected':raw,'actual':'','reason':'missing_location'})
   continue
  loc=json.loads(locraw);bb=json.loads(loc['value_bbox']);pg=doc[loc['page_1based']-1];pk=(row['source_id'],loc['page_1based'])
  if pk not in textpages:textpages[pk]=pg.get_textpage()
  actual=textpages[pk].extractTextbox(fitz.Rect(*bb));ok=norm(actual)==norm(raw)
  extraction_method='PDF text rectangle'
  if not ok:
   # Rectangle intersection includes overhanging glyphs from adjacent cells.
   # Use character centres, the same geometric rule for every mismatch.
   lines=[]
   for block in pg.get_text('rawdict')['blocks']:
    for line in block.get('lines',[]):
     chars=[]
     for span in line['spans']:
      for char in span['chars']:
       x0,y0,x1,y1=char['bbox'];cx=(x0+x1)/2;cy=(y0+y1)/2
       if bb[0]<=cx<=bb[2] and bb[1]<=cy<=bb[3]:chars.append(char['c'])
     if chars:lines.append(''.join(chars))
   centered='\n'.join(lines)
   if norm(centered)==norm(raw):
    summary['geometry_or_page_boundary_resolutions'].append({'observation_version_key':row['observation_version_key'],'field':field,'reason':'neighbour_cell_glyph_intersects_clip_but_character_centre_outside','rectangle_text':actual.strip(),'character_centre_text':centered,'bbox':bb})
    actual=centered;ok=True;extraction_method='PDF character centre within rectangle'
  extracted.append({'observation_version_key':row['observation_version_key'],'source_id':row['source_id'],'model_key':row['model_key'],'config_id':row['config_id'],'field':field,'page_1based':loc['page_1based'],'value_bbox':json.dumps(bb),'retained_raw':raw,'original_extracted_raw':actual.strip(),'extraction_method':extraction_method,'normalized_equal':int(ok),'source_sha256':row['source_sha256']})
  if ok:summary['fields_verified']+=1;summary['nonempty_fields_verified']+=bool(raw)
  else:summary['discrepancies'].append(extracted[-1])
summary['discrepancy_count']=len(summary['discrepancies']);summary['all_285_headings_and_config_ids_present']=all(not d.get('field')=='heading_or_config' for d in summary['discrepancies'])
summary['reconstruction_scope']='Existing retained PDF cell coordinates were re-read from byte-identical official originals; this verifies retained field transcription, not exhaustive extraction of every product in the PDFs, same configuration across tax and recommendation catalogues, test compliance, or exemption eligibility.'
(OUT/'recommendation_original_verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (OUT/'推荐285配置_官方原件逐字段对账.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(extracted[0]));writer.writeheader();writer.writerows(extracted)
print(json.dumps({k:v for k,v in summary.items() if k not in ['discrepancies']},ensure_ascii=False,indent=2))
if summary['discrepancies']:print(json.dumps(summary['discrepancies'][:15],ensure_ascii=False,indent=2))
