#!/usr/bin/env python3
"""Side-table audit: conservative interval screens, never frozen-point backfills."""
import csv, hashlib, json, sys
from collections import Counter
from decimal import Decimal as D
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'round3/reconstruction/data_v1_3'
OUT = ROOT / 'parameters'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT.parent / 'round3/archive'))
from word_piece_text import extract

def read(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def write(p, rows):
    with p.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)

def screen(lo, hi, threshold):
    if not lo or not hi: return '无可用区间'
    assert D(lo) <= D(hi)
    if D(hi) < threshold: return '全部低于阈值'
    if D(lo) >= threshold: return '全部达到阈值'
    return '区间跨越阈值'

params = {r['record_id']: r for r in read(BASE/'研究数据/参数版本_原值与计算代理.csv')}
frozen = {r['model_key']: r for r in read(BASE/'研究数据/重建样本_两截点参数与暴露.csv') if r['cutoff']=='2023-12-10'}
layers = read(BASE/'官方技术清单/五档数值层_逐型号归属与判据.csv')
sources = {r['source_sha256']: r for r in read(ROOT.parent/'round3/archive/106原件公开回收清单.csv')}
evidence = []
for rid, field, raw, literal, lo, hi in [
    ('old-51-Word97--0-11', 'battery_mass', '138/磷酸铁锂蓄电池', '唯一质量数值138；斜线后为化学类型注释', '138', '138'),
    ('old-57-Word97--0-27', 'range', '650(CLTC)/616(CLTC)/616CLTC)', '三个列出值650、616、616；保留多值；括号印刷缺失', '616', '650')]:
    r = params[rid]
    assert r[field+'_raw'] == raw
    path = Path(sources[r['source_sha256']]['recovered_path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == r['source_sha256']
    text, proof = extract(path)
    at = text.index(r['model_raw'])
    snippet = text[at:at+220]
    assert raw in snippet
    evidence.append(dict(record_id=rid, model_key=r['model_key'], field=field, original_raw=raw,
        source_file=r['source_file'], source_sha256=r['source_sha256'], source_location=r['source_location'],
        verified_source_snippet=snippet, interpretation=literal, verified_lower=lo, verified_upper=hi,
        frozen_point_updated='0', configuration_identity_certified='0'))
write(OUT/'2条原件注释与排版_解析补充证据.csv', evidence)
verified = {(r['record_id'], r['field']):r for r in evidence}

rows=[]
for l in layers:
    if l['numeric_input_ready']=='1': continue
    f = frozen[l['model_key']]
    ids = f['possible_latest_record_ids'].split('|')
    assert len(ids)==1 and f['all_possible_latest_observed_before_cutoff']=='1'
    r=params[ids[0]]
    rl,ru,dl,du = (f[k] for k in ['range_lower','range_upper','density_proxy_lower','density_proxy_upper'])
    overlay=''
    if (r['record_id'],'range') in verified:
        v=verified[(r['record_id'],'range')]; rl,ru=v['verified_lower'],v['verified_upper'];overlay='原件多值排版解析补充'
    if (r['record_id'],'battery_mass') in verified:
        v=verified[(r['record_id'],'battery_mass')]
        dl=str(D(r['battery_energy_lower'])*1000/D(v['verified_upper']))
        du=str(D(r['battery_energy_upper'])*1000/D(v['verified_lower']))
        overlay='原件质量注释解析补充'
    rs,ds=screen(rl,ru,D(200)),screen(dl,du,D(125))
    if rs==ds=='全部达到阈值': combined='两项数值在整个外包络均达到常规阈值'
    elif '全部低于阈值' in (rs,ds): combined='至少一项数值在整个外包络低于常规阈值'
    elif '无可用区间' in (rs,ds): combined='缺少可用原始字段/更正范围证据'
    else: combined='区间跨越阈值，具体配置仍待匹配'
    if '无可用区间' in (rs,ds): reason='原件空格或局部更正范围待核'
    elif overlay: reason='公开原件已有可识别数值，解析补充完成'
    elif any('tolerance' in r[k+'_parse_status_new'] for k in ['range','battery_mass','battery_energy']): reason='公差区间（可能同时含多配置）；原值已经取得'
    elif any(r[k+'_parse_status_new']=='multi' for k in ['range','battery_mass','battery_energy']): reason='多个数值/配置选项；原值已经取得'
    else: reason='数值附注；原值已经取得，冻结主表保留原点估计口径'
    rows.append(dict(model_key=l['model_key'],cutoff='2023-12-10',record_id=r['record_id'],source_file=r['source_file'],
        source_sha256=r['source_sha256'],source_location=r['source_location'],range_raw=r['range_raw'],
        battery_mass_raw=r['battery_mass_raw'],battery_energy_raw=r['battery_energy_raw'],
        range_parse_status=r['range_parse_status_new'],battery_mass_parse_status=r['battery_mass_parse_status_new'],
        battery_energy_parse_status=r['battery_energy_parse_status_new'],insufficiency_type=reason,
        range_lower=rl,range_upper=ru,density_proxy_lower=dl,density_proxy_upper=du,
        range_interval_screen=rs,density_interval_screen=ds,two_parameter_interval_screen=combined,
        both_parameter_threshold_results_determined=str(int(all(s in ['全部达到阈值','全部低于阈值'] for s in [rs,ds]))),
        public_parse_evidence_overlay=overlay,frozen_numeric_ready_original='0',frozen_point_updated='0',
        full_technical_conformity_certified='0',configuration_identity_certified='0',
        note='保守外包络不配对斜线选项；仅两项数值筛查；密度为目录能量/质量代理，非推荐目录声明值'))
assert len(rows)==381
write(OUT/'381单值不足_原因与保守区间核查.csv',rows)
summary=dict(rows=len(rows),two_parameter_threshold_results_determined=sum(r['both_parameter_threshold_results_determined']=='1' for r in rows),
    interval_screen_counts=dict(Counter(r['two_parameter_interval_screen'] for r in rows)),
    reason_counts=dict(Counter(r['insufficiency_type'] for r in rows)),
    genuine_source_or_correction_evidence_gaps=[r['model_key'] for r in rows if '无可用区间' in (r['range_interval_screen'],r['density_interval_screen'])],
    public_annotation_parse_supplements=2,frozen_numeric_ready_models_unchanged=2424,
    source_bytes_hash_verified_for_supplements=True,scope='2023-12-10已在册风险集；冻结单值不回填，旁表只给保守区间判断；不认证同配置、低温或全部技术要求')
(OUT/'interval_audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
