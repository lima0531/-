#!/usr/bin/env python3
"""Apply reviewed metadata repairs; keep scientific values and prior version immutable."""
import csv, hashlib, json, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'round3/reconstruction/data_v1_3'
OUT=ROOT/'data_v1_4'

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);return r.fieldnames,list(r)

def write(p,fields,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

if OUT.exists(): shutil.rmtree(OUT)
shutil.copytree(BASE,OUT)
sem=Path('目录覆盖/正式历史撤销_语义记录修正版3007行.csv')
shutil.copyfile(ROOT/'withdrawals/正式历史撤销_全表核查修正版3007行.csv',OUT/sem)
pf=Path('研究数据/参数版本_原值与计算代理.csv')
fields,rows=read(OUT/pf)
target=[r for r in rows if r['record_id']=='old-40-Word97-correction--8-2']
assert len(target)==1 and target[0]['model_key']=='JX6570T-M5BEV' and target[0]['trade_name_raw']==''
target[0]['trade_name_raw']='特顺EV'
write(OUT/pf,fields,rows)
companions=[
 ('parameters/381单值不足_原因与保守区间核查.csv','数值补充核查/381单值不足_原因与保守区间核查.csv'),
 ('parameters/2条原件注释与排版_解析补充证据.csv','数值补充核查/2条原件注释与排版_解析补充证据.csv'),
 ('catalogues/名称元数据_证据覆盖候选层.csv','勘误补充/名称更正_带观察日期证据表.csv'),
 ('recommendation_interval/29配置版本_四技术条件保守外包络核查.csv','数值补充核查/29推荐配置版本_四技术条件保守外包络核查.csv'),
]
for a,b in companions:
    dest=OUT/b;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/a,dest)
fields,inventory=read(ROOT.parent/'round3/archive/106原件公开回收清单.csv')
meta=json.loads((ROOT/'public_gaps/batch26_tax_attachments.json').read_text())
urls={}
def visit(x):
    if isinstance(x,dict):
        for k,v in x.items():
            if isinstance(v,str) and v.startswith('http'):urls[k]=v
            visit(v)
    elif isinstance(x,list):
        for v in x:visit(v)
visit(meta)
for r in inventory:
    if r['source_file']=='mf_batch26.docx': path=ROOT/'public_gaps/batch26_tax_catalogue.docx'
    elif r['source_sha256']=='f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544':path=ROOT/'public_gaps/batch26_tax_withdrawal.docx'
    else:continue
    assert sha(path)==r['source_sha256'] and path.stat().st_size==int(r['source_bytes'])
    r.update(recovery_status='sha256_exact',recovered_path=str(path),recovered_sha256=sha(path),recovered_bytes=str(path.stat().st_size))
    receipt=json.loads(path.with_suffix(path.suffix+'.receipt.json').read_text())
    r['download_url']=receipt.get('url',receipt.get('requested_url',r['download_url']))
assert sum(r['recovery_status']=='sha256_exact' for r in inventory)==104
dest=OUT/'原件回收登记/106原件公开回收清单_v1_4.csv';dest.parent.mkdir(exist_ok=True);write(dest,fields,inventory)

checks=[]
def check(name,ok,detail=''):
    checks.append(dict(check=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
oldfields,oldrows=read(BASE/pf)
check('7203参数记录仅补1条同原件名称',len(rows)==len(oldrows)==7203 and sum(a!=b for a,b in zip(oldrows,rows))==1)
check('全部7203科学参数及日期与冻结点原样保留',all({k:v for k,v in a.items() if k!='trade_name_raw'}=={k:v for k,v in b.items() if k!='trade_name_raw'} for a,b in zip(oldrows,rows)))
_,oldsem=read(BASE/sem);_,newsem=read(OUT/sem)
check('历史撤销3007成员及事件日期原样保留',len(newsem)==len(oldsem)==3007 and all(all(a[k]==b[k] for k in ['model_key','撤销公告批次','撤销事件日','原列入批次','在研究总体内']) for a,b in zip(oldsem,newsem)))
changed=[]
for f in BASE.rglob('*'):
    if not f.is_file() or f.name=='文件清单_SHA256.txt':continue
    rel=f.relative_to(BASE)
    if sha(f)!=sha(OUT/rel):changed.append(str(rel))
check('除两张元数据表外其余既有文件逐字节不变',set(changed)=={str(pf),str(sem)},changed)
verified=0
for r in inventory:
    if r['recovery_status']!='sha256_exact':continue
    path=Path(r['recovered_path'])
    check('原件SHA:'+r['source_file'],sha(path)==r['source_sha256'] and path.stat().st_size==int(r['source_bytes']))
    verified+=1
check('104份历史原件全部核SHA',verified==104)

(OUT/'README.md').write_text('''# 数据 v1.4：核查收尾与材料边界

v1.4 继承 v1.3 科学口径：3328 型号；2023-12-10 在册风险集 2805，冻结单值可用 2424、单值不足 381；2024撤销观察503（风险集496、风险集外7）。参数原值、资格事件、成员、月度状态及冻结暴露未改。

本次仅修复历史撤销2处文字内容和225处企业文字来源标注，增加原件本格原值/定位；补齐 JX6570T-M5BEV 已有完整勘误记录的“特顺EV”名称。2024-07-09五条公开名称更正单列带观察日期的伴随表，不回写当时原文、不提前进入2023信息集。

数值补充核查是独立旁表，含381型号的保守外包络与2条经原件核实的注释/排版解析。343型号的两项阈值结果已确定；全体381中300的两项全外包络达到、47至少一项全外包络低于、32仍跨阈值未知、2待原字段/勘误范围证据。它不替换冻结单值，不认证同配置、全部技术要求或低温例外。

推荐端另29个缺单值配置版本的145字段已完成严格字符串解析和四条件外包络旁表：28版本所有列出选项数值达到、1版本未达、0版本仍跨界；不改原推荐单值字段，也不认证配置身份或税收资格。

原件回收登记为104/106同历史字节（95/97目录、9/9历史撤销）；2份缺件的精确提取路径见round4/requirements。既有文件名中2877/8等旧计数来自历史名称，不表示v1.4行数；使用不带旧计数的规范同名表及本文口径。其他字段定义继承《字段说明_版本边界.md》。
''',encoding='utf-8')
# README intentionally revised after the byte-comparison above.
files=[f for f in OUT.rglob('*') if f.is_file() and f.name!='文件清单_SHA256.txt']
(OUT/'文件清单_SHA256.txt').write_text(''.join(sha(f)+'  '+str(f.relative_to(OUT))+'\n' for f in sorted(files)),encoding='utf-8')
result=dict(dataset='v1.4',data_files=len(files),checks=len(checks),failures=sum(not x['passed'] for x in checks),
    checks_detail=checks,existing_table_changes=changed,scientific_values_changed=0,metadata_name_cell_repairs=1,
    withdrawal_content_repairs=2,withdrawal_provenance_labels_refined=225,historical_originals_sha_verified=verified)
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/v1_4_delta_and_sources.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks_detail'},ensure_ascii=False))
