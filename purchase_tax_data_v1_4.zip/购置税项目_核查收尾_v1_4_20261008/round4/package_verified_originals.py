#!/usr/bin/env python3
import csv,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
TASK=ROOT.parent
TARGET=Path('/workspace/购置税项目_公开原件104份及推荐资料_v1_4_20261008.zip')
PREFIX='购置税项目_核查收尾_v1_4_20261008'
files={}
with (ROOT/'data_v1_4/原件回收登记/106原件公开回收清单_v1_4.csv').open(encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        if r['recovery_status']!='sha256_exact':continue
        p=Path(r['recovered_path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==r['source_sha256']
        files[str(p.relative_to(TASK))]=p
assert len(files)==104
for p in (TASK/'round3/technical').glob('rec*_original.pdf'):files[str(p.relative_to(TASK))]=p
for name in ['batch26_7368842.wps','batch26_7368844.docx']:
    p=TASK/'round3/archive/version_search'/name;files[str(p.relative_to(TASK))]=p
assert len(files)==109
manifest=[dict(relative_path=rel,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for rel,p in sorted(files.items())]
with zipfile.ZipFile(TARGET,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for rel,p in sorted(files.items()):z.write(p,f'{PREFIX}/{rel}')
    z.writestr(f'{PREFIX}/原件包_SHA256.txt',''.join(r['sha256']+'  '+r['relative_path']+'\n' for r in manifest))
    z.writestr(f'{PREFIX}/原件包使用说明.txt','104份历史同SHA原件（95目录+9撤销）、3份推荐PDF和2份第26批官方异字节版本。\n与核查收尾主包解压到同一父目录，合并同名文件夹即可；不覆盖任何不同字节文件。\n第1批PDF与第64批DOC仍待从已有完整归档提取，本包不包含这两份。\n')
with zipfile.ZipFile(TARGET) as z:
    assert z.testzip() is None
    for r in manifest:
        b=z.read(f"{PREFIX}/{r['relative_path']}");assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
assert TARGET.stat().st_size<32*1024*1024
with (ROOT/'原件分包索引_v1_4.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(manifest[0]));w.writeheader();w.writerows(manifest)
result=dict(path=str(TARGET),bytes=TARGET.stat().st_size,sha256=hashlib.sha256(TARGET.read_bytes()).hexdigest(),
    historical_exact_originals=104,recommendation_pdfs=3,official_alternate_byte_versions=2,
    source_files=109,all_members_crc_and_sha_verified=True)
(ROOT/'original_package_result_v1_4.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
