import urllib.request,urllib.parse,urllib.error,json,hashlib,datetime,re,pathlib,concurrent.futures
from html.parser import HTMLParser
OUT=pathlib.Path(__file__).parent
HEADERS={'User-Agent':'Mozilla/5.0','Referer':'https://www.miit.gov.cn/search/'}
def fetch(name,url,suffix='.html'):
 target=OUT/(name+suffix); receipt=OUT/(name+'_request.json')
 if target.exists() and receipt.exists():
  rec=json.loads(receipt.read_text());
  if rec.get('status')==200:return target.read_bytes()
 rec={'url':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls_verification':True}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers=HEADERS),timeout=35) as r:
   data=r.read();rec.update(status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type'),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());target.write_bytes(data)
 except urllib.error.HTTPError as e:rec.update(error=str(e),status=e.code);data=b''
 except Exception as e:rec.update(error=str(e));data=b''
 receipt.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n');print(name,rec,flush=True);return data
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.current=None
 def handle_starttag(self,tag,attrs):
  if tag=='a':self.current=[dict(attrs).get('href',''),'']
 def handle_data(self,s):
  if self.current:self.current[1]+=s
 def handle_endtag(self,tag):
  if tag=='a' and self.current:self.links.append(self.current);self.current=None

def search(name,q,cateid='47',pos=None,begin='',end=''):
 params=dict(websiteid='110000000000000',scope='basic',q=q,pg='40',p='1',cateid=cateid,pos='title_text,titlepy,infocontent,filenumbername,keyword,contentdescribe',pq='',oq='',eq='',begin='',end='',dateField='deploytime',selectFields='title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode',group='distinct',highlightConfigs='[{"field":"infocontent","numberOfFragments":2,"fragmentOffset":0,"fragmentSize":110,"noMatchSize":110}]',highlightFields='title_text,infocontent,webid',level='6',sortFields='[{"name":"deploytime","type":"desc"}]',hidCol='fbafd13557fa453d9c59432567d2b150')
 if pos:params['pos']=pos
 params['begin']=begin;params['end']=end
 raw=fetch(name,'https://www.miit.gov.cn/search-front-server/api/search/info?'+urllib.parse.urlencode(params),'.json')
 if not raw:return []
 j=json.loads(raw);found=[]
 def walk(x):
  if isinstance(x,dict):
   if 'title' in x and 'url' in x:found.append(x)
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(j.get('data',{}).get('searchResult',{}).get('dataResults'))
 print(name,[(x['title'],x['url']) for x in found],flush=True)
 (OUT/(name+'_hits.json')).write_text(json.dumps(found,ensure_ascii=False,indent=2))
 return found

if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  list(ex.map(lambda x:fetch(*x),[
   ('rec2020_04_original','https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit/n1146285/n1146352/n3054355/n3057585/n3057590/c7844163/part/7844179.pdf','.pdf'),
   ('rec2022_04_original','https://www.miit.gov.cn/cms_files/filemanager/1226211233/attach/20224/c7ccd1f2b217441691a67b2e983c2fdb.pdf','.pdf'),
   ('rec2020_04_announcement','https://www.miit.gov.cn/jgsj/zbys/wjfb/art/2020/art_d9806d4577ba4c9ab9a584c1e53f091e.html','.html')]))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  list(ex.map(lambda x:search(*x),[
   ('rec2022_12_search_v2','推荐车型目录 2022年第12批'),
   ('policy32_search_v2','调整减免车辆购置税新能源汽车产品技术要求'),
   ('policy10_search_v2','延续和优化新能源汽车车辆购置税减免政策')]))
