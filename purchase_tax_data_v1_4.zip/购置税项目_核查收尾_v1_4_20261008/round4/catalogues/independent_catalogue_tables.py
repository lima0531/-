#!/usr/bin/env python3
"""Independent source-header enumeration of BEV passenger catalogue rows.
Never loads expected model list during extraction. Only after all source rows
are materialized does it compare model multisets and source raw parameters.
"""
from pathlib import Path
import csv,hashlib,json,re,sys,unicodedata,zipfile,xml.etree.ElementTree as ET
from collections import Counter,defaultdict
import fitz
ROOT=Path('/workspace/purchase_tax_audit');R3=ROOT/'round3';OUT=ROOT/'round4/catalogues'
sys.path.insert(0,str(R3/'archive'))
from word_piece_text import extract as word_text
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def norm(s): return re.sub(r'\s+','',unicodedata.normalize('NFKC',s or ''))
def key(s): return norm(s).upper()
def read_csv(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write_csv(p,rows,fields=None):
 if fields is None:fields=list(rows[0]) if rows else []
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
def headers(cells):
 n=[norm(c) for c in cells];out={}
 for i,s in enumerate(n):
  if s=='车辆型号':out['model_raw']=i
  elif s=='序号':out['sequence_raw']=i
  elif '生产企业名称' in s or s=='企业名称':out['firm_raw']=i
  elif s=='通用名称':out['trade_name_raw']=i
  elif s=='产品名称':out['product_name_raw']=i
  elif '纯电动' in s and ('续驶里程' in s or '行驶里程' in s):out['range_raw']=i
  elif '整' in s and '整备质量' in s:out['curb_mass_raw']=i
  elif '蓄电池' in s and '总质量' in s:out['battery_mass_raw']=i
  elif '蓄电池' in s and '总能量' in s:out['battery_energy_raw']=i
  elif s=='备注':out['remarks_raw']=i
  elif '目录' in s and '批次' in s:out['catalogue_batch_marked_raw']=i
 return out
REQUIRED={'model_raw','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw'}
def row_dict(cells,h,kind,where):
 row={k:(cells[i] or '').strip() if i<len(cells) else '' for k,i in h.items()}
 row['model_key']=key(row['model_raw']);row['kind']=kind;row['location']=where
 if not row['model_key'] or not re.search('[A-Z]',row['model_key']):raise ValueError('Model cell lacks a product model at '+where+': '+repr(row['model_raw']))
 for f in ['firm_raw','trade_name_raw','product_name_raw','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw','catalogue_batch_marked_raw','sequence_raw']:row.setdefault(f,'')
 return row

def kind_before(t,pos):
 pre=t[:pos]
 parts=list(re.finditer(r'第二部分\s*重新申报[^\n]*|(?:^|\n)\s*重新申报后符合新技术要求的车型[^\n]*',pre))
 if not parts:return '完整表格勘误' if re.search(r'勘\s*误',pre) else '目录列入'
 return '重申报汇总' if '汇总' in parts[-1].group() else '重新申报列入'

def cfb_rows(path):
 t,proof=word_text(path);out=[];tables=[]
 # A BEV section begins at its standalone power heading, not a product name.
 starts=list(re.finditer(r'(?:^|\n)\s*(?:[一二三四五六七八九十]+[、.．]\s*)?纯电动汽车\s*\n',t))
 for si,m in enumerate(starts):
  stop=starts[si+1].start() if si+1<len(starts) else len(t)
  part=t[m.end():stop]
  ph=re.match(r'\s*(?:[（(]\s*一\s*[)）]\s*)?乘用车\s*\n',part)
  if not ph:continue
  start=m.end()+ph.end()
  # Stop at the next standalone vehicle class/power heading.
  eh=re.search(r'(?:^|[\n\t])\s*(?P<heading>(?:(?:[（(]\s*[二三四五六]+\s*[)）]|[一二三四五六]+[、.．])\s*)?(?:客车|货车|专用车|插电式混合动力汽车|燃料电池汽车))\s*\n',t[start:stop])
  end=start+eh.start('heading') if eh else stop
  cells=t[start:end].split('\t');h=headers(cells[:20])
  if not REQUIRED<=h.keys():raise ValueError('BEV passenger table header incomplete')
  width=h['remarks_raw']+1;stride=width+1
  if cells[width].strip():raise ValueError('Word row-end cell marker not empty after table header')
  i=stride;kind=kind_before(t,start);count=0;repeat=0
  while i+width<=len(cells):
   block=cells[i:i+width];hnew=headers(block)
   if REQUIRED<=hnew.keys():
    if hnew!=h:raise ValueError('Repeated header layout changed')
    repeat+=1;i+=stride;continue
   if all(not x.strip() for x in block):break
   row=row_dict(block,h,kind,f'CFB CLX; section_char={start}; row_start_cell={i}; stride={stride}')
   out.append(row);count+=1;i+=stride
  residue=''.join(cells[i:]).strip()
  if residue and not re.match(r'勘\s*误',residue):raise ValueError('Unconsumed data following table: '+repr(residue[:200]))
  tables.append({'start_char':start,'end_char':end,'column_count':width,'row_stride':stride,'data_rows':count,'repeated_headers':repeat,'kind':kind,'header_raw':cells[:width],'header_columns':h})
 if not tables:raise ValueError('No standalone BEV passenger table')
 return out,{'engine':'CFB bounded CLX cells plus source power/class headers; no expected model filter','tables':tables,'text_proof':proof}

def zip_rows(path):
 root=ET.fromstring(zipfile.ZipFile(path).read('word/document.xml'));out=[];tables=[];power='';cl='';kind='目录列入';ti=0
 for el in root.find('w:body',NS):
  if el.tag.endswith('}p'):
   text=''.join(x.text or '' for x in el.iterfind('.//w:t',NS));n=norm(text)
   if '重新申报后符合新技术要求的车型' in n:kind='重申报汇总' if '汇总' in n else '重新申报列入'
   if re.fullmatch(r'(?:[一二三四五六七八九十]+[、.．])?纯电动汽车',n):power='BEV'
   elif re.fullmatch(r'(?:[一二三四五六七八九十]+[、.．])?(?:插电式混合动力汽车|燃料电池汽车)',n):power='OTHER'
   if re.fullmatch(r'(?:[（(][一二三四五六七八九十]+[)）])?乘用车',n):cl='乘用车'
   elif re.fullmatch(r'(?:[（(][一二三四五六七八九十]+[)）])?(?:客车|货车|专用车)',n):cl='OTHER'
  elif el.tag.endswith('}tbl'):
   ti+=1
   if power!='BEV' or cl!='乘用车':continue
   allrows=[]
   for tr in el.findall('w:tr',NS):
    cs=[]
    for tc in tr.findall('w:tc',NS):
     cs.append('\n'.join(''.join(x.text or '' for x in p.iterfind('.//w:t',NS)) for p in tc.findall('w:p',NS)))
    allrows.append(cs)
   h=headers(allrows[0]);count=0
   if not REQUIRED<=h.keys():raise ValueError('DOCX header incomplete')
   for ri,cs in enumerate(allrows[1:],2):
    if REQUIRED<=headers(cs).keys():continue
    if not any(c.strip() for c in cs):continue
    if len(cs)!=len(allrows[0]):raise ValueError('DOCX row cell count changes')
    out.append(row_dict(cs,h,kind,f'OOXML table={ti};row_1based={ri}'));count+=1
   tables.append({'table':ti,'data_rows':count,'kind':kind,'header_raw':allrows[0],'header_columns':h})
 if not tables:raise ValueError('No DOCX BEV passenger table')
 return out,{'engine':'OOXML source-flow power/class headings and complete cell tables','tables':tables}

def pdf_rows(path):
 d=fitz.open(path);out=[];tables=[];begun=False;ended=False
 for pi,p in enumerate(d):
  if ended:break
  words=p.get_text('words');lines=defaultdict(list)
  for x0,y0,x1,y1,w,b,l,i in words:lines[(b,l)].append((x0,y0,x1,y1,w))
  headinglines=[]
  for v in lines.values():
   v.sort();s=''.join(x[4] for x in v);headinglines.append((min(x[1] for x in v),max(x[3] for x in v),norm(s)))
  lower=0;upper=p.rect.height
  if not begun:
   passenger=[z for z in headinglines if re.fullmatch(r'(?:\(?一\)?)?乘用车',z[2])]
   if not passenger:raise ValueError('PDF first BEV passenger heading not found on page '+str(pi+1))
   begun=True;lower=min(z[1] for z in passenger)
  stops=[z for z in headinglines if z[0]>lower and re.fullmatch(r'(?:\(?二\)?)?客车',z[2])]
  if stops:upper=min(z[0] for z in stops);ended=True
  for ti,tab in enumerate(p.find_tables().tables):
   if tab.bbox[1]<lower or tab.bbox[3]>upper:continue
   rows=tab.extract();h=headers(rows[0]);count=0
   if not REQUIRED<=h.keys():raise ValueError('PDF header incomplete p'+str(pi+1))
   for ri,cs in enumerate(rows[1:],2):
    if REQUIRED<=headers(cs).keys():continue
    if not any(norm(c) for c in cs):continue
    out.append(row_dict(cs,h,'目录列入',f'PDF geometric-grid;page={pi+1};table={ti};row={ri}'));count+=1
   tables.append({'page':pi+1,'table':ti,'bbox':list(tab.bbox),'data_rows':count,'header_raw':rows[0],'header_columns':h})
 if not ended:raise ValueError('PDF BEV passenger end heading missing')
 if not tables:raise ValueError('No PDF geometric passenger tables')
 return out,{'engine':'PyMuPDF ruled-grid geometry plus standalone class heading bounds','tables':tables}

def main():
 manifest=read_csv(R3/'archive/106原件公开回收清单.csv');rows=[];status=[];proofs={}
 for source in manifest:
  if source['source_file']=='mf_batch26.docx':
   additional=ROOT/'round4/public_gaps/batch26_tax_catalogue.docx'
   if additional.exists() and hashlib.sha256(additional.read_bytes()).hexdigest()==source['source_sha256']:
    source['recovery_status']='sha256_exact';source['recovered_path']=str(additional)
 for source in manifest:
  if source['scope']!='目录':continue
  name=source['source_file'];rec={'system':source['system'],'source_file':name,'source_sha256':source['source_sha256'],'recovery_status':source['recovery_status']}
  if source['recovery_status']!='sha256_exact':rec['status']='source_bytes_unavailable';rec['error']='';status.append(rec);continue
  p=Path(source['recovered_path']);b=p.read_bytes()
  if hashlib.sha256(b).hexdigest()!=source['source_sha256']:raise ValueError('Changed recovered source '+name)
  try:
   if b.startswith(b'PK'):got,proof=zip_rows(p)
   elif b.startswith(b'\xd0\xcf'):got,proof=cfb_rows(p)
   elif b.startswith(b'%PDF'):got,proof=pdf_rows(p)
   else:raise ValueError('Unsupported original signature')
   for x in got:x.update(source_file=name,system=source['system'],source_sha256=source['source_sha256'])
   rows.extend(got);rec.update(status='extracted',rows=len(got),engine=proof['engine'],error='');proofs[name]=proof
  except Exception as e:rec.update(status='extraction_issue',rows=0,engine='',error=str(e))
  status.append(rec);print(name,rec['status'],rec.get('rows',0),rec.get('error',''),flush=True)
 fields=['source_file','system','source_sha256','kind','model_raw','model_key','sequence_raw','firm_raw','trade_name_raw','product_name_raw','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw','catalogue_batch_marked_raw','location']
 write_csv(OUT/'独立原件_纯电动乘用车逐表参数.csv',rows,fields)
 write_csv(OUT/'逐源提取状态.csv',status,['system','source_file','source_sha256','recovery_status','status','rows','engine','error'])
 (OUT/'extraction_proofs.json').write_text(json.dumps(proofs,ensure_ascii=False,indent=2))
 # Comparison begins only after every extraction has finished.
 data=R3/'reconstruction/data_v1_3'
 expected=read_csv(data/'目录覆盖/原件逐表独立枚举.csv');params=read_csv(data/'研究数据/参数版本_原值与计算代理.csv')
 em=defaultdict(Counter);gm=defaultdict(Counter);pm=defaultdict(Counter);gr=defaultdict(Counter)
 for x in expected:
  if x['kind'] in ['目录列入','重新申报列入','重申报汇总']:em[x['source_file']][(x['kind'],x['model_key'])]+=1
 for x in rows:
  if x['kind']!='完整表格勘误':gm[x['source_file']][(x['kind'],x['model_key'])]+=1
 F=['model_key','kind','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw','trade_name_raw','product_name_raw','catalogue_batch_marked_raw','firm_raw']
 for x in params:
  if x['observation_kind'] not in ['目录列入','重新申报列入','重申报汇总','完整表格勘误']:continue
  n=Path(x['source_file']).name;y=dict(x,kind=x['observation_kind']);pm[n][tuple(norm(y.get(f,'')) for f in F)]+=1
 for x in rows:gr[x['source_file']][tuple(norm(x.get(f,'')) for f in F)]+=1
 SF=['model_key','kind','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw'];sp=defaultdict(Counter);sg=defaultdict(Counter)
 for x in params:
  if x['observation_kind'] in ['目录列入','重新申报列入','重申报汇总','完整表格勘误']:sp[Path(x['source_file']).name][tuple(norm(dict(x,kind=x['observation_kind']).get(f,'')) for f in SF)]+=1
 for x in rows:sg[x['source_file']][tuple(norm(x.get(f,'')) for f in SF)]+=1
 diffs=[];comparisons=[]
 for s in status:
  name=s['source_file'];ok=s['status']=='extracted';a=em[name];b=gm[name];c=pm[name];e=gr[name]
  comparisons.append({'source_file':name,'status':s['status'],'expected_model_rows':sum(a.values()),'extracted_model_rows':sum(b.values()),'model_missing':sum((a-b).values()) if ok else '', 'model_extra':sum((b-a).values()) if ok else '', 'expected_parameter_rows':sum(c.values()),'parameter_multiset_missing':sum((c-e).values()) if ok else '', 'parameter_multiset_extra':sum((e-c).values()) if ok else '', 'scientific_parameter_missing':sum((sp[name]-sg[name]).values()) if ok else '', 'scientific_parameter_extra':sum((sg[name]-sp[name]).values()) if ok else ''})
  if ok:
   for direction,count in [('expected_only',c-e),('source_only',e-c)]:
    for vals,num in count.items():diffs.append(dict(source_file=name,direction=direction,multiplicity=num,**dict(zip(F,vals))))
 write_csv(OUT/'逐源型号与参数多重集对账.csv',comparisons)
 write_csv(OUT/'参数多重集差异.csv',diffs,['source_file','direction','multiplicity']+F)
 summary={'source_catalogues':len(status),'source_sha_exact':sum(s['recovery_status']=='sha256_exact' for s in status),'extracted_sources':sum(s['status']=='extracted' for s in status),'extracted_rows':len(rows),'source_unavailable':[s['source_file'] for s in status if s['status']=='source_bytes_unavailable'],'extraction_issues':[s for s in status if s['status']=='extraction_issue'],'model_missing':sum(int(c['model_missing'] or 0) for c in comparisons),'model_extra':sum(int(c['model_extra'] or 0) for c in comparisons),'parameter_missing':sum(int(c['parameter_multiset_missing'] or 0) for c in comparisons),'parameter_extra':sum(int(c['parameter_multiset_extra'] or 0) for c in comparisons),'scientific_parameter_missing':sum(int(c['scientific_parameter_missing'] or 0) for c in comparisons),'scientific_parameter_extra':sum(int(c['scientific_parameter_extra'] or 0) for c in comparisons),'compared_fields':F,'scientific_fields':SF,'scope':'Pure-electric passenger car listing and reapplication tables. PDF geometry independently parsed. CFB logical cell order and source section/header strides; no model list used for extraction. Withdrawals and text-only range correction excluded; the full-grid correction row is included. No configuration-identity certificate.'}
 (OUT/'catalogue_result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
if __name__=='__main__':main()
