#!/usr/bin/env python3
"""Read-only, cached recovery of tax catalogue originals from official pages.

No signature/date is inferred from URL paths. Only SHA-exact matches certify
identity with the historical source index. Nonmatching public versions remain
separate evidence. TLS uses the standard validated default SSL context.
"""
import concurrent.futures, csv, hashlib, json, re, shutil, time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse, quote, parse_qs
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parent
INPUT=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
DATE=Path('/workspace/purchase_tax_audit/round2/dates/97批次日期_第29批续查更新.csv')
INDEX=INPUT/'原件索引/完整归档_106份原件嵌套索引_历史记录.csv'
TARGETS=list(csv.DictReader(INDEX.open(encoding='utf-8-sig')))
BYHASH={r['source_sha256']:r for r in TARGETS}
MAX_BYTES=32*1024*1024

class LinkParser(HTMLParser):
    def __init__(self):super().__init__();self.links=[];self.current=None
    def handle_starttag(self,tag,attrs):
        if tag.lower()=='a':self.current=[dict(attrs).get('href',''),[]]
    def handle_data(self,data):
        if self.current is not None:self.current[1].append(data)
    def handle_endtag(self,tag):
        if tag.lower()=='a' and self.current is not None:
            self.links.append((self.current[0],''.join(self.current[1]).strip()));self.current=None

def sha(b):return hashlib.sha256(b).hexdigest()
def valid_document(b):
    if b[:8]==bytes.fromhex('d0cf11e0a1b11ae1'):return 'ole_compound'
    if b[:4]==b'PK\x03\x04':return 'zip_office_or_archive'
    if b.startswith(b'%PDF-'):return 'pdf'
    if b.lstrip().startswith(b'{\\rtf'):return 'rtf'
    return 'unrecognized'

def fetch(url,kind):
    key=sha(url.encode())
    recpath=ROOT/'receipts'/f'{key}.json'
    if recpath.exists():
        rec=json.loads(recpath.read_text());p=Path(rec.get('local_path',''))
        if rec.get('status')!='ok' or (p.is_file() and sha(p.read_bytes())==rec.get('sha256')):
            return rec
    rec={'requested_url':url,'fetched_at_utc':datetime.now(timezone.utc).isoformat(),'kind':kind}
    try:
        req=Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; PublicResearchAudit/1.0)','Accept':'*/*'})
        with urlopen(req,timeout=20) as r:
            b=r.read(MAX_BYTES+1)
            rec.update(http_status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type',''),content_length_header=r.headers.get('Content-Length',''),content_encoding_header=r.headers.get('Content-Encoding',''),transfer_encoding_header=r.headers.get('Transfer-Encoding',''),response_headers=dict(r.headers.items()))
        if len(b)>MAX_BYTES:raise ValueError('32 MiB download limit exceeded')
        if kind=='attachment' and valid_document(b)=='unrecognized':
            rec.update(status='non_document_response',bytes=len(b),sha256=sha(b))
        else:
            ext='.html' if kind=='page' else Path(urlparse(rec['final_url']).path).suffix.lower()
            if not ext or len(ext)>8:ext='.bin'
            p=ROOT/('pages' if kind=='page' else 'downloads')/f'{key}{ext}'
            p.write_bytes(b)
            rec.update(status='ok',bytes=len(b),sha256=sha(b),local_path=str(p))
            length=rec.get('content_length_header','')
            if length and length.isdigit() and int(length)!=len(b):
                rec.update(status='response_length_mismatch',transmission_complete=False)
            if kind=='attachment':rec['detected_format']=valid_document(b)
    except HTTPError as e:rec.update(status='http_error',http_status=e.code,error=str(e))
    except Exception as e:rec.update(status='fetch_error',error=f'{type(e).__name__}: {e}')
    recpath.parent.mkdir(parents=True,exist_ok=True);recpath.write_text(json.dumps(rec,ensure_ascii=False,indent=2))
    return rec

def desktop(url):
    return url.replace('https://wap.miit.gov.cn/','https://www.miit.gov.cn/')

def attachment_candidates(url):
    """Use explicit official static file paths embedded in download links."""
    u=urlparse(url); candidates=[]
    if u.scheme=='http' and u.hostname=='www.miit.gov.cn':
        candidates.append(url.replace('http://','https://',1))
        if u.path.startswith('/n'):
            candidates.append('https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit'+u.path)
    query=parse_qs(u.query)
    if query.get('fileUrl') and query['fileUrl'][0].startswith('/cms_files/'):
        candidates.append('https://www.miit.gov.cn'+query['fileUrl'][0])
    if u.hostname in {'jyhwzhq.miit.gov.cn','ythxxfb.miit.gov.cn'} and u.path.startswith('/cms_files/'):
        candidates.append('https://www.miit.gov.cn'+u.path)
    candidates.append(quote(url,safe=':/?&=%+#'))
    return list(dict.fromkeys(candidates))

def process_page(row):
    url=desktop(row['source_url'])
    rec=fetch(url,'page')
    rec=dict(rec,system=row['system'],batch=row['batch'],historical_source_url=row['source_url'])
    links=[]
    if rec['status']=='ok':
        b=Path(rec['local_path']).read_bytes()
        text=b.decode('utf-8',errors='replace')
        parser=LinkParser();parser.feed(text)
        for href,label in parser.links:
            link=desktop(urljoin(rec['final_url'],href))
            if re.search(r'\.(?:docx?|xlsx?|pdf|zip|wps)(?:[?#].*)?$',link,re.I):
                if ('购置税' in label or ('撤销' in label and '新能源' in label)):
                    for actual in attachment_candidates(link):
                        links.append({'url':actual,'label':label,'system':row['system'],'batch':row['batch'],'page_url':rec['final_url'],'page_link_url':link})
    return rec,links

def main():
    rows=list(csv.DictReader(DATE.open(encoding='utf-8-sig')))
    for r in rows:
        if r['system']=='减免目录' and r['batch']=='6':
            r['source_url']='https://www.miit.gov.cn/jgsj/zbys/wjfb/art/2024/art_b1d6e07d8be2458bbba1155695d85c22.html'
    pages=[];attachments={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        fs={pool.submit(process_page,r):r for r in rows}
        for f in concurrent.futures.as_completed(fs):
            rec,links=f.result();pages.append(rec)
            for a in links:
                attachments.setdefault(a['url'],{'url':a['url'],'links':[]})['links'].append(a)
            if len(pages)%10==0:print(f'pages {len(pages)}/97; candidate attachments {len(attachments)}',flush=True)
    (ROOT/'page_manifest.json').write_text(json.dumps(sorted(pages,key=lambda r:(r['system'],int(r['batch']))),ensure_ascii=False,indent=2))
    out=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        fs={pool.submit(fetch,u,'attachment'):a for u,a in attachments.items()}
        for f in concurrent.futures.as_completed(fs):
            rec=f.result();rec=dict(rec,links=fs[f]['links']);out.append(rec)
            if len(out)%10==0:print(f'attachments {len(out)}/{len(attachments)}; SHA-exact {sum(x.get("sha256") in BYHASH for x in out)}',flush=True)
    old=Path('/workspace/purchase_tax_audit/round2/batch29_official_attachment.doc')
    if old.exists():out.append({'status':'ok','kind':'attachment','local_path':str(old),'sha256':sha(old.read_bytes()),'bytes':old.stat().st_size,'requested_url':'https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit/n1146295/n1652858/n1652930/n4509607/c7589631/part/7589662.doc','origin':'previous_round_retrieval','links':[]})
    (ROOT/'attachment_manifest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    matched={r['sha256']:r for r in out if r['status']=='ok' and r.get('sha256') in BYHASH}
    manifest=[]
    for t in TARGETS:
        r=matched.get(t['source_sha256']);m=dict(t)
        if r:
            dst=ROOT/'recovered'/t['system']/t['source_file'];dst.parent.mkdir(parents=True,exist_ok=True)
            if not dst.exists():shutil.copyfile(r['local_path'],dst)
            m.update(recovery_status='sha256_exact',recovered_path=str(dst),download_url=r['requested_url'],recovered_sha256=r['sha256'],recovered_bytes=r['bytes'])
        else:m.update(recovery_status='not_recovered',recovered_path='',download_url='',recovered_sha256='',recovered_bytes='')
        manifest.append(m)
    with (ROOT/'106原件公开回收清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(manifest[0]));w.writeheader();w.writerows(manifest)
    summary={'target_originals':len(TARGETS),'page_success':sum(r['status']=='ok' for r in pages),'page_total':len(pages),'candidate_attachments':len(attachments),'attachment_success':sum(r['status']=='ok' for r in out),'sha256_exact_recovered':len(matched),'catalogue_exact_recovered':sum(m['scope']=='目录' and m['recovery_status']=='sha256_exact' for m in manifest),'historic_withdrawal_exact_recovered':sum(m['scope']=='历史撤销' and m['recovery_status']=='sha256_exact' for m in manifest),'unmatched_attachment_versions':sum(r['status']=='ok' and r.get('sha256') not in BYHASH for r in out)}
    (ROOT/'recovery_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
