$(function () {
    var publicJS = {
        init: function () {
            this.links();
            this.zcjdchoose();
            this.search();
            this.tap();
            this.fontSize();
        },
        links: function () {
            $('.pulldown').hover(function () {
                $('.pulldown-menu').hide()
                $(this).children('.pulldown-menu').show()
            }, function () {
                $('.pulldown-menu').hide()
            }
            );
        },
        tap: function () {
            $('.searchArea p').on('click', function () {
                $(this).addClass('on').siblings().removeClass('on');
            })

            $('.range p').on('click', function () {
                $(this).addClass('on').siblings().removeClass('on');
            })

            $('.langqh .lang').on('click', function () {
                $('.langqh .selects').toggle()
            })
        },
        fontSize: function () {
            $('.fontsize span.big').on('click', function () {
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').addClass('big')
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').removeClass('mb sm')
            })
            $('.fontsize span.middle').on('click', function () {
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').addClass('mb')
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').removeClass('big sm')
            })
            $('.fontsize span.small').on('click', function () {
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').addClass('sm')
                $('.arc_cont,.zs .zscont p,.arc_cont p,.arc_cont p span,.arc_cont p strong,.arctips div strong,.arctips div span,.arctips div').removeClass('mb big')
            })
        },
        zcjdchoose: function () {
            $('.jdchoose .jdxs dd,.jdchoose .pubtime dd').on('click', function () {
                $(this).addClass('on').siblings().removeClass('on')
            })
        },
        search: function () {
            $('#fgksearch').keydown(function (e) {
                 var userName=　"";
                $.ajax({
                      url: '/service/jzxx/isLogin.do',
                      dataType: 'json',
                      async:false,
                      cache: false,
                      type:"post",
                      success: function(result){
                         if(result!=''){
                          if(result.success){
                          userName=result.userid;
                          } else {}
                         }
                      }
                  });
                if (e.keyCode == 13) {
                    var siteCode = $('meta[name="SiteIDCode"]').attr('content')
                    var val = $.trim($('#fgksearch').val()) == '个税'?'个人所得税':$.trim($('#fgksearch').val());
                    var type = $('.searchArea p.on').attr('data-id')
                    var column=''
                    if(type=="0"){
                        column="政策法规"
                    }else if(type=="1"){
                        column="政策解读"
                    }else{
                        column='政策法规,政策解读,政策指引&label=文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引'
                    }
                    
                    if (val == '') {
                        alert('请输入你要搜索的内容')
                    } else if(val.length < 2) {
                        alert('请输入2个字以上关键词')
                    } else if(val.length > 120) {
                        alert('建议字数控制在120字以内，以提高搜索效率')
                    } else {
                        var url = "/zcfgk/c100028/zcwj.html?siteCode=" + siteCode + "&searchWord=" + val + "&type=" + type + "&pageSize=10&pageNum=0&orderBy=5&column="+column+'&likeDoc=0&wordPlace=0&indexCode=1&userName=' + userName
                        url = encodeURI(url)
                        window.open(url)
                    }
                }
            });


            var siteCode = $('meta[name="SiteIDCode"]').attr('content')

            // 热搜词
            // $.ajax({
            //     type: "get",
            //     url: "http://www.chinatax.gov.cn/search5/search/s?siteCode=" + siteCode + "&column=全部",
            //     success: function (res) {
            //         var html = '<span class="tle">热门关键词：</span>';
            //         var htmlword=''
            //         $.each(res.hotWords, function (i, v) {
            //             html += '<span class="word">' + v + '</span>'
            //         })
            //         $('.fgkhotWord').html(html)

            //         $.each(res.hotWords, function (i, v) {
            //             htmlword += '<li class="word">' + v + '</li>'
            //         })
            //         $('.searchcond .hotword ul').html(htmlword)
            //     }
            // });

            // 修改热搜词
                    var html = '<span class="tle">热门关键词：</span>';
                    var htmlword=''

                        html += '<span class="word">个人所得税</span>'
                        html += '<span class="word">增值税</span>'
                        html += '<span class="word">企业所得税</span>'
                        html += '<span class="word">小微企业</span>'
                        html += '<span class="word">印花税</span>'
                    $('.fgkhotWord').html(html)


                        htmlword += '<li class="word">个人所得税</li>'
                        htmlword += '<li class="word">增值税</li>'
                        htmlword += '<li class="word">企业所得税</li>'
                        htmlword += '<li class="word">小微企业</li>'
                        htmlword += '<li class="word">印花税</li>'
                    $('.searchcond .hotword ul').html(htmlword)



            // 热搜词跳转
            $('.fgkhotWord,.searchcond .hotword ul').on('click', '.word', function () {
                 var userName=　"";
                $.ajax({
                      url: '/service/jzxx/isLogin.do',
                      dataType: 'json',
                      async:false,
                      cache: false,
                      type:"post",
                      success: function(result){
                         if(result!=''){
                          if(result.success){
                          userName=result.userid;
                          } else {}
                         }
                      }
                  });
                var word = $(this).text()=='个税'?'个人所得税':$(this).text();
                var type = $('.searchArea p.on').attr('data-id')
                var column='政策法规,政策解读,政策指引&label=文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引'
                if(type=="0"){
                    column="政策法规"
                }else if(type=="1"){
                    column="政策解读"
                }else{
                    column='政策法规,政策解读,政策指引&label=文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引'
                }
                var url = "/zcfgk/c100028/zcwj.html?siteCode=" + siteCode + "&searchWord=" + word + "&type=" + type + "&pageSize=10&pageNum=0&orderBy=5&column="+column+'&likeDoc=0&wordPlace=0&indexCode=1&userName=' + userName
                url = encodeURI(url)
                window.open(url)
            })

            //普通搜索
            $('.fkginputsr .nsearch').on('click', function () {
                var val = $.trim($('#fgksearch').val()) =='个税'?'个人所得税':$.trim($('#fgksearch').val());
                val =　val.replace("%", "％")
                var type = $('.searchArea p.on').attr('data-id')
                var participleRule = $('.range p.on').attr('data-id')
                var column=''
                var userName=　"";
                $.ajax({
                      url: '/service/jzxx/isLogin.do',
                      dataType: 'json',
                      async:false,
                      cache: false,
                      type:"post",
                      success: function(result){
                         if(result!=''){
                          if(result.success){
                          userName=result.userid;
                          } else {}
                         }
                      }
                  });
                if(type=="0"){
                    column="政策法规"
                }else if(type=="1"){
                    column="政策解读"
                }else{
                    column='政策法规,政策解读,政策指引&label=文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引'
                }
                if (val == '') {
                    alert('请输入你要搜索的内容')
                } else if(val.length < 2) {
                    alert('请输入2个字以上关键词')
                } else if(val.length > 120) {
                        alert('建议字数控制在120字以内，以提高搜索效率')
                } else {
                  var url = "/zcfgk/c100028/zcwj.html?siteCode=" + siteCode + "&searchWord=" + val + "&type=" + type + "&pageSize=10&pageNum=0&orderBy=5&column="+column+'&likeDoc=0&wordPlace=0&indexCode=1&participleRule=' + participleRule+ '&userName=' + userName
                    url = encodeURI(url)
                    window.open(url)
                }
            })
        }
    }


    publicJS.init()
})


// 输入框联想词
    var timer = "";
    $("#fgksearch").on('keydown',function(e){
        clearTimeout(timer); //清除之前的定时器
       timer = setTimeout(function(){
            var sousuo = $("#fgksearch").val();
            if(sousuo == ""){
                $('.lxc').hide();
            } else {
                 $.ajax({
                type: "get",
                url: 'https://www.chinatax.gov.cn/search5/search/suggestFGK?siteCode=bm29000002&indexCode=1&typename=文件&searchWord='+sousuo+'&column=政策法规,政策解读,政策指引&label=文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引',
                success: function (res) {
                //  console.log(res)
                //   console.log(JSON.parse(res).suggestFGKList)
                    $('.lxc').html("");
                    var html = '';
                    var data = JSON.parse(res).suggestFGKList;
                    $.each(data,function(index,item){
                        var lxc = item.replace(/<[^>]+>/g,"");
                        html += '<li title="'+ lxc +'">'+ lxc +'</li>';
                    })
                    $('.lxc').html(html);
                    $('.lxc').show();
                    $('.lxc li').each(function(){
                        $(this).on('click',function(){
                            $("#fgksearch").val($(this).text());
                            $('.lxc').hide();
                        })
                    })
                }
            })
            }
        },1000);
    })