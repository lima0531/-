#!/usr/bin/env python3
"""Package verified public originals in independent ZIPs below 32 MiB."""
import csv
import hashlib
import json
import zlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIMIT = 28 * 1024 * 1024
files = {}
with (ROOT/'archive/106原件公开回收清单.csv').open(encoding='utf-8-sig', newline='') as f:
    for row in csv.DictReader(f):
        if row['recovery_status'] == 'sha256_exact':
            p = Path(row['recovered_path'])
            assert hashlib.sha256(p.read_bytes()).hexdigest() == row['source_sha256']
            files[str(p.relative_to(ROOT))] = p
for p in ROOT.glob('technical/rec*_original.pdf'):
    files[str(p.relative_to(ROOT))] = p
for name in ['batch26_7368842.wps', 'batch26_7368844.docx']:
    p = ROOT/'archive/version_search'/name
    assert p.is_file()
    files[str(p.relative_to(ROOT))] = p

items = []
for rel, p in files.items():
    b = p.read_bytes()
    items.append({'relative_path':rel, 'path':p, 'bytes':len(b),
                  'sha256':hashlib.sha256(b).hexdigest(),
                  'compressed_estimate':len(zlib.compress(b,6))+len(rel.encode())*2+200})
items.sort(key=lambda r:r['compressed_estimate'],reverse=True)
groups, sizes = [], []
for row in items:
    assert row['compressed_estimate'] < LIMIT
    candidates = [i for i,s in enumerate(sizes) if s+row['compressed_estimate'] < LIMIT]
    if candidates:
        index = min(candidates,key=lambda i:sizes[i])
    else:
        index=len(groups);groups.append([]);sizes.append(0)
    groups[index].append(row);sizes[index]+=row['compressed_estimate']

manifest, packages = [], []
for index, group in enumerate(groups,1):
    name=f'购置税项目_公开原件_第{index}包_20261008.zip'
    target=Path('/workspace')/name
    fingerprint_text=''.join(f"{r['sha256']}  {r['relative_path']}\n" for r in sorted(group,key=lambda r:r['relative_path']))
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for row in group:
            archive.write(row['path'],row['relative_path'])
            manifest.append({k:row[k] for k in ['relative_path','bytes','sha256']}|{'package_name':name})
        archive.writestr('原件包_SHA256.txt',fingerprint_text)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
    assert target.stat().st_size < 32*1024*1024
    packages.append({'name':name,'path':str(target),'bytes':target.stat().st_size,
                     'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(group),'crc_verified':True})
with (ROOT/'公开原件_分包索引.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(manifest[0]));writer.writeheader();writer.writerows(manifest)
(ROOT/'original_packages.json').write_text(json.dumps(packages,ensure_ascii=False,indent=2))
print(json.dumps({'original_files_packaged':len(items),'packages':packages},ensure_ascii=False))
