# 第 26、35 批历史原件版本补查

本目录只写入第三轮补采结果，未修改输入精简包。

## 字节恢复与版本边界

- 第 35 批主管网站目录 WPS 已重新取得完整 756,040 字节，SHA256 `e4a6abd0e50daa81d029f8b37584511354700e855dc89de210fcba782b0643f0`，与历史原件索引完全一致。路径为 `batch35_complete.wps`，网络回执为同名 `.request.json`。
- 首次历史下载回执实际为 458,398 字节而 Content-Length 标为 756,040，属于完整性异常。完整复核原件不可与首次异常字节作为两个可信官方版本并列。旧回执缺少完整响应头，不能进一步断言具体编码或传输机制。
- 第 26 批历史目录 DOCX（99,034 字节，SHA256 `de0890335ef3a4f1302a8a0735ec8b6aed52e994e2635db481820060d62248b5`）及历史撤销 DOCX（53,919 字节，SHA256 `f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544`）尚未取得相同字节。工信部主管公告和相关部门页面公开附件已取得；下面提供当前官方不同字节版本的内容复核，不替换历史哈希。

## 第 26 批目录内容复核

主管公告：<https://www.miit.gov.cn/zwgk/zcwj/wjfb/gg/art/2020/art_b2d97a57976f43d18a7fa142b17bdc48.html>。

官方附件 `7368842.wps` 为 938,352 字节，SHA256 `c9ea4cdf312f32d39eb9a4bc2255f54f618f85bcb54be090593a92c9f136ff32`。使用独立 LibreOffice profile 转换至 `derived/batch26_7368842.docx`，转换产物属于派生文件。按原正文顺序识别“纯电动汽车/乘用车”段，并检查完整 9 列表头后，重提 83 行。

- 83 行型号与历史 `mf_batch26.docx` 留存枚举的 Counter 完全一致。
- 续驶里程、整备质量、蓄电池质量、蓄电池能量 4 个原值字段共 332 个比较，0 差异。
- 企业名称、型号、通用名称、上述 4 个数值原值和备注共 664 个比较，25 个原字符串差异。23 个为通用名称全角/半角空格，NFKC 后一致；2 个为企业名在分页处重复显示与空单元格的差异，涉及 `GAM6480BEVB0C`、`X75D7`。
- 按当前表上下文得到的企业名称与历史 `firm_context_candidate` 全 83 行一致。原字符串差异仍保留，未对输入做修复。

重提结果及对照见 `batch26_current_official_bev_passenger_83.csv`、`batch26_current_vs_historical_catalogue_comparison.json`。可运行 `compare26_catalogue.py` 复核；运行前需已保存 `derived` 中的转换文件。

## 第 26 批撤销内容复核

主管公告附件 `7368844.docx` 为 38,700 字节，SHA256 `ee9325e79d91945e2e22986ebc4cb7894634e21f3be04611ab38942c799eebe7`。直接读取 DOCX XML，验证 6 列原表头后，重提全表 324 行。型号 Counter 与历史原件枚举 0 差异；企业名称、产品名称、原列入批次这 3 个历史语义表可比字段均 0 差异。未将序号和备注也宣称为与历史原件全字段一致。

见 `batch26_current_official_withdrawal_324.csv`、`batch26_current_vs_historical_withdrawal_comparison.json`，可运行 `compare26_withdrawal.py` 复核。

## 检索与网络记录

`search26.json`、`search35.json` 为工信部站内原生检索响应，`search_results_summary.json` 保留结果标题与 URL。`batch26_page_*.html` 及回执保留公告/部门页面；`batch26_attachment_discovery.json` 保留附件标签、所属页及页面哈希；`batch26_download_manifest.json` 保留当前官方附件完整响应头、字节数和 SHA256。

历史撤销语义表给出的税务原公告 <https://fgk.chinatax.gov.cn/zcfgk/c100013/c5207235/content.html> 首次访问收到代理 Tunnel 403。政府全站检索 `sousuo.www.gov.cn` 和税务官网 `www.chinatax.gov.cn` 首次访问亦为 Tunnel 403；均保留单次错误回执，未重复访问。当前结果不声称这些页面永久失效。

上述内容比较补充了公开官方证据，未取得历史两份同字节 DOCX，也不能认证跨目录具体配置身份、低温检测或车辆制造日期。
