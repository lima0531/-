"""Audit visible official-source scope independently of the supplied model population."""
import csv,json,re,html,urllib.parse,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parent; B=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
 with (R/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
cn={'零':0,'〇':0,'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9}
def num(s):
 if s.isdigit():return int(s)
 if '十' in s:
  a,b=s.split('十');return (cn.get(a,1) if a else 1)*10+(cn.get(b,0) if b else 0)
 return cn.get(s,-1)
def batches(title):return [(system+'目录',num(number)) for system,number in re.findall(r'(免征|减免)车辆购置税的新能源汽车车型目录[》」]?\s*[（(]\s*第([〇零一二三四五六七八九十\d]+)批',title)]
column=read(R/'official_announcements_column_complete.csv');search=read(R/'official_search_results.csv');found=collections.defaultdict(list)
for row in column+search:
 for key in batches(row['title']):found[key].append(row)
# The first batch is absent from current MIIT title results but independently named
# in the live government tax-authority republication, whose complete response was saved.
pages=json.loads((R.parent/'archive/page_manifest.json').read_text());first=next(x for x in pages if x['system']=='免征目录' and x['batch']=='1');plain=html.unescape(re.sub(r'<[^>]+>','',Path(first['local_path']).read_text()))
assert '免征车辆购置税的新能源汽车车型目录（第一批）' in plain and '2014年第54号' in re.sub(r'\s+','',plain)
found[('免征目录',1)].append({'title':'免征车辆购置税的新能源汽车车型目录（第一批）','url':first['requested_url'],'evidence_kind':'政府税务主管部门正式转载','response_sha256':first['sha256']})
ledger=read(R.parent/'dates/97批次日期_本轮官方登记补采更新.csv');index=read(B/'原件索引/完整归档_106份原件嵌套索引_历史记录.csv');recover=read(R.parent/'archive/106原件公开回收清单.csv'); rec_by={(x['system'],x['source_file']):x for x in recover}
rows=[]
for x in ledger:
 system=x['system'];batch=int(x['batch']);key=(system,batch);witnesses=found[key];assert witnesses,key
 upper=x['public_date_upper_bound'];inside=upper<='2024-12-31';required=system=='免征目录' and batch<=73 or system=='减免目录' and batch<=13
 assert inside==required,(key,upper)
 ix=next(z for z in index if z['scope']=='目录' and z['system']==system and re.search(r'(?:mf_batch0*|cat_batch0*)'+str(batch)+r'\.',z['source_file']))
 rc=rec_by[(system,ix['source_file'])]
 witness=next((w for w in witnesses if '/zwgk/zcwj/wjfb/gg/' in w['url']),witnesses[0])
 rows.append({'system':system,'batch':str(batch),'in_source_horizon_through_20241231':str(int(inside)),'use_in_2022_2024_panel_sources':str(int(required)),'registered_public_date_exact':x['publish_date_exact'],'registered_exact_date_verified':x['publish_date_exact_is_verified'],'public_date_upper':upper,'source_file':ix['source_file'],'input_expected_sha256':ix['source_sha256'],'current_exact_recovery_status':rc['recovery_status'],'current_exact_original_path':rc['recovered_path'],'batch_title_independently_observed':'1','batch_title_witness_url':witness['url'],'batch_title_witness_title':witness['title'],'witness_scope':witness.get('evidence_kind','工信部官方栏目/站内搜索可见标题'),'date_from_search_used_as_exact_date':'0','outside_horizon_reason':'' if inside else '2025年目录；仅作为归档背景，不进入2022–24面板'})
write('97_catalogues_independent_scope_comparison.csv',rows)
# Enumerate formal and draft withdrawal / correction links from the official search
# API's complete indexed bodies. An indexed link is not treated as fetched original bytes.
refs=[]
for p in sorted((R/'raw').glob('search*.txt')):
 try:groups=json.loads(p.read_text())['data']['searchResult']['dataResults'] or []
 except Exception:continue
 receipt_path=p.with_suffix('.json');receipt=json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
 for group in groups:
  for item in group.get('groupData') or [group]:
   d=item.get('data') or {}
   try:elements=json.loads(d.get('infoextends','')).get('elementList',[])
   except Exception:continue
   for element in elements:
    if element.get('fieldName')!='content':continue
    body=element.get('fieldValue','').replace('\\"','"');body_plain=html.unescape(re.sub('<[^>]+>','',body))
    for url,label in re.findall(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>',body,re.S|re.I):
     label=html.unescape(re.sub(r'<[^>]+>','',label));label=re.sub(r'\s+','',label)
     if not any(t in label for t in ['撤销','更正','勘误']):continue
     if not any(t in label for t in ['购置税','免税']):continue
     formal='拟撤销' not in label and '拟撤销' not in d.get('title','')
     matches=[(s,b) for s,b in batches(d.get('title','')) if s=='免征目录']
     if not matches:matches=[(s,b) for s,b in batches(body_plain) if s=='免征目录']
     logical=('免征配套撤销:'+str(matches[-1][1])) if matches else ('2018-05-22独立正式撤销' if formal and '关于撤销' in d.get('title','') else '拟撤销公示或待区分来源')
     refs.append({'announcement_url':urllib.parse.urljoin('https://www.miit.gov.cn/',d['url']),'announcement_title':d.get('title',''),'search_display_date_not_exact':d.get('jsearch_date',''),'attachment_url':urllib.parse.urljoin('https://www.miit.gov.cn/',url),'attachment_label':label,'formal_withdrawal_link':str(int(formal)),'logical_notice_group':logical,'indexed_body_response_file':str(p),'indexed_body_response_sha256':receipt.get('sha256',hashlib.sha256(p.read_bytes()).hexdigest()),'indexed_content_scope':'官网站内搜索返回的正文链接；是否取得原件及其版本由archive/coverage回收receipt另行判断'})
# De-duplicate repeated API queries, retain distinct official page/attachment versions.
refs=list({(x['announcement_url'],x['attachment_url']):x for x in refs}.values());write('withdrawal_and_correction_indexed_link_inventory.csv',refs)
formal_groups=sorted(set(x['logical_notice_group'] for x in refs if x['formal_withdrawal_link']=='1'))
expected=['2018-05-22独立正式撤销']+['免征配套撤销:'+str(b) for b in [18,20,21,22,23,24,26,27,28,43]]
assert set(formal_groups)==set(expected),(formal_groups,expected)
search_summary=json.loads((R/'search_enumeration_summary.json').read_text());qstats={}
for name in sorted(set(x['query'] for x in search_summary)):
 qs=[x for x in search_summary if x['query']==name]; total=next((x['total_group_count'] for x in qs if x['status']=='ok'),None);n=sum(x.get('groups_returned',0) for x in qs)
 qstats[name]={'declared_distinct_groups':total,'received_groups_across_pages':n,'pages':len(qs),'failed_pages':[x['page'] for x in qs if x['status']!='ok'],'declared_count_matched':n==total};assert n==total,(name,n,total)
summary={'source_cutoff':'2024-12-31','announcement_column':json.loads((R/'column_enumeration_summary.json').read_text()),'official_search_query_coverage':qstats,'input_catalogues':len(rows),'catalogues_through_cutoff':sum(x['in_source_horizon_through_20241231']=='1' for x in rows),'exempt_catalogues_through_cutoff':73,'reduced_catalogues_through_cutoff':13,'2025_catalogues_excluded_from_panel':11,'input_source_sequence_gaps_within_named_cutoff':[],'catalogue_batches_2022_2024':36,'historic_formal_withdrawal_logical_notices_observed':11,'historic_formal_withdrawal_groups':formal_groups,'previous_9_historic_source_index_missing_notices':['2018-05-22独立正式撤销','免征配套撤销:28'],'newly_recovered_formal_withdrawal_sources':2,'new_full_source_rows':2020,'historic_row_records_after_addition':5027,'indexed_attachment_link_records':len(refs),'formal_indexed_links':sum(x['formal_withdrawal_link']=='1' for x in refs),'correction_errata_query_results':0,'correction_absence_or_entire_internet_exhaustiveness_certified':False,'whole_catalogue_model_population_exhaustiveness_certified':False,'all_source_row_reenumeration_certified':False,'first_batch_date_still_exact_unverified':True,'batch40_withdrawal_filename_note':'既有批40文件SHA77e87fb0...等于第43批公告撤销附件；40为历史文件标签，不能据此改变已核2021-06-11日期。','scope_limit':'仅官方公告栏目完整分页及列明关键词/日期范围的站内搜索当前可见数据；不认证已删除页、未索引附件、全互联网、更正绝不存在、全部车型身份或法律资格。'}
(R/'independent_source_scope_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['announcement_column','official_search_query_coverage','scope_limit']},ensure_ascii=False))
