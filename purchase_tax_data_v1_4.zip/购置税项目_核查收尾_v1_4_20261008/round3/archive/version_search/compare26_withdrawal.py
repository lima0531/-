from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
import csv,json,hashlib,unicodedata,re
ROOT=Path('/workspace/purchase_tax_audit/round3/archive/version_search')
INPUT=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
p=ROOT/'batch26_7368844.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with ZipFile(p) as z:r=E.fromstring(z.read('word/document.xml'))
def text(c):return ''.join(c.itertext()).strip()
def key(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',x)).upper()
out=[]
for ti,t in enumerate(r.findall('.//w:tbl',ns)):
 rows=t.findall('w:tr',ns)
 header=[text(c) for c in rows[0].findall('w:tc',ns)]
 assert header==['序号','企业名称','车辆型号','目录发布产品名称','批次','备注'],header
 for ri,row in enumerate(rows[1:],1):
  cells=[text(c) for c in row.findall('w:tc',ns)]
  assert len(cells)==6,(ri,cells)
  out.append(dict(table_0based=ti,row_0based=ri,model_raw=cells[2],model_key=key(cells[2]),firm_raw=cells[1],product_name_raw=cells[3],old_batch_raw=cells[4],remarks_raw=cells[5],source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
with (ROOT/'batch26_current_official_withdrawal_324.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
old=list(csv.DictReader((INPUT/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv').open(encoding='utf-8-sig')))
old=[o for o in old if o['原件SHA256']=='f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544']
oldenum=list(csv.DictReader((INPUT/'目录覆盖/9份历史撤销_原件全列枚举3007行.csv').open(encoding='utf-8-sig')))
oldenum=[o for o in oldenum if o['source_sha256']=='f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544']
from collections import Counter
miss=Counter(o['model_key'] for o in oldenum)-Counter(o['model_key'] for o in out)
extra=Counter(o['model_key'] for o in out)-Counter(o['model_key'] for o in oldenum)
lookup={o['model_key']:o for o in old};diff=[]
for o in out:
 a=lookup.get(o['model_key'])
 if not a:continue
 for raw,oldfield in [('firm_raw','企业名称'),('product_name_raw','目录发布产品名称'),('old_batch_raw','原列入批次')]:
  if o[raw]!=a[oldfield]:diff.append({'model_key':o['model_key'],'field':raw,'current_raw':o[raw],'historical_semantic_value':a[oldfield]})
result={'source_url':'https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit/n1146295/n1652858/n1652930/n4509607/c7368799/part/7368844.docx','current_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'historical_target_sha256':'f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544','current_rows':len(out),'historical_enum_rows':len(oldenum),'model_counter_missing':dict(miss),'model_counter_extra':dict(extra),'matched_model_membership':not(miss or extra),'compared_semantic_columns':['企业名称','目录发布产品名称','原列入批次'],'semantic_differences':diff,'version_status':'distinct bytes; original historical target not recovered; current official model content compared to retained historical table'}
(ROOT/'batch26_current_vs_historical_withdrawal_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
