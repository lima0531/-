#!/usr/bin/env python3
"""Prepare a traced source-corrected base for the final event reconstruction."""
import csv
import hashlib
import json
import shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'versioning/data_v1_2'
OUT=ROOT/'reconstruction/corrected_source_base'
COV=ROOT/'coverage'
SOURCE_SHA='c388317a1453e6b139a2a67bd21e4b5818d6711b0982feb55626f0ac886783ff'

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        r=csv.DictReader(f);rows=list(r)
        return r.fieldnames,rows

def write(path,fields,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

before={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in BASE.rglob('*') if p.is_file()}
shutil.copytree(BASE,OUT,dirs_exist_ok=True)
updates=[]
for rel,patch,keycols,count in [
 ('研究数据/资格事件_重建去重表.csv','batch27_corrected_events_47.csv',['event_id'],47),
 ('研究数据/资格事件_逐原件连接.csv','batch27_corrected_source_links_47.csv',['event_id','source_record_id'],47),
 ('目录覆盖/正式历史撤销_语义记录修正版3007行.csv','batch27_corrected_semantic_records_424.csv',['input_csv_line_1based'],424),
]:
    fields,rows=read(OUT/rel);pfields,patches=read(COV/patch)
    assert fields==pfields and len(patches)==count
    key=lambda r:tuple(r[c] for c in keycols)
    target={key(r):dict(r) for r in patches};assert len(target)==count
    applied=0
    for i,row in enumerate(rows):
        if key(row) not in target:continue
        replacement=target[key(row)]
        assert row['model_key']==replacement['model_key']
        if 'source_sha256' in row:assert row['source_sha256']==SOURCE_SHA
        if '原件SHA256' in row:
            assert row['原件SHA256']==SOURCE_SHA
            # This field records the raw uploaded value, not the corrected date.
            replacement['撤销事件日_raw']=row['撤销事件日_raw']
        for field in fields:
            if row[field]!=replacement[field]:
                updates.append({'target_file':rel,'row_key':'|'.join(key(row)),'model_key':row['model_key'],
                                'field':field,'before':row[field],'after':replacement[field],
                                'evidence':'coverage/batch27_32_source_date_conclusion.json'})
        rows[i]=replacement;applied+=1
    assert applied==count
    write(OUT/rel,fields,rows)
assert before=={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in BASE.rglob('*') if p.is_file()}
write(ROOT/'reconstruction/第27批错挂日期_实际字段修订.csv',list(updates[0]),updates)
summary={'repaired_source_sha256':SOURCE_SHA,'corrected_cohort_events':47,'corrected_source_links':47,
         'corrected_historic_semantic_rows':424,'field_updates':len(updates),'opaque_ids_preserved':True,
         'raw_uploaded_date_column_preserved':True,'base_inputs_modified':False,
         'output_is_intermediate_source_base_not_ready_for_analysis':True,
         'old_batch':'32','old_date':'2020-06-02','verified_batch':'27','verified_registered_date':'2019-10-25'}
(ROOT/'reconstruction/source_correction_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
