$(function () {
    var fgkIndexJS = {
        init: function () {
            this.zxwj()
            this.indexJD();
            this.search();
            this.swiper();
            this.tap();
            this.indexzcjd()
        },
        indexJD:function(){
            getAjaxpic()
            getAjaxvd()
            function getAjaxpic(){
                $.ajax({
                    type: 'post',
                    url: 'https://www.chinatax.gov.cn/getFileListByCodeId',
                    data: {
                        "siteCode":'chinatax',
                        "codeId":'n2340339' ,
                        "channelId":'bb7b88a22162418d9eaa51f3035f467f',
                        "page":1,
                        "size":6
                    },
                    success: function (data) {
                        var res = data.results.data
                        var data = res.results
                        var html=''
                        $.each(data, function (i, v) {
                            if(v.resList.length > 0 && v.resList[0].filePath.length > 0){
                                var picsrc=v.resList[0].filePath.split('http://www.chinatax.gov.cn')[1]
                                var Url = v.url.split('http://www.chinatax.gov.cn')[1]
                                // var picsrc=v.resList[0].filePath
                                html+='<div class="swiper-slide"><a href="'+Url+'" target="_blank"><img src="'+picsrc+'"alt=""><p class="title">'+v.title.slice(0,23)+'...</p></a></div>'
                            }
                            
                        })
                        $('.zcjdpic .swiper-container .swiper-wrapper').html(html)
                        var wh=$(window).width();
                        if(wh>768){
                            // 政策解读-图片
                            var charactersSwiperPic = new Swiper('.zcjdpic .swiper-container', {
                                paginationClickable: true,
                                pagination: '.zcjdpic .pagination',
                                autoplay: 2000, //可选选项，自动滑动
                                loop: true, //可选选项，开启循环
                                slidesPerView: 3,
                                centeredSlides : true
                            })
                        }else{
                            // 政策解读-图片
                            var charactersSwiperPic = new Swiper('.zcjdpic .swiper-container', {
                                paginationClickable: true,
                                pagination: '.zcjdpic .pagination',
                                autoplay: 2000, //可选选项，自动滑动
                                loop: true, //可选选项，开启循环
                                slidesPerView: 1,
                                centeredSlides : true
                            })
                        }

                    }
                  })
            }

            function getAjaxvd(){
                $.ajax({
                    type: 'post',
                    url: 'https://www.chinatax.gov.cn/getFileListByCodeId',
                    data: {
                        "siteCode":'chinatax',
                        "codeId":'c102390' ,
                        "channelId":'ccb087bdb34048edb794b860fb2d2a95',
                        "page":1,
                        "size":4
                    },
                    success: function (data) {
                        var res = data.results.data
                        var data = res.results
                        var html=""
                        $.each(data, function (i, v) {
                            if(v.resList.length > 0 && v.resList[0].filePath.length > 0){
                                var picsrc=v.resList[0].filePath.split('http://www.chinatax.gov.cn')[1]
                                var Url = v.url.split('http://www.chinatax.gov.cn')[1]
                                // var picsrc=v.resList[0].filePath
                                var title= ""
                                if(v.title.length <= 30){
                                    title = v.title.slice(0,30)
                                } else {
                                    title = v.title.slice(0,30) + '...'
                                }
                                html+='<div class="swiper-slide"><a href="'+Url+'" target="_blank"><img src="'+picsrc+'" alt=""><p>'+title+'</p></a></div>'
                            }
                        })
                        $('.zcjdvideo .swiper-container .swiper-wrapper').html(html)
                        var wh=$(window).width();
                        if(wh>1366){
                            // 政策解读-视频
                            var zcjdvideoSwiperVideo = new Swiper('.zcjdvideo .swiper-container', {
                                autoplay: 3000,
                                loop: true,
                                slidesPerView : 2,
                                paginationClickable :true,
                                pagination: '.zcjdvideo .pagination'
                            })
                        }else if(wh>1024){
                            // 政策解读-视频
                            var zcjdvideoSwiperVideo = new Swiper('.zcjdvideo .swiper-container', {
                                autoplay: 3000,
                                loop: true,
                                slidesPerView : 2,
                                paginationClickable :true,
                                pagination: '.zcjdvideo .pagination'
                            })
                        }else if(wh>768){
                            // 政策解读-视频
                            var zcjdvideoSwiperVideo = new Swiper('.zcjdvideo .swiper-container', {
                                autoplay: 3000,
                                loop: true,
                                slidesPerView : 2,
                                paginationClickable :true,
                                pagination: '.zcjdvideo .pagination'
                            })
                        }else{
                            
                            // 政策解读-视频
                            var zcjdvideoSwiperVideo = new Swiper('.zcjdvideo .swiper-container', {
                                autoplay: 3000,
                                loop: true,
                                slidesPerView : 1,
                                paginationClickable :true,
                                pagination: '.zcjdvideo .pagination'
                            })
                        }
                    }
                  })
            }
        },
        swiper: function () {
            // 公报
            var wh=$(window).width();
            var gblsitSwiperVideo
            if(wh>1366){
                gblsitSwiperVideo = new Swiper('.gblist .swiper-container', {
                    // autoplay: 3000,
                    loop: true,
                    slidesPerView : 5,
                    slidesPerGroup:5,
                    paginationClickable :true
                })
            } else if(wh>1200){
                gblsitSwiperVideo = new Swiper('.gblist .swiper-container', {
                    // autoplay: 3000,
                    loop: true,
                    slidesPerView : 4,
                    slidesPerGroup:4,
                    paginationClickable :true
                })
            } else if(wh>768){
                gblsitSwiperVideo = new Swiper('.gblist .swiper-container', {
                    // autoplay: 3000,
                    loop: true,
                    slidesPerView : 3,
                    slidesPerGroup:3,
                    paginationClickable :true
                })
            }else{
                gblsitSwiperVideo = new Swiper('.gblist .swiper-container', {
                    // autoplay: 3000,
                    loop: true,
                    slidesPerView : 1,
                    slidesPerGroup:1,
                    paginationClickable :true
                })
            }
            
            $('.arrow-left').on('click',function(){
                gblsitSwiperVideo.swipePrev(); 
            })
            $('.arrow-right').on('click',function(){
                gblsitSwiperVideo.swipeNext(); 
            })

        },
        search:function(){
            var siteCode=$('meta[name="SiteIDCode"]').attr('content')

            // 热搜词
            // $.ajax({
            //     type: "get",
            //     url: "https://zs-test.kaipuyun.cn/guoshui4/ht?siteCode="+siteCode+"&column=全部",
            //     success: function (res) {
            //         var html='<span class="tle">热门关键词：</span>';
            //         $.each(res,function(i,v){
            //             html+='<span class="word">'+v+'</span>'
            //         })
            //         $('.fgkhotWord').html(html)
            //     }
            // });
            // 热搜词跳转
            // $('.fgkhotWord').on('click','span.word',function(){
            //     var word=$(this).text();
            //     var url="/zcfgk/c100028/zcwj.html?siteCode="+siteCode+"&searchWord="+word+"&pageSize=10&pageNum=0&orderBy=4&column=政策法规,政策解读&label=文字政策解读,法律,行政法规及国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件&likeDoc=0&wordPlace=0&indexCode=1"
            //     window.open(url)
            // })
            //普通搜索
            // $('.fkginputsr .nsearch').on('click',function(){
            //     var val=$.trim($('#fgksearch').val());
            //     var type=$('.searchArea p.ar.on').attr('data-id')
            //     if(val!=''){
            //         var url="/zcfgk/c100028/zcwj.shtml?siteCode="+siteCode+"&searchWord="+val+"&type="+type+"&pageSize=10&pageNum=0"
            //         window.open(url)
            //     }else{
            //         alert('请输入你要搜索的内容')
            //     }
            // })

        },
        tap:function(){
            $('.searchArea p').on('click',function(){
                $(this).addClass('on').siblings().removeClass('on');
            })
        },
        zxwj:function(){
            $.ajax({
                type: 'post',
                url: 'https://www.chinatax.gov.cn/getFileListByCodeId',
                data: {
                    "codeId":'' ,
                    "channelId":'29a88b67e4b149cfa9fac7919dfb08a5',
                   //  "metaDataKey":"writtendate",
                    "page":1,
                    "size":4
                },
                success: function (data) {
                    var res = data.results.data
                    var html=""
                    var fwzh=''
                    var y=''
                    var m=''
                    var d=''
                    var urlN=''
                    $.each(res.results,function(i,v){

                        var title_list = v.titleHtml;
                        var tmp = "";
                        for(var i=0;i<title_list.length;i++) {
                            if(title_list.charCodeAt(i) == 32){
                                tmp=tmp+String.fromCharCode(12288);
                            }else if(title_list.charCodeAt(i) < 48){
                                tmp=tmp+String.fromCharCode(title_list.charCodeAt(i)+65248);
                            }else if(title_list.charCodeAt(i) > 57 && title_list.charCodeAt(i) < 127){
                                tmp=tmp+String.fromCharCode(title_list.charCodeAt(i)+65248);
                            }else{
                                tmp= tmp + title_list[i];
                            }
                        }
                        if(tmp.length>61){
                            var str="";
                            str=tmp.substring(0,61)+"...";
                            title_list = str;
                        } else {
                            title_list = tmp;
                        }


                        y=v.domainMetaList[2].resultList[1].value.split('-')[0]
                        m=v.domainMetaList[2].resultList[1].value.split('-')[1]
                        d=v.domainMetaList[2].resultList[1].value.split('-')[2]
                        if(v.channelName=="法规"||v.channelName=="税务部门规章"){
                            fwzh=''
                        }else if(v.channelName=="法律"){
                            y=v.domainMetaList[1].resultList[1].value.split('-')[0]
                            m=v.domainMetaList[1].resultList[1].value.split('-')[1]
                            d=v.domainMetaList[1].resultList[1].value.split('-')[2]
                            fwzh=''
                        }else if(v.channelName=="财税文件"){
                            y=v.domainMetaList[1].resultList[1].value.split('-')[0]
                            m=v.domainMetaList[1].resultList[1].value.split('-')[1]
                            d=v.domainMetaList[1].resultList[1].value.split('-')[2]
                            for(var n=0;n<v.domainMetaList.length;n++){
                             if(v.domainMetaList[n].domainMetadataName == "政策文件信息"){
                                fwzh=v.domainMetaList[n].resultList[6].value;
                             }    
                            }
                            // fwzh=v.domainMetaList[2].resultList[6].value
                        }else if(v.channelName=="行政法规"){
                            fwzh=''
                            y=v.domainMetaList[1].resultList[1].value.split('-')[0]
                            m=v.domainMetaList[1].resultList[1].value.split('-')[1]
                            d=v.domainMetaList[1].resultList[1].value.split('-')[2]
                        }else if(v.channelName=="其他文件"){
                            y=v.domainMetaList[1].resultList[1].value.split('-')[0]
                            m=v.domainMetaList[1].resultList[1].value.split('-')[1]
                            d=v.domainMetaList[1].resultList[1].value.split('-')[2]
                             for(var n=0;n<v.domainMetaList.length;n++){
                             if(v.domainMetaList[n].domainMetadataName == "政策文件信息"){
                                fwzh=v.domainMetaList[n].resultList[6].value;
                             }    
                            }
                            // fwzh=v.domainMetaList[2].resultList[6].value
                        } else if(v.channelName=="工作通知"){
                            y=v.domainMetaList[1].resultList[1].value.split('-')[0]
                            m=v.domainMetaList[1].resultList[1].value.split('-')[1]
                            d=v.domainMetaList[1].resultList[1].value.split('-')[2]
                             for(var n=0;n<v.domainMetaList.length;n++){
                             if(v.domainMetaList[n].domainMetadataName == "政策文件信息"){
                                fwzh=v.domainMetaList[n].resultList[6].value;
                             }    
                            }
                            // fwzh=v.domainMetaList[2].resultList[6].value
                        } else{
                             for(var n=0;n<v.domainMetaList.length;n++){
                             if(v.domainMetaList[n].domainMetadataName == "政策文件信息"){
                                fwzh=v.domainMetaList[n].resultList[6].value;
                             }    
                            }
                            // fwzh=v.domainMetaList[3].resultList[6].value
                        }
                        urlN=v.url.split('http://www.chinatax.gov.cn')[1]
                        if(title_list.length>31){
                            html+='<li class="clearfix" style="margin-top: 10px;margin-bottom: 0;"><a href="'+urlN+'" target="_blank"><div class="time"><span class="day">'+d+'</span><span class="date">'+(y+'-'+m)+'</span></div><div class="zxzctitle"><p class="title"><a href="'+urlN+'" target="_blank">'+ title_list +'</a></p><p class="desc">'+fwzh+'</p></div></a></li>'
                        } else {
                            html+='<li class="clearfix"><a href="'+urlN+'" target="_blank"><div class="time"><span class="day">'+d+'</span><span class="date">'+(y+'-'+m)+'</span></div><div class="zxzctitle"><p class="title"><a href="'+urlN+'" target="_blank">'+ title_list +'</a></p><p class="desc">'+fwzh+'</p></div></a></li>'
                        }
                        
                    })
                    $('.zxzcwjlist').html(html)
                    if($(".zxzcwjlist").height() >= 375){
                        $(".zcdh .zcdhlist li").css({"margin-bottom": "40px"});
                    }else{
                        $(".zcdh .zcdhlist li").css({"margin-bottom": "20px"});
                    }
                }
              })
        },
        indexzcjd:function(){
            $.ajax({
                type: 'post',
                url: 'https://www.chinatax.gov.cn/getFileListByCodeId',
                data: {
                    "codeId":'',
                    "channelId":'70fb5b62948a4e2aa9e89b303e3d9739',
                    // "metaDataKey":"writtendate",
                    "page":1,
                    "size":7
                },
                success: function (data) {
                    var res=data.results.data.results;
                    var html=''
                    var urlN=''
                    $.each(res,function(i,v){
                        urlN=v.url.split('http://www.chinatax.gov.cn')[1]
                        html+='<li><a href="'+urlN+'" target="_blank">'+v.titleHtml+'</a><span class="time">'+v.domainMetaList[1].resultList[1].value+'</span></li>'
                    })
                    $('.characters .charsw ul').html(html)
                }
              })
        }
    }


    fgkIndexJS.init()
})