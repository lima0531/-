from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode,urljoin
from concurrent.futures import ThreadPoolExecutor
import ssl,json,hashlib,datetime,re,html
ROOT=Path('/workspace/purchase_tax_audit/round3/archive/version_search');ROOT.mkdir(exist_ok=True,parents=True)
BASE='https://www.miit.gov.cn/'
def fetch(url,name):
 rec={'requested_url':url,'fetched_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls_verification':True}
 try:
  with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':BASE}),timeout=35,context=ssl.create_default_context()) as r:
   raw=r.read();p=ROOT/name;p.write_bytes(raw); rec.update(status='ok',http_status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type'),content_length_header=r.headers.get('Content-Length'),response_headers=dict(r.headers.items()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),local_path=str(p))
 except Exception as e:rec.update(status='fetch_error',error=f'{type(e).__name__}: {e}')
 (ROOT/(name+'.request.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2));return rec

def search(q,name):
 args={'websiteid':'110000000000000','scope':'basic','cateid':47,'pg':20,'p':1,'pos':'title_text,titlepy,infocontent,filenumbername,keyword,contentdescribe','q':q,'selectFields':'title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode','group':'distinct','level':'6','sortFields':json.dumps([{'name':'deploytime','type':'desc'}],separators=(',',':'))}
 return fetch(BASE+'search-front-server/api/search/info?'+urlencode(args),name)

def flatten_search(v):
 if isinstance(v,dict):
  if isinstance(v.get('title'),str) and v.get('url'):yield v
  for x in v.values():yield from flatten_search(x)
 elif isinstance(v,list):
  for x in v:yield from flatten_search(x)
if __name__=='__main__':
 tasks=[('免征车辆购置税 第二十六批','search26.json'),('免征车辆购置税 第三十五批','search35.json')]
 with ThreadPoolExecutor(max_workers=2) as p:
  for r in p.map(lambda t:search(*t),tasks):print(json.dumps(r,ensure_ascii=False),flush=True)
 url='https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit/n1146285/n1146352/n3054355/n3057585/n3057590/c8091385/part/8093780.wps'
 print(json.dumps(fetch(url,'batch35_complete.wps'),ensure_ascii=False),flush=True)
 results=[]
 for q,n in tasks:
  for v in flatten_search(json.loads((ROOT/n).read_text())):
   results.append({k:v.get(k) for k in ['title','url','deploytime','cdate','publishtime','columnname']})
 unique={v['url']:v for v in results};(ROOT/'search_results_summary.json').write_text(json.dumps(list(unique.values()),ensure_ascii=False,indent=2))
 print(json.dumps(list(unique.values()),ensure_ascii=False),flush=True)
