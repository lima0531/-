#!/usr/bin/env python3
"""Independently enumerate historical withdrawal originals before comparing data.

MS-DOC: checked main-story piece table, original table header and cell-end stride.
OOXML: complete direct XML table rows, named column header and sequence.
XLS: complete xlrd sheet rows, named column header and sequence.
LibreOffice text is a second row/column/numbering check, never a model search.
All source input files are read-only; only this script directory is written.
"""
from pathlib import Path
from collections import Counter, defaultdict, deque
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import csv, hashlib, json, re, sys, unicodedata
import xlrd

ROOT=Path(__file__).resolve().parent
R3=Path('/workspace/purchase_tax_audit/round3')
BASE=R3/'reconstruction/data_v1_3'
ARCHIVE=R3/'archive'
sys.path.insert(0,str(ARCHIVE))
from word_piece_text import extract
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

def norm(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(x))).upper()
def fmt(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',str(x)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows,fields=None):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)

def header_ok(c):
    return len(c) in (5,6) and c[:3]==['序号','企业名称','车辆型号'] and c[3] in ['产品名称','目录发布产品名称'] and c[4] in ['批次','目录批次'] and (len(c)==5 or c[5]=='备注')

def ole_rows(p):
    text,proof=extract(p);tokens=text.split('\t')
    # The first cell includes the document title, so use its last paragraph.
    header0=tokens[0].splitlines()[-1].strip()
    assert header0=='序号',(p.name,header0)
    n=6 if tokens[5].strip()=='备注' else 5
    header=[header0]+[x.strip() for x in tokens[1:n]]
    assert header_ok(header),(p.name,header)
    stride=n+1
    assert tokens[n]=='',(p.name,'missing Word end-of-row cell marker')
    assert not tokens[-1].strip(),(p.name,'unparsed trailing table text')
    assert (len(tokens)-1)%stride==0,(p.name,len(tokens),stride)
    out=[]
    for offset in range(stride,len(tokens)-1,stride):
        cells=tokens[offset:offset+n]
        assert tokens[offset+n]=='',(p.name,offset,'row marker')
        out.append((cells,{'main_story_cell_0based':offset,'original_cell_stride':stride}))
    proof.update(original_header=header,cell_stride=stride,whole_table_rows=len(out),independent_table_enumeration=True)
    return header,out,proof

def celltext(c):
    return '\n'.join(''.join(x.text or '' for x in p.findall('.//w:t',NS)) for p in c.findall('w:p',NS)).strip()

def xml_rows(p):
    with ZipFile(p) as z:
        document=z.read('word/document.xml');tree=ET.fromstring(document)
    out=[];headers=[]
    for ti,table in enumerate(tree.findall('.//w:tbl',NS)):
        rows=table.findall('w:tr',NS);header=[celltext(c) for c in rows[0].findall('w:tc',NS)]
        assert header_ok(header),(p.name,ti,header)
        headers.append(header)
        for ri,row in enumerate(rows[1:],1):
            cells=[celltext(c) for c in row.findall('w:tc',NS)]
            assert len(cells)==len(header),(p.name,ti,ri,cells)
            number=row.find('w:tc/w:p/w:pPr/w:numPr',NS)
            num_id=number.find('w:numId',NS).get('{'+NS['w']+'}val') if number is not None else ''
            out.append((cells,{'table_0based':ti,'row_0based':ri,'xml_member':'word/document.xml','xml_sequence_numId':num_id}))
    assert len(set(tuple(x) for x in headers))==1
    return headers[0],out,{'reader':'direct OOXML table rows; text nodes only','document_xml_sha256':hashlib.sha256(document).hexdigest(),'table_count':len(headers),'original_header':headers[0],'whole_table_rows':len(out),'independent_table_enumeration':True}

def xls_rows(p):
    book=xlrd.open_workbook(p,formatting_info=True);out=[];headers=[]
    for si,sheet in enumerate(book.sheets()):
        found=[]
        for ri in range(sheet.nrows):
            cells=[str(sheet.cell_value(ri,ci)) for ci in range(sheet.ncols)]
            if header_ok(cells):found.append(ri)
        assert len(found)==1,(p.name,si,found)
        start=found[0];header=[str(sheet.cell_value(start,ci)) for ci in range(sheet.ncols)]
        headers.append(header)
        for ri in range(start+1,sheet.nrows):
            cells=[str(sheet.cell_value(ri,ci)) for ci in range(sheet.ncols)]
            if not any(x.strip() for x in cells):continue
            seq=sheet.cell_value(ri,0)
            assert isinstance(seq,(int,float)) and int(seq)==seq,(p.name,si,ri,cells)
            cells[0]=str(int(seq))
            out.append((cells,{'sheet_index_0based':si,'sheet_name':sheet.name,'row_0based':ri,'merged_ranges_count':len(sheet.merged_cells)}))
    assert len(set(tuple(x) for x in headers))==1
    return headers[0],out,{'reader':'xlrd direct sheet/cells, no filtered model lookup','sheet_count':book.nsheets,'original_header':headers[0],'whole_table_rows':len(out),'independent_table_enumeration':True}

def libre_rows(p,header):
    lines=p.read_text(encoding='utf-8-sig').splitlines();out=[];headers=[]
    for ln,line in enumerate(lines,1):
        cells=line.split('\t')
        if cells and cells[0].strip()=='序号':headers.append(cells)
        elif cells and re.fullmatch(r'\s*\d+(?:\.0)?\s*',cells[0]):
            # LO may append a redundant empty cell after a DOC row.
            while len(cells)>len(header) and not cells[-1]:cells.pop()
            assert len(cells)==len(header),(p.name,ln,cells)
            cells[0]=str(int(float(cells[0].strip())))
            out.append((cells,ln))
        elif '\t' in line:
            # XLS title/blank lines have empty cells except for one title cell.
            assert not any(x.strip() for x in cells[1:]),(p.name,ln,'unexpected partial table line',cells)
    assert len(headers)==1 and headers[0]==header,(p.name,headers,header)
    seq=[int(c[0]) for c,_ in out]
    assert seq==list(range(1,len(out)+1)),(p.name,'non-contiguous LibreOffice row numbering')
    return out

semantic=read(BASE/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv')
oldenum=read(BASE/'目录覆盖/9份历史撤销_原件全列枚举3007行.csv')
cohort={r['model_key'] for r in read(BASE/'研究数据/样本成员重建.csv')}
semfiles=defaultdict(list)
for n,r in enumerate(semantic,2):semfiles[r['原件文件']].append((n,r))

sources=[];allrows=[];textdiff=[];fielddiff=[];firmflags=[];membershipdiff=[];sourcepatch=[];repaired=[dict(x) for x in semantic]
for name,previous in semfiles.items():
    p=ARCHIVE/'recovered/历史正式撤销'/name
    expected_hash=previous[0][1]['原件SHA256']
    if not p.exists():
        assert name.startswith('批26_'),name
        recovered_exact=ROOT.parent/'public_gaps/batch26_tax_withdrawal.docx'
        p=recovered_exact if recovered_exact.exists() else ARCHIVE/'version_search/batch26_7368844.docx'
    actual_hash=sha(p)
    exact=actual_hash==expected_hash
    assert exact or name.startswith('批26_'),(name,'same-byte source hash mismatch')
    if p.suffix=='.xls':header,rows,proof=xls_rows(p)
    elif p.read_bytes()[:8]==bytes.fromhex('d0cf11e0a1b11ae1'):header,rows,proof=ole_rows(p)
    else:header,rows,proof=xml_rows(p)
    tx=ARCHIVE/'text'/(name+'.txt') if p.parent.name=='历史正式撤销' else ROOT/(p.stem+'.txt')
    second=libre_rows(tx,header)
    if second:
        assert len(second)==len(rows),(name,len(rows),len(second))
    current=[];firm_context=''
    for ix,(cells,location) in enumerate(rows,1):
        sequence=cells[0].strip()
        if sequence:assert int(sequence)==ix,(name,ix,sequence)
        else:
            assert name.startswith('批18_') or location.get('xml_sequence_numId'),(name,ix,'unexplained missing source number')
        if second:
            secondcells,lineno=second[ix-1]
            assert int(secondcells[0])==ix
            for ci,(a,b) in enumerate(zip(cells[1:],secondcells[1:]),1):
                if a!=b:textdiff.append({'source_file':name,'source_sequence':ix,'column_1based':ci+1,'piece_or_direct_original_value':a,'libreoffice_value':b,'format_only':str(int(fmt(a)==fmt(b))),'libreoffice_line_1based':lineno})
            location.update(libreoffice_text_path=str(tx),libreoffice_line_1based=lineno,sequence_source='LibreOffice renders Word auto-number field' if not sequence else 'original explicit cell plus independent rendered sequence')
        else:location.update(sequence_source='original OOXML explicit cell')
        firm=cells[1]
        if firm.strip():firm_context=firm
        assert firm_context,(name,ix,'firm has no preceding source context')
        model=cells[2];assert model.strip(),(name,ix,'empty model')
        row={'source_file_historic':name,'original_path_used':str(p),'same_bytes_as_historical_source':str(int(exact)),'source_sha256_used':actual_hash,'historical_sha256_expected':expected_hash,'source_sequence':str(ix),'sequence_cell_raw':cells[0],'firm_cell_raw':firm,'firm_context_candidate':firm_context,'firm_text_present_in_this_source_cell':str(int(bool(firm.strip()))),'model_raw':model,'model_key':norm(model),'product_name_raw':cells[3],'original_listing_batch_raw':cells[4],'remarks_raw':cells[5] if len(cells)>5 else '', 'location':json.dumps(location,ensure_ascii=False),'reader':proof['reader'],'in_cohort_3328':str(int(norm(model) in cohort))}
        allrows.append(row);current.append(row)
    # This happens only after a complete source enumeration with all sequence checks.
    expected_enum=[r for r in oldenum if r['source_file']==name]
    miss=Counter(r['model_key'] for r in expected_enum)-Counter(r['model_key'] for r in current)
    extra=Counter(r['model_key'] for r in current)-Counter(r['model_key'] for r in expected_enum)
    for direction,counter in [('missing_from_new',miss),('new_not_in_old',extra)]:
        for model,count in counter.items():membershipdiff.append({'source_file':name,'difference':direction,'model_key':model,'row_count':count})
    # Match occurrence-preserving queues; never suppress duplicate model rows.
    bymodel=defaultdict(deque)
    for n,old in previous:bymodel[old['model_key']].append((n,old))
    for row in current:
        if not bymodel[row['model_key']]:continue
        n,old=bymodel[row['model_key']].popleft()
        for newfield,oldfield in [('model_raw','车辆型号'),('firm_context_candidate','企业名称'),('product_name_raw','目录发布产品名称'),('original_listing_batch_raw','原列入批次')]:
            new=row[newfield];before=old[oldfield]
            if new!=before:
                change={'input_csv_line_1based':n,'source_file':name,'source_sequence':row['source_sequence'],'model_key':row['model_key'],'field':oldfield,'old_value':before,'original_value':new,'format_only':str(int(fmt(new)==fmt(before))),'same_bytes_as_historical_source':row['same_bytes_as_historical_source'],'source_sha256_used':actual_hash,'source_location':row['location']}
                fielddiff.append(change)
                if fmt(new)!=fmt(before):sourcepatch.append(change)
        fromrow=old['企业名是否来自本条'];expected_fromrow='是' if row['firm_text_present_in_this_source_cell']=='1' else '否（沿用上一家）'
        if fromrow!=expected_fromrow:
            firmflags.append({'input_csv_line_1based':n,'source_file':name,'source_sequence':row['source_sequence'],'model_key':row['model_key'],'field':'企业名是否来自本条','old_value':fromrow,'original_firm_cell_raw':row['firm_cell_raw'],'context_candidate':row['firm_context_candidate'],'suggested_precise_value':expected_fromrow,'same_bytes_as_historical_source':row['same_bytes_as_historical_source'],'source_sha256_used':actual_hash,'source_location':row['location'],'classification':'provenance labeling difference; this field means literal text in the original row cell; Word cell merge not legally certified'})
        repair=repaired[n-2]
        repair['企业名是否来自本条']=expected_fromrow
        for newfield,oldfield in [('firm_context_candidate','企业名称'),('product_name_raw','目录发布产品名称')]:
            if fmt(row[newfield])!=fmt(old[oldfield]):repair[oldfield]=row[newfield]
        repair.update(全表核查序号=row['source_sequence'],全表核查原件SHA256=actual_hash,全表核查与历史原件同字节=row['same_bytes_as_historical_source'],企业名原件本格原值=row['firm_cell_raw'],企业名来源标注旧值=fromrow,产品名原件原值=row['product_name_raw'],全表核查原件定位=row['location'],全表核查原件引擎=row['reader'])
    sources.append({'source_file':name,'path_used':str(p),'source_sha256_used':actual_hash,'historical_sha256_expected':expected_hash,'same_bytes_as_historical_source':exact,'source_rows':len(rows),'retained_enum_rows':len(expected_enum),'retained_semantic_rows':len(previous),'source_sequences_checked_contiguous':True,'model_counter_matches':not(miss or extra),'unique_models':len(set(r['model_key'] for r in current)),'cohort_rows':sum(r['in_cohort_3328']=='1' for r in current),'whole_table_proof':proof,'second_engine':{'reader':'existing LibreOffice full table text, independently traversed every numbered line','checked_all_row_cells':True,'rows':len(second)} if second else {'reader':None,'reason':'current official OOXML version independently parsed; exact historical bytes unavailable'}})

assert len(allrows)==3007
write('9份历史撤销_独立全表枚举3007行.csv',allrows)
write('9份历史撤销_逐源结构与覆盖检查.csv',[{k:s[k] for k in ['source_file','source_sha256_used','historical_sha256_expected','same_bytes_as_historical_source','source_rows','retained_enum_rows','retained_semantic_rows','source_sequences_checked_contiguous','model_counter_matches','unique_models','cohort_rows']} for s in sources])
write('原件双引擎逐字段差异.csv',textdiff,['source_file','source_sequence','column_1based','piece_or_direct_original_value','libreoffice_value','format_only','libreoffice_line_1based'])
diff_fields=['input_csv_line_1based','source_file','source_sequence','model_key','field','old_value','original_value','format_only','same_bytes_as_historical_source','source_sha256_used','source_location']
write('全表对语义表_逐字段差异.csv',fielddiff,diff_fields)
write('全表对语义表_内容修订补丁.csv',sourcepatch,diff_fields)
write('企业文字来源标注_逐行精确化候选.csv',firmflags,['input_csv_line_1based','source_file','source_sequence','model_key','field','old_value','original_firm_cell_raw','context_candidate','suggested_precise_value','same_bytes_as_historical_source','source_sha256_used','source_location','classification'])
write('全表型号多重集合差异.csv',membershipdiff,['source_file','difference','model_key','row_count'])
write('正式历史撤销_全表核查修正版3007行.csv',repaired)

# Recheck the separately completed 2-source/2020-row addition, including source bytes,
# complete contiguous numbering, provenance counts and distinct source/model grains.
new=read(R3/'coverage/new_withdrawal_full_enumeration_2020_rows.csv')
newproof=[]
for tag in sorted(set(r['source_tag'] for r in new)):
    rows=[r for r in new if r['source_tag']==tag];p=Path(rows[0]['source_file']);actual=sha(p)
    assert {r['source_sha256'] for r in rows}=={actual}
    assert [int(r['sequence']) for r in rows]==list(range(1,len(rows)+1))
    assert len(set(r['model_key'] for r in rows))==len(rows)
    newproof.append({'source_tag':tag,'source_sha256':actual,'verified_rows':len(rows),'distinct_models':len(set(r['model_key'] for r in rows)),'cohort_models':sum(r['in_cohort_3328']=='1' for r in rows),'scope':'recheck of completed independent full-table enumeration; no new broad audit'})
assert len(new)==2020
limitations=['CFB CLX 提取包含原件主文档完整单元格结束符；对企业合并单元格的实际版式归属不作额外法律身份认证。企业文本来源标注区分本格文字与前文企业上下文。']
if any(not s['same_bytes_as_historical_source'] for s in sources):limitations.insert(0,'第26批同字节历史撤销原件未取得；当前官方OOXML版本的324行内容只能支持内容对账，不能认证旧原件字节身份。')
summary={'historic_source_count':len(sources),'exact_historical_source_count':sum(s['same_bytes_as_historical_source'] for s in sources),'current_official_distinct_byte_versions':sum(not s['same_bytes_as_historical_source'] for s in sources),'historic_full_table_rows':len(allrows),'historic_distinct_source_model_pairs':len(set((r['source_file_historic'],r['model_key']) for r in allrows)),'historic_distinct_models_across_sources':len(set(r['model_key'] for r in allrows)),'model_membership_counter_differences':len(membershipdiff),'semantic_field_exact_differences':len(fielddiff),'semantic_field_format_only_differences':sum(r['format_only']=='1' for r in fielddiff),'semantic_content_repair_fields':len(sourcepatch),'semantic_content_repair_cohort_rows':sum(r['model_key'] in cohort for r in sourcepatch),'firm_provenance_precision_candidates':len(firmflags),'firm_provenance_yes_to_context':sum(r['old_value']=='是' for r in firmflags),'firm_provenance_context_to_explicit':sum(r['old_value']!='是' for r in firmflags),'firm_provenance_precision_candidates_cohort':sum(r['model_key'] in cohort for r in firmflags),'independent_engines_field_differences':len(textdiff),'independent_engines_nonformat_differences':sum(r['format_only']=='0' for r in textdiff),'sources':sources,'new_sources_recheck':newproof,'new_sources_complete_rows':len(new),'inputs_modified':False,'derived_semantic_table_content_repairs':len(sourcepatch),'derived_semantic_table_provenance_flag_repairs':len(firmflags),'research_membership_or_dates_changed':False,'limitations':limitations}
(ROOT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['sources','limitations','new_sources_recheck']},ensure_ascii=False))
