import collect,json,re,html
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
urls=[r['url'] for r in json.loads((collect.ROOT/'search_results_summary.json').read_text()) if '免征车辆购置税的新能源汽车车型目录（第二十六批）'==r['title']]
allrec=[]
with ThreadPoolExecutor(max_workers=2) as ex:
 for r in ex.map(lambda t:collect.fetch(urljoin(collect.BASE,t[1]),f'batch26_page_{t[0]}.html'),enumerate(urls)):
  allrec.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
attachments=[]
for rec in allrec:
 if rec['status']!='ok':continue
 text=Path(rec['local_path']).read_text(errors='replace')
 for href,label in re.findall(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',text,re.I|re.S):
  if not re.search(r'\.(?:docx?|wps|pdf|xlsx?)(?:\?|$)',href,re.I):continue
  label=html.unescape(re.sub('<[^>]+>','',label)).strip();attachments.append({'url':urljoin(rec['final_url'],html.unescape(href)),'label':label,'page_url':rec['final_url'],'page_sha256':rec['sha256']})
(collect.ROOT/'batch26_attachment_discovery.json').write_text(json.dumps(attachments,ensure_ascii=False,indent=2))
print(json.dumps(attachments,ensure_ascii=False,indent=2),flush=True)
