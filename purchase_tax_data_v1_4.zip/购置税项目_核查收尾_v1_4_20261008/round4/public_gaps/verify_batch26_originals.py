from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
from collections import Counter
import csv,json,hashlib,re,unicodedata
ROOT=Path(__file__).parent
INPUT=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def raw(c):return ''.join(c.itertext()).strip()
def key(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s)).upper()
def load(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def save(rows,name):
    with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
targets=[('batch26_tax_catalogue.docx',99034,'de0890335ef3a4f1302a8a0735ec8b6aed52e994e2635db481820060d62248b5'),('batch26_tax_withdrawal.docx',53919,'f210c6a6a1e4f8edd3036f38e7d06b91dda93864667118f2808e7b778a2cb544')]
results={}
for name,n,h in targets:
    p=ROOT/name
    assert len(p.read_bytes())==n and sha(p)==h,name
    with ZipFile(p) as z:
        assert z.testzip() is None
        doc=E.fromstring(z.read('word/document.xml'))
    results[name]={'original_sha256':h,'bytes':n,'historical_exact_bytes_match':True,'zip_crc_pass':True,'parsed_document_xml':True}
    if 'catalogue' in name:
        body=doc.find('w:body',NS);power=None;vehicle=None;selected=[]
        for c in body:
            if c.tag==f"{{{NS['w']}}}p":
                t=key(raw(c))
                if '纯电动汽车' in t:power='BEV'
                elif '插电式混合动力汽车' in t:power='PHEV'
                elif '燃料电池汽车' in t:power='FCEV'
                for v in ['乘用车','客车','货车','专用车']:
                    if t.endswith(v):vehicle=v
            elif c.tag==f"{{{NS['w']}}}tbl" and power=='BEV' and vehicle=='乘用车':selected.append(c)
        assert len(selected)==1
        rows=selected[0].findall('w:tr',NS)
        header=[raw(c) for c in rows[0].findall('w:tc',NS)]
        assert header==['序号','生产企业名称','车辆型号','通用名称','纯电动续驶里程(km)','整车整备质量(kg)','动力蓄电池组总质量(kg)','动力蓄电池组总能量(kWh)','备注']
        fields=['seq_raw','firm_raw','model_raw','trade_name_raw','range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw']
        out=[]
        for ri,row in enumerate(rows[1:],1):
            cells=[raw(c) for c in row.findall('w:tc',NS)];assert len(cells)==9
            d=dict(zip(fields,cells));d.update(model_key=key(d['model_raw']),source_sha256=h,table_0based=0,row_0based=ri);out.append(d)
        assert len(out)==83
        old=[x for x in load(INPUT/'研究数据/参数版本_原值与计算代理.csv') if x['source_sha256']==h]
        lookup={x['model_key']:x for x in old};assert len(lookup)==len(old)
        diffs=[]
        for x in out:
            a=lookup[x['model_key']]
            for f in fields[1:]:
                if a[f]!=x[f]:diffs.append({'model_key':x['model_key'],'field':f,'extracted':x[f],'retained':a[f]})
        results[name].update(scope='BEV passenger table selected by body headings and nine-column header',rows=83,matched_model_counter=Counter(x['model_key'] for x in out)==Counter(x['model_key'] for x in old),raw_field_comparisons=83*8,raw_field_differences=diffs)
        save(out,'batch26_exact_original_bev_passenger_83.csv')
    else:
        tables=doc.findall('.//w:tbl',NS);assert len(tables)==1
        rows=tables[0].findall('w:tr',NS)
        header=[raw(c) for c in rows[0].findall('w:tc',NS)]
        assert header==['序号','企业名称','车辆型号','目录发布产品名称','批次','备注']
        fields=['seq_raw','firm_raw','model_raw','product_name_raw','old_batch_raw','remarks_raw'];out=[]
        for ri,row in enumerate(rows[1:],1):
            cells=[raw(c) for c in row.findall('w:tc',NS)];assert len(cells)==6
            d=dict(zip(fields,cells));d.update(model_key=key(d['model_raw']),source_sha256=h,table_0based=0,row_0based=ri);out.append(d)
        assert len(out)==324
        old=[x for x in load(INPUT/'目录覆盖/正式历史撤销_语义记录修正版3007行.csv') if x['原件SHA256']==h]
        lookup={x['model_key']:x for x in old};assert len(lookup)==len(old)
        diffs=[]
        for x in out:
            a=lookup[x['model_key']]
            for f,oldf in [('firm_raw','企业名称'),('product_name_raw','目录发布产品名称'),('old_batch_raw','原列入批次')]:
                if a[oldf]!=x[f]:diffs.append({'model_key':x['model_key'],'field':f,'extracted':x[f],'retained':a[oldf]})
        normalized_diffs=[d for d in diffs if unicodedata.normalize('NFKC',d['extracted'])!=unicodedata.normalize('NFKC',d['retained'])]
        results[name].update(scope='complete official withdrawal table',rows=324,matched_model_counter=Counter(x['model_key'] for x in out)==Counter(x['model_key'] for x in old),semantic_field_comparisons=324*3,semantic_field_differences=diffs,nfkc_semantic_differences=normalized_diffs,seq_and_remarks_retained_fields_available=False)
        save(out,'batch26_exact_original_withdrawal_324.csv')
(ROOT/'batch26_exact_original_verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
