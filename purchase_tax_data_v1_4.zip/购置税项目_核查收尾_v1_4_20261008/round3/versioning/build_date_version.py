#!/usr/bin/env python3
"""Apply evidenced registered dates to a separate data version, with impact gates.

This is a date repair, not a new configuration identity or eligibility certificate.
Source inputs are never changed. Any scientific/candidate-set change stops the
date-only build and is written to impact_changes.json for further investigation.
"""
import argparse
import collections
import csv
import hashlib
import json
import shutil
from pathlib import Path


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        return reader.fieldnames, list(reader)


def write(path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fingerprint(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def candidates(rows, cutoff):
    possible = [r for r in rows if not r['public_date_lower_bound'] or r['public_date_lower_bound'] <= cutoff]
    certain = [r for r in possible if r['public_date_upper_bound'] <= cutoff]
    required = max((r['public_date_lower_bound'] for r in certain), default='')
    latest = [r for r in possible if min(r['public_date_upper_bound'], cutoff) >= required]
    return latest, certain


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_root', type=Path)
    parser.add_argument('accepted_dates', type=Path)
    parser.add_argument('output_root', type=Path)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    original_hashes = {str(p.relative_to(args.input_root)): fingerprint(p) for p in args.input_root.rglob('*') if p.is_file()}
    _, accepted = read(args.accepted_dates)
    registered = {}
    for r in accepted:
        key = (r['system'], r['source_batch'])
        if key in registered or len(r['publish_date_exact']) != 10 or not r['evidence_file']:
            raise ValueError(f'Invalid or duplicate accepted date: {key}')
        registered[key] = r
    tables, columns = {}, {}
    # Analytical CSVs are delivered as a current separate version. Historical
    # source-fingerprint tables and original validators are not rewritten/copied.
    groups = ['研究数据', '官方技术清单', '目录覆盖', '推荐参数', '参数版本边界', '1991基线']
    for group in groups:
        for path in (args.input_root / group).glob('*.csv'):
            rel = str(path.relative_to(args.input_root))
            columns[rel], tables[rel] = read(path)
    changes, impact = [], []

    def update(rel, row, field, value, evidence='derived_from_updated_sources'):
        if field in row and row[field] != value:
            changes.append({'target_file': rel, 'model_key': row.get('model_key', ''),
                            'row_id': row.get('event_id', row.get('record_id', row.get('cutoff', row.get('month', '')))),
                            'field': field, 'before': row[field], 'after': value, 'evidence_file': evidence})
            row[field] = value

    selectors = [
        ('研究数据/资格事件_重建去重表.csv', 'event_batch', ['publish_date_exact', 'public_date_lower_bound', 'public_date_upper_bound'], 'event_date_basis'),
        ('研究数据/资格事件_逐原件连接.csv', 'source_batch', ['publish_date_exact', 'public_date_lower_bound', 'public_date_upper_bound', 'source_parameter_observation_lower', 'source_parameter_observation_upper'], 'event_date_basis'),
        ('研究数据/参数版本_原值与计算代理.csv', 'source_batch', ['publish_date_exact', 'public_date_lower_bound', 'public_date_upper_bound'], 'date_basis'),
        ('研究数据/原件列入_成员来源长表.csv', 'source_batch', ['public_date_lower_bound', 'public_date_upper_bound'], None),
    ]
    for rel, batch_field, date_fields, basis_field in selectors:
        for row in tables[rel]:
            evidence = registered.get((row['system'], row[batch_field]))
            if evidence is None or row.get('effective_date_exception') == '1':
                continue
            for field in date_fields:
                update(rel, row, field, evidence['publish_date_exact'], evidence['evidence_file'])
            if basis_field:
                update(rel, row, basis_field, '当前主管部门明示登记公开日；不认证全球最早上线时间', evidence['evidence_file'])

    # Historical withdrawal filenames can differ from the actual announcement
    # batch. Use the explicit semantic batch, never the filename's number.
    rel = '目录覆盖/正式历史撤销_语义记录修正版3007行.csv'
    for row in tables[rel]:
        evidence = registered.get(('免征目录', row['撤销公告批次']))
        if evidence is None:
            continue
        for field in ['撤销事件日', '撤销观察日']:
            update(rel, row, field, evidence['publish_date_exact'], evidence['evidence_file'])
        for field, value in [('publish_date_is_verified', '1'),
                             ('date_basis', '当前主管部门明示登记公开日；不认证全球最早上线时间'),
                             ('publish_date_source_url', evidence['source_url']),
                             ('撤销日期口径', '主管部门明示登记公开日；不认证全球最早上线或法定生效日')]:
            update(rel, row, field, value, evidence['evidence_file'])

    events_by_model = collections.defaultdict(list)
    for row in tables['研究数据/资格事件_重建去重表.csv']:
        events_by_model[row['model_key']].append(row)
    params_by_model = collections.defaultdict(list)
    for row in tables['研究数据/参数版本_原值与计算代理.csv']:
        if row['admitted_to_analysis_cohort'] == '1':
            params_by_model[row['model_key']].append(row)

    def gate(rel, row, field, expected):
        if row[field] != expected:
            impact.append({'file': rel, 'model_key': row['model_key'], 'time': row.get('cutoff', row.get('month', '')),
                           'field': field, 'old': row[field], 'recomputed': expected})

    # All 36 month ends plus three policy snapshots, not just rows known affected.
    for rel, cutoff_col in [('研究数据/车型月度面板_2022至2024.csv', 'month_end'), ('研究数据/重建样本_三截点状态.csv', 'cutoff')]:
        for row in tables[rel]:
            latest, certain = candidates(events_by_model[row['model_key']], row[cutoff_col])
            ids = '|'.join(sorted(r['event_id'] for r in latest))
            gate(rel, row, 'possible_last_event_ids', ids)
            actions = {r['action'] for r in latest}
            if not certain:
                actions.add('未观察到列入')
            if actions == {'列入'}:
                state, active, robust = '在册（区间口径下的已收集事件）', '1', '1'
            elif actions == {'撤销'}:
                state, active, robust = '已撤销（区间口径下的已收集事件）', '0', '1'
            elif actions == {'未观察到列入'}:
                state, active, robust = '未列入（已收集记录范围）', '0', '1'
            else:
                state, active, robust = '日期区间导致状态不确定', '', '0'
            for field, value in [('state', state), ('catalogue_active_observed', active), ('state_robust_under_date_bounds', robust)]:
                gate(rel, row, field, value)
            dates = {r['publish_date_exact'] for r in latest}
            update(rel, row, 'last_event_exact_date', next(iter(dates)) if len(dates) == 1 else '')
            if cutoff_col == 'cutoff':
                gate(rel, row, 'certain_observed_event_count', str(len(certain)))
                gate(rel, row, 'potential_event_count', str(len(latest)))

    rel = '研究数据/重建样本_两截点参数与暴露.csv'
    for row in tables[rel]:
        latest, _ = candidates(params_by_model[row['model_key']], row['cutoff'])
        gate(rel, row, 'possible_latest_record_ids', '|'.join(sorted(r['record_id'] for r in latest)))
        gate(rel, row, 'possible_latest_record_count', str(len(latest)))
        observed = bool(latest) and all(r['public_date_upper_bound'] <= row['cutoff'] for r in latest)
        gate(rel, row, 'all_possible_latest_observed_before_cutoff', str(int(observed)))
        for field in ['range_point', 'curb_mass_point', 'battery_mass_point', 'battery_energy_point', 'density_proxy_point']:
            values = {r[field] for r in latest}
            gate(rel, row, field, next(iter(values)) if observed and len(values) == 1 else '')
        update(rel, row, 'possible_date_lower_min', min((r['public_date_lower_bound'] or '0001-01-01' for r in latest), default=''))
        update(rel, row, 'possible_date_upper_max', max((r['public_date_upper_bound'] for r in latest), default=''))
    rel = '研究数据/车型月度面板_2022至2024.csv'
    for row in tables[rel]:
        latest, _ = candidates(params_by_model[row['model_key']], row['month_end'])
        gate(rel, row, 'parameter_possible_latest_ids', '|'.join(sorted(r['record_id'] for r in latest)))
        update(rel, row, 'parameter_latest_upper', max((r['public_date_upper_bound'] for r in latest), default=''))

    pre_parameters = {r['model_key']: r for r in tables['研究数据/重建样本_两截点参数与暴露.csv'] if r['cutoff'] == '2023-12-10'}
    rel = '研究数据/公告前风险集_连续处理强度输入.csv'
    for row in tables[rel]:
        update(rel, row, 'exposure_max_observation_upper', pre_parameters[row['model_key']]['possible_date_upper_max'])

    after_hashes = {str(p.relative_to(args.input_root)): fingerprint(p) for p in args.input_root.rglob('*') if p.is_file()}
    if after_hashes != original_hashes:
        raise RuntimeError('Original inputs changed during version build')
    (args.output_root / 'impact_changes.json').write_text(json.dumps(impact, ensure_ascii=False, indent=2))
    if impact:
        raise RuntimeError(f'{len(impact)} non-metadata impacts require investigation; date-only release stopped')
    data = args.output_root / 'data_v1_2'
    for rel, rows in tables.items():
        if any(r['target_file'] == rel for r in changes):
            write(data / rel, columns[rel], rows)
        else:
            (data / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(args.input_root / rel, data / rel)
    write(args.output_root / '日期版本_实际字段更新.csv', list(changes[0]) if changes else ['target_file', 'model_key', 'row_id', 'field', 'before', 'after', 'evidence_file'], changes)
    manifest = []
    for rel in tables:
        manifest.append({'relative_path': rel, 'input_sha256': original_hashes[rel], 'v1_2_sha256': fingerprint(data/rel),
                         'rows': len(tables[rel]), 'field_updates': sum(r['target_file'] == rel for r in changes)})
    write(args.output_root / 'data_version_manifest.csv', list(manifest[0]), manifest)
    summary = {'accepted_date_batches': len(registered), 'accepted_dates': accepted, 'csv_files': len(tables),
               'field_updates': len(changes), 'non_metadata_impacts': len(impact),
               'input_unchanged_files': len(original_hashes), 'original_inputs_modified': False,
               'state_rows_recomputed': len(tables['研究数据/车型月度面板_2022至2024.csv']) + len(tables['研究数据/重建样本_三截点状态.csv']),
               'two_cutoff_parameter_rows_recomputed': len(tables['研究数据/重建样本_两截点参数与暴露.csv']),
               'limits': 'Retains cohort, science values and certification flags. Completeness of public sources and individual vehicle qualification are separate evidence questions.'}
    (args.output_root/'date_version_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='accepted_dates'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
