import urllib.request,urllib.parse,json,pathlib,concurrent.futures,datetime,hashlib
OUT=pathlib.Path(__file__).parent
BASE='https://www.miit.gov.cn/search-front-server/api/search/info'
HEADERS={'User-Agent':'Mozilla/5.0','Referer':'https://www.miit.gov.cn/search/'}
def query(name,q,begin='',end='',pos='title_text,titlepy,infocontent,filenumbername,keyword,contentdescribe',p='1'):
 params=dict(websiteid='110000000000000',scope='basic',q=q,pg='40',p=p,cateid='47',pos=pos,pq='',oq='',eq='',begin=begin,end=end,dateField='deploytime',selectFields='title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode',group='distinct',highlightConfigs='[{"field":"infocontent","numberOfFragments":2,"fragmentOffset":0,"fragmentSize":110,"noMatchSize":110}]',highlightFields='title_text,infocontent,webid',level='6',sortFields='[{"name":"deploytime","type":"desc"}]',hidCol='fbafd13557fa453d9c59432567d2b150')
 url=BASE+'?'+urllib.parse.urlencode(params)
 try:
  resp=urllib.request.urlopen(urllib.request.Request(url,headers=HEADERS),timeout=35);raw=resp.read();(OUT/(name+'.json')).write_bytes(raw);(OUT/(name+'.url.txt')).write_text(url+'\n',encoding='utf8')
  j=json.loads(raw);r=j['data']['searchResult'];print(name,'total',r['total'],flush=True)
  found=[]
  def walk(x):
   if isinstance(x,dict):
    if 'title' in x and 'url' in x:
     row={k:x.get(k) for k in ['title','url','deploytime','publishtime','cdate','columnname']};found.append(row)
    for v in x.values():walk(v)
   elif isinstance(x,list):
    for v in x:walk(v)
  walk(r['dataResults']);(OUT/(name+'_hits.json')).write_text(json.dumps(found,ensure_ascii=False,indent=2),encoding='utf8')
  for f in found:print(name,json.dumps(f,ensure_ascii=False),flush=True)
 except Exception as e:print(name,type(e).__name__,str(e),flush=True)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  list(ex.map(lambda args:query(*args),[('search_2014','免征车辆购置税','2014-01-01','2014-12-31'),('search_2016','免征车辆购置税','2016-01-01','2016-12-31'),('search_2017','免征车辆购置税','2017-01-01','2018-01-19')]))
