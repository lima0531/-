from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,json,re,html,ssl
ROOT=Path(__file__).parent/'completed_primary';ROOT.mkdir(exist_ok=True)
PAGES={
'batch9_announcement':'/zwgk/zcwj/wjfb/gg/art/2020/art_0d2491acc4a149c39d94f0995e065ce5.html',
'batch9_department':'/jgsj/zbys/wjfb/art/2020/art_6f337cc692794f7f92a9ab2b89b469bc.html',
'batch15_announcement':'/zwgk/zcwj/wjfb/gg/art/2020/art_f2dc8105eaa2477c8889cf41df461d54.html',
'batch15_department':'/jgsj/zbys/wjfb/art/2020/art_f837460b72aa497bbfdacc8e62edb0a6.html',
'batch20_announcement':'/zwgk/zcwj/wjfb/gg/art/2020/art_62c81fa8bf2743fe977f78d9ef5498db.html',
'batch20_department':'/jgsj/zbys/wjfb/art/2020/art_e7d52d50be844ead9f346d060ec1a4b0.html',
}
def fetch(kv):
 name,path=kv;url=urljoin('https://www.miit.gov.cn/',path);f=ROOT/(name+'.html');rec={'source_url':url,'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tls_verified':True}
 if f.exists():raw=f.read_bytes();rec['cached']=True
 else:
  try:
   with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.miit.gov.cn/search/'}),context=ssl.create_default_context(),timeout=30) as r:raw=r.read();rec.update(http_status=r.status,final_url=r.url)
   f.write_bytes(raw)
  except Exception as e:rec['error']=str(e);print(rec,flush=True);return rec
 text=raw.decode('utf8','replace');rec.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),evidence_file=str(f))
 rec['date_evidence']=[{'line':i,'raw':s.strip()} for i,s in enumerate(text.splitlines(),1) if any(x in s for x in ['PubDate','MakeTime','成文日期','发布日期','id="con_time"'])]
 rec['attachments']=[{'url':urljoin(url,a[1]),'title':html.unescape(re.sub('<[^>]*>','',a[2]))} for a in re.finditer(r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',text,re.S|re.I) if any(x in a[1].lower() for x in ['.doc','.pdf','.xls','.wps'])]
 (ROOT/(name+'.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2));print(json.dumps(rec,ensure_ascii=False),flush=True);return rec
if __name__=='__main__':list(ThreadPoolExecutor(max_workers=3).map(fetch,PAGES.items()))
