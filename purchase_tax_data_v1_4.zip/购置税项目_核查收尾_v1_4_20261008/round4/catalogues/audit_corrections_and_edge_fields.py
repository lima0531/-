#!/usr/bin/env python3
"""Audit publicly attached corrections and two conservative numeric-parse cases.
Companion correction metadata are dated observations, never new qualification
listing events. No original input or derived data version is modified.
"""
from pathlib import Path
import csv,hashlib,json,re,sys,zipfile,xml.etree.ElementTree as ET
import fitz
sys.path.insert(0,'/workspace/purchase_tax_audit/round4/catalogues')
import independent_catalogue_tables as m
R3=m.R3;OUT=m.OUT;DATA=R3/'reconstruction/data_v1_3'
params=m.read_csv(DATA/'研究数据/参数版本_原值与计算代理.csv')
independent=m.read_csv(OUT/'独立原件_纯电动乘用车逐表参数.csv')
manifest=m.read_csv(R3/'archive/106原件公开回收清单.csv')
dates=m.read_csv(R3/'dates/97批次日期_本轮官方登记补采更新.csv')
proofs=json.loads((OUT/'extraction_proofs.json').read_text())
correction_notes=[];text_sources={}
for s in manifest:
 if s['scope']!='目录' or s['recovery_status']!='sha256_exact':continue
 p=Path(s['recovered_path']);b=p.read_bytes()
 if b[:2]==b'\xd0\xcf':t,_=m.word_text(p)
 elif b[:2]==b'PK':
  root=ET.fromstring(zipfile.ZipFile(p).read('word/document.xml'));t='\n'.join(''.join(x.text or '' for x in el.iterfind('.//w:t',m.NS)) for el in root.find('w:body',m.NS))
 elif b[:4]==b'%PDF':t='\n'.join(p.get_text() for p in fitz.open(p))
 else:continue
 text_sources[s['source_file']]=t
 for match in re.finditer(r'勘\s*误|更\s*正',t):
  start=match.start();end=t.find('\n',match.end())
  # A stand-alone correction heading introduces a complete appendix.
  if end<0:end=len(t)
  note=t[start:end].strip()
  if not re.sub(r'\s','',note).strip('：:') or re.fullmatch(r'勘\s*误',note):note=t[start:min(len(t),start+1500)]
  source_batch=str(int(re.search(r'batch(\d+)',s['source_file']).group(1)))
  date=next(x for x in dates if x['system']==s['system'] and x['batch']==source_batch)
  correction_notes.append({'source_file':s['source_file'],'source_sha256':s['source_sha256'],'observed_public_date':date['publish_date_exact'],'page_url':date['source_url'],'source_text_start_char':start,'correction_text_raw':note,'in_BEV_passenger_scope':int('一、纯电动汽车' in note and '乘用车' in note or s['source_file']=='mf_batch40.doc')})
m.write_csv(OUT/'目录内全部勘误_公开原文扫描.csv',correction_notes)
# Explicit source note declares five BEV passenger trade-name corrections.
name_corrections=[];overlay=[]
cat7=next(s for s in manifest if s['source_file']=='cat_batch7.doc')
cat7_date=next(x for x in dates if x['system']=='减免目录' and x['batch']=='7')
page_receipt=next(json.loads(p.read_text()) for p in (R3/'archive/receipts').glob('*.json') if cat7_date['source_url'] in p.read_text() and json.loads(p.read_text()).get('kind')=='page')
html=Path(page_receipt['local_path']).read_text()
visible=re.search('发布日期：</span><span[^>]*>([^<]+)',html).group(1)
if visible!=cat7_date['publish_date_exact']:raise ValueError('cat7 visible registration date differs')
for note in correction_notes:
 if note['source_file']!='cat_batch7.doc' or not note['in_BEV_passenger_scope']:continue
 kind='重申报汇总' if '汇总' in note['correction_text_raw'] else '目录列入'
 for match in re.finditer(r'第(\d+)条，([^；。]*?)([A-Z][A-Z0-9-]+)的通用名称应为“([^”]+)”',note['correction_text_raw']):
  seq,firm,model,corrected=match.groups()
  originals=[x for x in independent if x['source_file']=='cat_batch6.doc' and x['kind']==kind and x['model_key']==model]
  targets=[x for x in params if x['source_file'].endswith('/cat_batch6.doc') and x['observation_kind']==kind and x['model_key']==model]
  if len(originals)!=1 or len(targets)!=1:raise ValueError('Cat6 correction target not unique '+model)
  original=originals[0];target=targets[0]
  if original['sequence_raw']!=seq:raise ValueError('Cat6 original sequence mismatch '+model)
  row={'model_key':model,'original_record_id':target['record_id'],'original_source_file':target['source_file'],'original_source_sha256':target['source_sha256'],'original_kind':kind,'original_sequence_raw':seq,'original_trade_name_raw':original['trade_name_raw'],'retained_trade_name_raw':target['trade_name_raw'],'corrected_trade_name_observed':corrected,'correction_observed_date':visible,'correction_source_file':'cat_batch7.doc','correction_source_sha256':cat7['source_sha256'],'correction_page_url':cat7_date['source_url'],'correction_page_sha256':page_receipt['sha256'],'correction_page_meta_pubdate':re.search(r'name="PubDate" content="([^"]+)"',html).group(1),'correction_text_raw':note['correction_text_raw'],'numerical_or_qualification_event_change':0,'decision':'Save as dated trade-name companion; four scientific fields and qualification events unchanged; no configuration identity inferred'}
  name_corrections.append(row)
  overlay.append({'record_id':target['record_id'],'source_file':target['source_file'],'model_key':model,'field':'trade_name_raw','old_value':target['trade_name_raw'],'new_value':corrected,'observed_date':visible,'evidence_source_file':'cat_batch7.doc','evidence_sha256':cat7['source_sha256'],'apply_as':'dated correction companion, preserve historic raw name'})
if len(name_corrections)!=5:raise ValueError('BEV passenger name corrections not exactly 5')
m.write_csv(OUT/'第7批公开名称勘误_逐条核原第6批.csv',name_corrections)
# The complete-grid correction has an existing stored record; recover missing name metadata.
full=next(x for x in independent if x['source_file']=='mf_batch40.doc' and x['kind']=='完整表格勘误')
full_old=next(x for x in params if x['source_file'].endswith('/mf_batch40.doc') and x['observation_kind']=='完整表格勘误')
if full_old['model_key']!=full['model_key']:raise ValueError('Grid correction model mismatch')
for field in ['range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw','remarks_raw']:
 if m.norm(full_old[field])!=m.norm(full[field]):raise ValueError('Grid correction scientific-field mismatch')
overlay.append({'record_id':full_old['record_id'],'source_file':full_old['source_file'],'model_key':full['model_key'],'field':'trade_name_raw','old_value':full_old['trade_name_raw'],'new_value':full['trade_name_raw'],'observed_date':full_old['publish_date_exact'],'evidence_source_file':'mf_batch40.doc','evidence_sha256':full['source_sha256'],'apply_as':'fill missing metadata of same existing correction record'})
m.write_csv(OUT/'名称元数据_证据覆盖候选层.csv',overlay)
# Literal original values and header mappings for conservative parse cases.
edge=[]
for name,model,field in [('mf_batch51.doc','YGM7002BEVB4','battery_mass_raw'),('mf_batch57.doc','MR7001BEV18','range_raw')]:
 row=next(x for x in independent if x['source_file']==name and x['model_key']==model)
 old=next(x for x in params if x['source_file'].endswith('/'+name) and x['model_key']==model)
 if row[field]!=old[field]:raise ValueError('Edge field changed between source and retained record')
 tab=proofs[name]['tables'][0]
 edge.append({'record_id':old['record_id'],'source_file':name,'source_sha256':row['source_sha256'],'model_key':model,'field':field,'source_field_raw':row[field],'retained_field_raw':old[field],'header_raw':tab['header_raw'],'header_column_map':tab['header_columns'],'independent_row':row,'interpretation_boundary':'Source literal confirmed, including chemistry text or missing opening CLTC parenthesis. Does not prove a single matching configuration; no point-value substitution here.'})
(OUT/'保守解析两型号_原件表头与原值证据.json').write_text(json.dumps(edge,ensure_ascii=False,indent=2))
counts={}
for name in ['mf_batch01.pdf','mf_batch64.doc']:
 counts[name]={'parameter_rows':sum(x['source_file'].endswith('/'+name) for x in params),'records':[{k:x[k] for k in ['record_id','model_key','observation_kind']} for x in params if x['source_file'].endswith('/'+name)]}
summary={'all_public_correction_text_occurrences':len(correction_notes),'BEV_passenger_name_corrections':len(name_corrections),'missing_grid_correction_name_metadata':1,'source_parameter_edge_fields_verified':len(edge),'scientific_or_qualification_change_from_6_name_metadata_candidates':0,'cat7_visible_public_registration_date':visible,'cat7_page_metadata_conflict_retained':visible not in re.search(r'name="PubDate" content="([^"]+)"',html).group(1),'unrecovered_catalogue_parameter_rows':counts,'point_value_fill_applied':False,'original_or_v1_3_mutated':False}
(OUT/'corrections_and_edge_fields_result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='unrecovered_catalogue_parameter_rows'},ensure_ascii=False))
