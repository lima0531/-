function mainframe_search() {
    $('#jsearch-no-result-box').hide();
    var $mainframe = $('#jsearch-plugin-mainframe');
    $mainframe.html("");
    var q = $('#q').val();
    var webid = $('#webid').val();
    var data = "q=" + encodeURIComponent($("#q").val()) + "&websiteid=" + encodeURIComponent(webid) + "&searchid=" + encodeURIComponent($('#input-searchid').val());
    var p = $('#p').val();
    ajaxGet("../../"+$('#search-form').data('path')+"api/search/mainframe", {
        type: 'json',
        data: data,
        success: function (result) {
            if (result && result.data && result.data.searchResult && result.data.searchResult.dataResults) {
                var res = result.data.searchResult.dataResults;
                for (var i = 0; i < res.length; i++) {
                    var mainframhtml = '<div class="mainframcontent"><a href="' + res[i].data.url + '">' + res[i].data.title + '</a></div>';
                    $mainframe.append(mainframhtml);
                }
                $('.ui-noresult-box').hide();
                $mainframe.show();
                $('#jsearch-no-result-box').hide();
            } else {
                $mainframe.hide();
            }
        }
    })
}

function catemainframe() {
    $('#jsearch-no-result-box').hide();
    var $mainframe = $('#jsearch-plugin-mainframe');
    $mainframe.html("");
    var q = $('#q').val();
    var webid = $('#webid').val();
    var data = "q=" + encodeURIComponent($("#q").val()) + "&websiteid=" + encodeURIComponent(webid) + "&cateid=" + encodeURIComponent($('#cateid').val());
    var p = $('#p').val();
    ajaxGet("../../"+$('#search-form').data('path')+"api/search/mainframe", {
        type: 'json',
        data: data,
        success: function (result) {
            if (result && result.data && result.data.searchResult && result.data.searchResult.dataResults) {
                var res = result.data.searchResult.dataResults;
                for (var i = 0; i < res.length; i++) {
                    var mainframhtml = '<div class="mainframcontent"><a href="' + res[i].data.url + '">' + res[i].data.title + '</a></div>';
                    $mainframe.append(mainframhtml);
                }
                $('.ui-noresult-box').hide();
                $mainframe.show();
                $('#jsearch-no-result-box').hide();
            } else {
                $mainframe.hide();
            }
        }
    })
}