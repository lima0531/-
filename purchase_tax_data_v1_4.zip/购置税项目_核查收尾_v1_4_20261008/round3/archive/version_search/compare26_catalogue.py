from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
from collections import Counter
import csv,json,hashlib,unicodedata,re
ROOT=Path('/workspace/purchase_tax_audit/round3/archive/version_search')
INPUT=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
SOURCE=ROOT/'batch26_7368842.wps';DERIVED=ROOT/'derived/batch26_7368842.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with ZipFile(DERIVED) as z:r=E.fromstring(z.read('word/document.xml'))
def rawtext(c):return ''.join(c.itertext()).strip()
def key(x):return re.sub(r'\s+','',unicodedata.normalize('NFKC',x)).upper()
body=r.find('w:body',ns);power=None;class_=None;selected=[]
for ch in body:
 if ch.tag==f"{{{ns['w']}}}p":
  t=key(rawtext(ch))
  if t=='纯电动汽车':power='BEV'
  elif t=='插电式混合动力汽车':power='PHEV'
  elif t=='燃料电池汽车':power='FCEV'
  if '乘用车' in t:class_='乘用车'
  elif any(t.endswith(x) for x in ['客车','货车','专用车']):class_=next(x for x in ['客车','货车','专用车'] if t.endswith(x))
 if ch.tag==f"{{{ns['w']}}}tbl" and power=='BEV' and class_=='乘用车':selected.append(ch)
assert len(selected)==1,len(selected)
t=selected[0];rows=t.findall('w:tr',ns)
head=[rawtext(c) for c in rows[0].findall('w:tc',ns)]
assert head==['序号','生产企业名称','车辆型号','通用名称','纯电动续驶里程(km)','整车整备质量(kg)','动力蓄电池组总质量(kg)','动力蓄电池组总能量(kWh)','备注'],head
mapping={1:'firm_raw',2:'model_raw',3:'trade_name_raw',4:'range_raw',5:'curb_mass_raw',6:'battery_mass_raw',7:'battery_energy_raw',8:'remarks_raw'}
out=[]
for ri,row in enumerate(rows[1:],1):
 cells=[rawtext(c) for c in row.findall('w:tc',ns)];assert len(cells)==9,(ri,cells)
 o={field:cells[col] for col,field in mapping.items()};o.update(model_key=key(o['model_raw']),table_0based=0,row_0based=ri,system='免征目录',kind='目录列入',power=power,vehicle_class=class_,source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),derived_sha256=hashlib.sha256(DERIVED.read_bytes()).hexdigest());out.append(o)
with (ROOT/'batch26_current_official_bev_passenger_83.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
oldenum=list(csv.DictReader((INPUT/'目录覆盖/原件逐表独立枚举.csv').open(encoding='utf-8-sig')))
oldenum=[o for o in oldenum if o['source_sha256']=='de0890335ef3a4f1302a8a0735ec8b6aed52e994e2635db481820060d62248b5']
oldparam=list(csv.DictReader((INPUT/'研究数据/参数版本_原值与计算代理.csv').open(encoding='utf-8-sig')))
oldparam=[o for o in oldparam if o['source_sha256']=='de0890335ef3a4f1302a8a0735ec8b6aed52e994e2635db481820060d62248b5']
miss=Counter(o['model_key'] for o in oldenum)-Counter(o['model_key'] for o in out)
extra=Counter(o['model_key'] for o in out)-Counter(o['model_key'] for o in oldenum)
assert len({o['model_key'] for o in out})==len(out)
assert len({o['model_key'] for o in oldparam})==len(oldparam)
lookup={o['model_key']:o for o in oldparam};diff=[];compared=0
for o in out:
 a=lookup.get(o['model_key'])
 if not a:continue
 for field in mapping.values():
  compared+=1
  if o[field]!=a[field]:diff.append({'model_key':o['model_key'],'field':field,'current_raw':o[field],'historical_raw':a[field]})
numeric_fields=['range_raw','curb_mass_raw','battery_mass_raw','battery_energy_raw']
numdiff=[d for d in diff if d['field'] in numeric_fields]
normalized_diff=[d for d in diff if unicodedata.normalize('NFKC',d['current_raw'])!=unicodedata.normalize('NFKC',d['historical_raw'])]
firmcontext=[];lastfirm=''
for o in out:
 if o['firm_raw']:lastfirm=o['firm_raw']
 a=lookup.get(o['model_key'])
 if a and lastfirm!=a['firm_context_candidate']:firmcontext.append({'model_key':o['model_key'],'current_table_firm_context':lastfirm,'historical_firm_context_candidate':a['firm_context_candidate']})
result={'source_url' :'https://www.miit.gov.cn/cms_files/filemanager/oldfile/miit/n1146295/n1652858/n1652930/n4509607/c7368799/part/7368842.wps','current_original_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'historical_target_sha256':'de0890335ef3a4f1302a8a0735ec8b6aed52e994e2635db481820060d62248b5','conversion':'LibreOffice headless Office Open XML Text export, isolated task profile; converted DOCX is a derived file, not original historical bytes','derived_sha256':hashlib.sha256(DERIVED.read_bytes()).hexdigest(),'scope':'BEV passenger table only, selected by original body order and headings, exact 9-column header alignment','current_rows':len(out),'historical_enum_rows':len(oldenum),'historical_parameter_rows':len(oldparam),'model_counter_missing':dict(miss),'model_counter_extra':dict(extra),'matched_model_membership':not(miss or extra),'compared_raw_columns':list(mapping.values()),'raw_field_comparisons':compared,'raw_field_differences':diff,'numeric_raw_field_comparisons':len(out)*len(numeric_fields),'numeric_raw_field_differences':numdiff,'nfkc_raw_field_differences':normalized_diff,'table_firm_context_differences':firmcontext,'version_status':'distinct original format and bytes; historical target not recovered; official current BEV passenger content compared with retained historical evidence'}
(ROOT/'batch26_current_vs_historical_catalogue_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
