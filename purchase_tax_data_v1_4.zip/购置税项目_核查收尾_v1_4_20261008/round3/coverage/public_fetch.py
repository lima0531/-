"""Save public HTTPS responses with provenance; TLS verification remains enabled."""
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent


def fetch(name, url, suffix='.bin', data=None):
    if not url.startswith('https://'):
        raise ValueError('HTTPS public sources required')
    raw = ROOT / 'raw'
    raw.mkdir(exist_ok=True)
    record = {'name': name, 'requested_url': url,
              'retrieved_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'method': 'POST' if data is not None else 'GET', 'tls_verification': True}
    if data is not None:
        record['request_data_utf8'] = data.decode('utf-8')
    body = b''
    request = urllib.request.Request(url, data=data, headers={
        'User-Agent': 'Mozilla/5.0', 'Accept': '*/*',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'})
    try:
        with urllib.request.urlopen(request, timeout=22) as response:
            body = response.read()
            record.update({'status': response.status, 'final_url': response.url,
                           'content_type': response.headers.get('Content-Type', '')})
    except urllib.error.HTTPError as error:
        body = error.read()
        record.update({'status': error.code, 'error': str(error)})
    except Exception as error:
        record.update({'error': str(error)})
    record.update({'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    (raw / (name + suffix)).write_bytes(body)
    (raw / (name + '.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False), flush=True)
    return record, body
