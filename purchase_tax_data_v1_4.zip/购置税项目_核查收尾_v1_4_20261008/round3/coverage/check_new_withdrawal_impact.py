"""Independently verify the effect of newly found withdrawals on the fixed cohort.
This is a companion calculation, not a mutation of the supplied panel.
"""
import csv,json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/purchase_tax_audit/compact_input_20261008/购置税项目_必要数据精简包_20261008')
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(name,rows):
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
new=read(ROOT/'new_withdrawal_events.csv'); added={e['model_key']:e for e in new}; old=read(BASE/'研究数据/资格事件_重建去重表.csv')
by=collections.defaultdict(list)
for e in old+new:by[e['model_key']].append(e)
# For these 73 every event interval is certainly before every study month/cutoff;
# later-than ordering is strict and verified from bounds, so maximum upper date
# selects the unique possible latest event without assuming the original panel state.
def last(key,cutoff):
 es=by[key];assert all(e['public_date_upper_bound']<=cutoff for e in es)
 latest=max(es,key=lambda e:e['public_date_upper_bound'])
 assert all(e is latest or e['public_date_upper_bound']<latest['public_date_lower_bound'] for e in es)
 assert latest['action']=='撤销';return latest
panel=read(BASE/'研究数据/车型月度面板_2022至2024.csv'); snapshots=read(BASE/'研究数据/重建样本_三截点状态.csv');risk=read(BASE/'研究数据/公告前风险集_连续处理强度输入.csv'); layer=read(BASE/'官方技术清单/五档数值层_逐型号归属与判据2877行.csv');official={r['model_key'] for r in read(BASE/'官方技术清单/官方不符合技术要求_全表4160行.csv')}
monthly=[]
for r in panel:
 if r['model_key'] not in added:continue
 e=last(r['model_key'],r['month_end']); assert r['catalogue_active_observed']=='1' and r['explicit_withdrawal_observed_cumulative']=='0'
 monthly.append({'model_key':r['model_key'],'month':r['month'],'month_end':r['month_end'],'old_state':r['state'],'new_state':'已撤销（区间口径下的已收集事件）','old_active':r['catalogue_active_observed'],'new_active':'0','old_withdrawal_cumulative':r['explicit_withdrawal_observed_cumulative'],'new_withdrawal_cumulative':'1','new_possible_latest_event_id':e['event_id'],'new_last_event_registered_public_date':e['publish_date_exact'],'old_numeric_did_ready':r['descriptive_continuous_did_input_ready'],'new_numeric_did_ready':'0','parameter_values_change':'0','locked_exposure_values_change':'0','scope':'已收集目录事件的公开观察状态；法定生效日期未认证'})
assert len(monthly)==73*36
snapshot_changes=[]
for r in snapshots:
 if r['model_key'] not in added:continue
 e=last(r['model_key'],r['cutoff']);assert r['catalogue_active_observed']=='1'
 snapshot_changes.append({'model_key':r['model_key'],'cutoff':r['cutoff'],'old_state':r['state'],'new_state':'已撤销（区间口径下的已收集事件）','old_active':r['catalogue_active_observed'],'new_active':'0','new_possible_latest_event_id':e['event_id']})
assert len(snapshot_changes)==73*3
layer_by={r['model_key']:r for r in layer};removal=[]
for r in risk:
 key=r['model_key']
 if key not in added:continue
 assert r['membership_announcement_cohort']=='1' and r['announcement_active_observed']=='1'
 removal.append({'model_key':key,'old_risk_member':'1','new_risk_member':'0','in_frozen_1991':r['in_frozen_1991'],'old_numeric_did_ready':r['descriptive_continuous_did_input_ready'],'new_numeric_did_ready':'0','old_numeric_layer':layer_by[key]['numeric_layer'],'old_numeric_input_ready':layer_by[key]['numeric_input_ready'],'official_marked':str(int(key in official)),'new_prior_withdrawal_registered_public_date':added[key]['publish_date_exact'],'cohort_membership_change':'0'})
old_state_counts=collections.Counter(r['state'] for r in panel);new_state_counts=old_state_counts.copy()
for r in monthly:new_state_counts[r['old_state']]-=1;new_state_counts[r['new_state']]+=1
cutoff_counts={}
for cutoff in ['2023-12-10','2023-12-31','2024-12-31']:
 oldc=collections.Counter(r['state'] for r in snapshots if r['cutoff']==cutoff);newc=oldc.copy()
 for r in snapshot_changes:
  if r['cutoff']==cutoff:newc[r['old_state']]-=1;newc[r['new_state']]+=1
 cutoff_counts[cutoff]={'old':dict(oldc),'new':dict(newc)}
layer_old=collections.Counter(r['numeric_layer'] for r in layer);layer_removed=collections.Counter(r['old_numeric_layer'] for r in removal);layer_new=layer_old-layer_removed
old_risk=sum(r['membership_announcement_cohort']=='1' and r['announcement_active_observed']=='1' for r in risk)
old_ready=sum(r['descriptive_continuous_did_input_ready']=='1' for r in risk);removed_ready=sum(r['old_numeric_did_ready']=='1' for r in removal)
report={'new_sources':2,'new_total_source_rows':2020,'added_unique_cohort_events':73,'fixed_cohort_models':len(risk),'fixed_cohort_membership_change':0,'affected_panel_rows':len(monthly),'panel_total_rows':len(panel),'panel_state_counts_before':dict(old_state_counts),'panel_state_counts_after':dict(new_state_counts),'affected_three_cutoff_rows':len(snapshot_changes),'three_cutoff_state_counts':cutoff_counts,'risk_before':old_risk,'risk_after':old_risk-73,'risk_removed_models':73,'numeric_ready_before':old_ready,'numeric_ready_removed':removed_ready,'numeric_ready_after':old_ready-removed_ready,'numeric_insufficient_after':old_risk-73-(old_ready-removed_ready),'numeric_ready_after_cycle_counts':dict(collections.Counter(r['range_cycle_explicit'] or '未标注循环' for r in risk if r['model_key'] not in added and r['descriptive_continuous_did_input_ready']=='1')),'numeric_ready_removed_cycle_counts':dict(collections.Counter(r['range_cycle_explicit'] or '未标注循环' for r in risk if r['model_key'] in added and r['descriptive_continuous_did_input_ready']=='1')),'numeric_layers_before':dict(layer_old),'numeric_layers_removed':dict(layer_removed),'numeric_layers_after':dict(layer_new),'official_marked_removed':sum(r['official_marked']=='1' for r in removal),'newly_withdrawn_models_in_frozen_1991':sum(r['in_frozen_1991']=='1' for r in removal),'parameter_numeric_values_changed':0,'locked_exposure_values_changed':0,'dates_are_public_observations_not_legal_effective_certification':True}
write('new_withdrawal_monthly_state_changes_2628.csv',monthly);write('new_withdrawal_cutoff_changes_219.csv',snapshot_changes);write('new_withdrawal_risk_removals_73.csv',removal)
(ROOT/'new_withdrawal_impact_independent.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
