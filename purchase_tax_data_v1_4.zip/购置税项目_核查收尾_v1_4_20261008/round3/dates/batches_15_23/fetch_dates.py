from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode,urljoin
import ssl,json,hashlib,re,datetime,csv,html
from concurrent.futures import ThreadPoolExecutor
ROOT=Path('/workspace/purchase_tax_audit/round3/dates/batches_15_23')
BASE='https://www.miit.gov.cn/'
HEAD={'User-Agent':'Mozilla/5.0','Referer':BASE+'search/'}

def fetch(url,name):
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 rec={'request_url':url,'request_method':'GET','retrieved_at_utc':stamp,'tls_verification':True}
 try:
  with urlopen(Request(url,headers=HEAD),timeout=45,context=ssl.create_default_context()) as r:
   raw=r.read();rec.update(status=r.status,final_url=r.url,content_type=r.headers.get('Content-Type',''),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),local_file=str(ROOT/name));(ROOT/name).write_bytes(raw)
 except Exception as e: rec.update(error_type=type(e).__name__,error=str(e))
 (ROOT/(name+'.request.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2))
 return rec

def search(q,name,p=1,pg=10,cateid=47):
 args={'websiteid':'110000000000000','scope':'basic','cateid':cateid,'pg':pg,'p':p,'pos':'title_text,titlepy,infocontent,filenumbername,keyword,contentdescribe','q':q,'selectFields':'title,content,deploytime,_index,url,cdate,infoextends,infocontentattribute,keyword,contentdescribe,sectitle,picpath,columnname,themename,publishgroupname,publishtime,metaid,bexxgk,columnid,infocontenthashcode','group':'distinct','level':'6','sortFields':json.dumps([{'name':'deploytime','type':'desc'}],separators=(',',':'))}
 return fetch(BASE+'search-front-server/api/search/info?'+urlencode(args),name)

if __name__=='__main__':
 queries={15:'免征车辆购置税 第十五批',19:'免征车辆购置税 第十九批',20:'免征车辆购置税 第二十批',21:'免征车辆购置税 第二十一批',23:'免征车辆购置税 第二十三批'}
 def f(kv):
  b,q=kv; rec=search(q,'search_batch'+str(b)+'.json');print(json.dumps(rec,ensure_ascii=False),flush=True)
 list(ThreadPoolExecutor(max_workers=3).map(f,queries.items()))
